// Generated using https://github.com/a2x/cs2-dumper
// 2026-09-01 14:56:45.274492200 UTC

pub const cs2_dumper = struct {
    pub const schemas = struct {
        // Module: networksystem.dll
        // Class count: 1
        // Enum count: 0
        pub const networksystem_dll = struct {
            // Parent: None
            // Field count: 1
            pub const ChangeAccessorFieldPathIndex_t = struct {
                pub const m_Value: usize = 0x0; // int32
            };
        };
    };
};
