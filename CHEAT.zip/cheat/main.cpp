#include <Windows.h>
#include "src/init.hpp"

bool __stdcall DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved)
{
	// TODO: add manual map, thread hi-jacking support
    if (reason == DLL_PROCESS_ATTACH)
    {
		CreateThread(nullptr, 0, (LPTHREAD_START_ROUTINE)INIT::Init, instance, 0, nullptr);
    }
    return true;
    }