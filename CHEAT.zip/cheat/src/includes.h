#ifndef INCLUDES_H
#define INCLUDES_H

#include <Windows.h>
#include <dwmapi.h>
#include <d3dcompiler.h>
#include <DirectXMath.h>
#include <tchar.h>
#include <vector>
#include <TlHelp32.h>
#include "d3d11.h"
#include "../ext/imgui/imgui.h"
#include "../ext/imgui/imgui_impl_dx11.h"
#include "../ext/imgui/imgui_impl_win32.h"

#endif /* INCLUDES_H */
