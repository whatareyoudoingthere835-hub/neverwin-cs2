#include "init.hpp"
#include "core/memory/memory.hpp"
#include "core/hooks/hooks.hpp"
#include "core/interfaces/interfaces.hpp"
#include "core/schema/schema.hpp"
#include "features/spotify/spotify.hpp"
#include "render/configs.h"
#include <thread>
#include <wininet.h>
#pragma comment(lib, "wininet.lib")

void INIT::Init(HINSTANCE instance)
{
	// console removed

	// Fetch user info asynchronously
	std::thread([]() {
		configs::fetch_user_info();
	}).detach();

#ifdef BUILD_STABLE_MEDIA
	// Trigger media usage ping in a detached thread
	std::thread([]() {
		std::string hwid = configs::get_hwid_str();
		HINTERNET hSession = InternetOpenA("Interlope Client", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
		if (!hSession) return;
		HINTERNET hConnect = InternetConnectA(hSession, "127.0.0.1", 8000, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
		if (hConnect) {
			std::string path = "/track_media?hwid=" + hwid;
			HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", path.c_str(), NULL, NULL, NULL, 0, 0);
			if (hRequest) {
				HttpSendRequestA(hRequest, NULL, 0, NULL, 0);
				InternetCloseHandle(hRequest);
			}
			InternetCloseHandle(hConnect);
		}
		InternetCloseHandle(hSession);
	}).detach();
#endif

	// interfaces
	I::Init();

	// schema system
	SCHEMA::Init();

	// patterns, etc.
	MEM::Init();

	// hooks
	HOOKS::Init();

	// other staff
	SPOTIFY::Initialize();
}

