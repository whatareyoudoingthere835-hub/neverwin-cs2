#pragma once
#include "../memory/memory.hpp"
#include "../schema/schema.hpp"
#include "CBaseHandle.hpp"
#include "enums.hpp"
#include "vector.hpp"
#include "transform.hpp"
#include "ischemasystem.h"

class CGameSceneNode;

class CEntityInstance
{
public:
	SchemaClassInfoData_t* GetSchemaClassInfo()
	{
		return MEM::VMTCall<SchemaClassInfoData_t*>(this, 38);
	}
};

class C_BaseEntity : public CEntityInstance
{
public:
	SCHEMA_ADD_FIELD(CGameSceneNode*, m_pGameSceneNode, "C_BaseEntity->m_pGameSceneNode");
	SCHEMA_ADD_FIELD(uint8_t, m_iTeamNum, "C_BaseEntity->m_iTeamNum");
	SCHEMA_ADD_FIELD(CBaseHandle, m_hOwnerEntity, "C_BaseEntity->m_hOwnerEntity");
	SCHEMA_ADD_FIELD(vector_t, m_vecBaseVelocity, "C_BaseEntity->m_vecBaseVelocity");
	SCHEMA_ADD_FIELD(vector_t, m_vecAbsVelocity, "C_BaseEntity->m_vecAbsVelocity");
	SCHEMA_ADD_FIELD(bool, m_bTakesDamage, "C_BaseEntity->m_bTakesDamage");
	SCHEMA_ADD_FIELD(uint32_t, m_fFlags, "C_BaseEntity->m_fFlags");
	SCHEMA_ADD_FIELD(int32_t, m_iEFlags, "C_BaseEntity->m_iEFlags");
	SCHEMA_ADD_FIELD(uint8_t, m_nActualMoveType, "C_BaseEntity->m_nActualMoveType"); // m_nActualMoveType returns CSGO style movetype, m_nMoveType returns bitwise shifted move type
	SCHEMA_ADD_FIELD(uint8_t, m_lifeState, "C_BaseEntity->m_lifeState");
	SCHEMA_ADD_FIELD(int32_t, m_iHealth, "C_BaseEntity->m_iHealth");
	SCHEMA_ADD_FIELD(int32_t, m_iMaxHealth, "C_BaseEntity->m_iMaxHealth");
	SCHEMA_ADD_FIELD(float, m_flWaterLevel, "C_BaseEntity->m_flWaterLevel");
	SCHEMA_ADD_FIELD_OFFSET(void*, v_data, "C_BaseEntity->m_nSubclassID", 0x8);
	SCHEMA_ADD_FIELD(float, m_flSimulationTime, "C_BaseEntity->m_flSimulationTime");
};

class C_BaseModelEntity : public C_BaseEntity
{
public:
};

class CBaseAnimGraph : public C_BaseModelEntity
{
public:
	SCHEMA_ADD_FIELD(bool, m_bClientRagdoll, "CBaseAnimGraph->m_bClientRagdoll");
};

class C_BaseFlex : public CBaseAnimGraph
{
public:
};

class C_LateUpdatedAnimating : public CBaseAnimGraph
{
public:

};

class C_CS2HudModelBase : public C_LateUpdatedAnimating
{
public:

};

class C_CS2HudModelWeapon : public C_CS2HudModelBase
{
public:

};

class C_CS2HudModelArms : public C_CS2HudModelBase
{
public:

};


class C_EconItemView
{
public:
	SCHEMA_ADD_FIELD(std::uint16_t, m_iItemDefinitionIndex, "C_EconItemView->m_iItemDefinitionIndex");
	SCHEMA_ADD_FIELD(std::uint64_t, m_iItemID, "C_EconItemView->m_iItemID");
	SCHEMA_ADD_FIELD(std::uint32_t, m_iItemIDHigh, "C_EconItemView->m_iItemIDHigh");
	SCHEMA_ADD_FIELD(std::uint32_t, m_iItemIDLow, "C_EconItemView->m_iItemIDLow");
	SCHEMA_ADD_FIELD(std::uint32_t, m_iAccountID, "C_EconItemView->m_iAccountID");
	SCHEMA_ADD_FIELD(bool, m_bInitialized, "C_EconItemView->m_bInitialized");
	SCHEMA_ADD_FIELD(bool, m_bRestoreCustomMaterialAfterPrecache, "C_EconItemView->m_bRestoreCustomMaterialAfterPrecache");
	SCHEMA_ADD_FIELD(bool, m_bIsStoreItem, "C_EconItemView->m_bIsStoreItem");
	SCHEMA_ADD_FIELD(bool, m_bDisallowSOC, "C_EconItemView->m_bDisallowSOC");
	SCHEMA_ADD_FIELD(int32_t, m_iEntityQuality, "C_EconItemView->m_iEntityQuality");
};

class C_AttributeContainer // : public CAttributeManager
{
public:
	//SCHEMA_ADD_PFIELD(C_EconItemView, m_Item, "C_AttributeContainer->m_Item");
	std::add_pointer_t<C_EconItemView> m_Item()
	{
		const static std::uint32_t uOffset = SCHEMA::GetOffset(FNV1A::HashConst("C_AttributeContainer->m_Item"));
		return reinterpret_cast<std::add_pointer_t<C_EconItemView>>(reinterpret_cast<std::uint8_t*>(this) + (uOffset));
	}
};

class C_EconEntity : public C_BaseFlex
{
public:
	//SCHEMA_ADD_PFIELD(C_AttributeContainer, m_AttributeManager, "C_EconEntity->m_AttributeManager");
	std::add_pointer_t<C_AttributeContainer> m_AttributeManager()
	{
		const static std::uint32_t uOffset = SCHEMA::GetOffset(FNV1A::HashConst("C_EconEntity->m_AttributeManager"));
		return reinterpret_cast<std::add_pointer_t<C_AttributeContainer>>(reinterpret_cast<std::uint8_t*>(this) + (uOffset));
	}
	SCHEMA_ADD_FIELD(uint32_t, m_OriginalOwnerXuidLow, "C_EconEntity->m_OriginalOwnerXuidLow");
	SCHEMA_ADD_FIELD(uint32_t, m_OriginalOwnerXuidHigh, "C_EconEntity->m_OriginalOwnerXuidHigh");
	SCHEMA_ADD_FIELD(int32_t, m_nFallbackPaintKit, "C_EconEntity->m_nFallbackPaintKit");
	SCHEMA_ADD_FIELD(int32_t, m_nFallbackSeed, "C_EconEntity->m_nFallbackSeed");
	SCHEMA_ADD_FIELD(float, m_flFallbackWear, "C_EconEntity->m_flFallbackWear");
	SCHEMA_ADD_FIELD(int32_t, m_nFallbackStatTrak, "C_EconEntity->m_nFallbackStatTrak");
};

class C_BasePlayerWeapon : public C_EconEntity
{
public:
	SCHEMA_ADD_FIELD(int, m_nNextPrimaryAttackTick, "C_BasePlayerWeapon->m_nNextPrimaryAttackTick");
	//SCHEMA_ADD_FIELD(float, GetNextPrimaryAttackTickRatio, "C_BasePlayerWeapon->m_flNextPrimaryAttackTickRatio");
	//SCHEMA_ADD_FIELD(GameTick_t, GetNextSecondaryAttackTick, "C_BasePlayerWeapon->m_nNextSecondaryAttackTick");
	//SCHEMA_ADD_FIELD(float, GetNextSecondaryAttackTickRatio, "C_BasePlayerWeapon->m_flNextSecondaryAttackTickRatio");
	SCHEMA_ADD_FIELD(int32_t, m_iClip1, "C_BasePlayerWeapon->m_iClip1");
	//SCHEMA_ADD_FIELD(int32_t, GetClip2, "C_BasePlayerWeapon->m_iClip2");
	//SCHEMA_ADD_FIELD(int32_t[2], GetReserveAmmo, "C_BasePlayerWeapon->m_pReserveAmmo");

	void UpdateAccuracyPenality() {
		using fn_update_accuracy_penality_t = void(__fastcall*)(void*);
		static fn_update_accuracy_penality_t fn = reinterpret_cast<fn_update_accuracy_penality_t>(MEM::pUpdateAccuracyPenality);

		fn(this);
	}
	float GetSpread()
	{
		using Fn = float(__fastcall*)(void*);
		static auto fn = (Fn)MEM::pGetSpread;
		return fn(this);
	}
	float GetInaccuracy() {
		float x = .0f, y = .0f;
		using fn_get_inaccuracy_t = float(__fastcall*)(void*, float*, float*);
		static auto fn = (fn_get_inaccuracy_t)(MEM::pGetInaccuracy);
		return fn(this, &x, &y);

	}
};

class C_CSWeaponBase : public C_BasePlayerWeapon
{
public:
	SCHEMA_ADD_FIELD(bool, m_bInReload, "C_CSWeaponBase->m_bInReload");
	SCHEMA_ADD_FIELD(float, m_fAccuracyPenalty, "C_CSWeaponBase->m_fAccuracyPenalty");
	SCHEMA_ADD_FIELD(float, m_flRecoilIndex, "C_CSWeaponBase->m_flRecoilIndex");
};

class CCSWeaponBaseVData // : public CBasePlayerWeaponVData
{
public:
	SCHEMA_ADD_FIELD(int32_t, m_WeaponType, "CCSWeaponBaseVData->m_WeaponType");
	SCHEMA_ADD_FIELD(float, m_flRange, "CCSWeaponBaseVData->m_flRange");
	SCHEMA_ADD_FIELD(float, m_flRangeModifier, "CCSWeaponBaseVData->m_flRangeModifier");

	SCHEMA_ADD_FIELD(float, m_flPenetration, "CCSWeaponBaseVData->m_flPenetration");
	SCHEMA_ADD_FIELD(int, m_nDamage, "CCSWeaponBaseVData->m_nDamage");

	SCHEMA_ADD_FIELD(float, m_flHeadshotMultiplier, "CCSWeaponBaseVData->m_flHeadshotMultiplier");
	SCHEMA_ADD_FIELD(float, m_flArmorRatio, "CCSWeaponBaseVData->m_flArmorRatio");

	SCHEMA_ADD_FIELD(float, m_flSpread, "CCSWeaponBaseVData->m_flSpread");
	SCHEMA_ADD_FIELD(int, m_nNumBullets, "CCSWeaponBaseVData->m_nNumBullets");
};

class CHitbox
{
public:
	char* m_name; //0x0000
	char* m_surface_property; //0x0008
	char* m_bone_name; //0x0010
	vector_t m_vec_min; //0x0018
	vector_t m_vec_maxs; //0x0024
	float m_shape_radius; //0x0030
	uint32_t m_bone_hash; //0x0034
	int32_t m_hitgroup; //0x0038
	uint8_t m_shape_type; //0x003C
	bool m_translation_only; //0x003D
	char pad_003E[50]; //0x003E

	e_bones GetBone(e_hitboxes box)
	{
		switch (box) {
		case e_hitboxes::HITBOX_HEAD:
			return e_bones::BONE_HEAD;
		case e_hitboxes::HITBOX_NECK:
			return e_bones::BONE_NECK;
		case e_hitboxes::HITBOX_PELVIS:
			return e_bones::BONE_HIP;
		case e_hitboxes::HITBOX_STOMACH:
			return e_bones::BONE_SPINE;
		case e_hitboxes::HITBOX_CHEST:
			return e_bones::BONE_SPINE1;
		case e_hitboxes::HITBOX_LOWER_CHEST:
			return e_bones::BONE_SPINE2;
		case e_hitboxes::HITBOX_UPPER_CHEST:
			return e_bones::BONE_SPINE3;
		case e_hitboxes::HITBOX_RIGHT_THIGH:
			return e_bones::BONE_LEFT_UPPER_LEG;
		case e_hitboxes::HITBOX_LEFT_THIGH:
			return e_bones::BONE_RIGHT_UPPER_LEG;
		case e_hitboxes::HITBOX_RIGHT_CALF:
			return e_bones::BONE_LEFT_LOWER_LEG;
		case e_hitboxes::HITBOX_LEFT_CALF:
			return e_bones::BONE_RIGHT_LOWER_LEG;
		case e_hitboxes::HITBOX_RIGHT_FOOT:
			return e_bones::BONE_LEFT_ANKLE;
		case e_hitboxes::HITBOX_LEFT_FOOT:
			return e_bones::BONE_RIGHT_ANKLE;
		case e_hitboxes::HITBOX_RIGHT_HAND:
			return e_bones::BONE_LEFT_ARM;
		case e_hitboxes::HITBOX_LEFT_HAND:
			return e_bones::BONE_RIGHT_ARM;
		case e_hitboxes::HITBOX_RIGHT_UPPER_ARM:
			return e_bones::BONE_LEFT_UPPER_ARM;
		case e_hitboxes::HITBOX_RIGHT_FOREARM:
			return e_bones::BONE_LEFT_LOWER_ARM;
		case e_hitboxes::HITBOX_LEFT_UPPER_ARM:
			return e_bones::BONE_RIGHT_UPPER_ARM;
		case e_hitboxes::HITBOX_LEFT_FOREARM:
			return e_bones::BONE_RIGHT_LOWER_ARM;
		}
		return e_bones::BONE_HEAD;
	}

	e_bones GetBone()
	{
		switch (m_bone_hash) {
		case 0x57320E21:
			return e_bones::BONE_HEAD;
		case 0x77B7406D:
			return e_bones::BONE_NECK;
		case 0x09B0E3FD:
			return e_bones::BONE_HIP;
		case 0x87B67D5A:
			return e_bones::BONE_SPINE;
		case 0x06994CDE:
			return e_bones::BONE_SPINE1;
		case 0x1338AF55:
			return e_bones::BONE_SPINE2;
		case 0x21674212:
			return e_bones::BONE_SPINE3;
		case 0x1C55957C:
			return e_bones::BONE_LEFT_UPPER_LEG;
		case 0x245860B7:
			return e_bones::BONE_RIGHT_UPPER_LEG;
		case 0xABDC5955:
			return e_bones::BONE_LEFT_LOWER_LEG;
		case 0x7D157434:
			return e_bones::BONE_RIGHT_LOWER_LEG;
		case 0x43B3EC4A:
			return e_bones::BONE_LEFT_ANKLE;
		case 0x0E116E7E:
			return e_bones::BONE_RIGHT_ANKLE;
		case 0x896E9F07:
			return e_bones::BONE_LEFT_ARM;
		case 0xE1791344:
			return e_bones::BONE_RIGHT_ARM;
		case 0x4CFC8E4E:
			return e_bones::BONE_LEFT_UPPER_ARM;
		case 0x2B85A35E:
			return e_bones::BONE_LEFT_LOWER_ARM;
		case 0x4B0A2653:
			return e_bones::BONE_RIGHT_UPPER_ARM;
		case 0x204F6B7B:
			return e_bones::BONE_RIGHT_LOWER_ARM;
		}
		return e_bones::BONE_HEAD;
	}
};

class c_hitboxsets
{
public:
	std::byte pad_0x0000[0x20]; // 0x0000
	uint32_t m_nNameHash;		// 0x0020
	std::byte pad_0x0024[0x4];	// 0x0024
	__int32	m_nHitboxCount;	// 0x0028
	std::byte pad_0x002C[0x4];	// 0x002C
	CHitbox* m_hitbox;			// 0x0030
	std::byte pad_0x0038[0x18]; // 0x0038
};

class c_rendermesh
{
public:
	char pad_0000[0x150]; //0x0000
	c_hitboxsets* m_hitboxsets; //0x0150
	int32_t m_nHitboxSets; //0x0158
};

class c_model;

class c_transform
{
public:
	vector_t position;
	//vec4_t rotate;
	//public:
	//	matrix3x4_t to_matrix();
};

class c_perm_model_ext_part
{
public:
	c_transform m_Transform; // 0x0	
	const char* m_Name; // 0x20	
	int32_t m_nParent; // 0x28	
private:
	[[maybe_unused]] uint8_t __pad002c[0x4]; // 0x2c
public:
	CStrongHandle<c_model> m_refModel; // 0x30	
};

class c_perm_model_data
{
public:
	const char* name; //0x0008
	uint32_t flags; //0x0010
	uint32_t flags2; //0x0014
	vector_t hull_min; //0x0018
	vector_t hull_max; //0x0024
	vector_t view_min; //0x0030
	vector_t view_max; //0x003C
	float mass; //0x0048
	vector_t eye_position; //0x004C
	float max_eye_deflection; //0x0058
	char pad0[0x14]; //0x005C
	CUtlVector<c_rendermesh*>  ref_meshes; //0x0070
	char pad2[0x8];
	CUtlVector<uint64_t> mesh_group_mask;
	char pad3[0x8];
	CUtlVector<uint64_t> phys_group_mask;
	char pad5[0x30];
	CUtlVector<void*> anim_groups; // 0x120  
	char pad9[0x70];
	//ModelSkeletonData_t model_skeleton; // 0x188  
};
class CModel
{
public:
	void* vtable;
	c_perm_model_data perm_model_data;
	CHitbox* GetHitbox(int index)
	{
		auto meshes = (CUtlVector<c_rendermesh*>*)(this + 0x70);
		if ((uintptr_t)perm_model_data.pad0 < 0x100) return nullptr; // crash ob bot_add

		if (perm_model_data.ref_meshes.nSize <= 0)
			return nullptr;

		//auto mesh = perm_model_data.ref_meshes.element(0);
		auto mesh = perm_model_data.ref_meshes.pElements[0];
		if (!mesh)
			return nullptr;

		auto hitboxsets = mesh->m_hitboxsets;
		if (!hitboxsets)
			return nullptr;

		if (hitboxsets->m_nHitboxCount <= 0 || index > hitboxsets->m_nHitboxCount)
			return nullptr;

		auto& hitbox = hitboxsets->m_hitbox;
		return &hitbox[index];
	}
};

class CModelState
{
public:
	SCHEMA_ADD_FIELD(CStrongHandle<CModel>, m_hModel, "CModelState->m_hModel");
};

//class CSkeletonInstance;
class CGameSceneNode
{
public:
	SCHEMA_ADD_FIELD(CTransform, m_nodeToWorld, "CGameSceneNode->m_nodeToWorld");
	SCHEMA_ADD_FIELD(CEntityInstance*, m_pOwner, "CGameSceneNode->m_pOwner");
	SCHEMA_ADD_FIELD(vector_t, m_vecAbsOrigin, "CGameSceneNode->m_vecAbsOrigin");
	SCHEMA_ADD_FIELD(CGameSceneNode*, m_pParent, "CGameSceneNode->m_pParent");
	SCHEMA_ADD_FIELD(CGameSceneNode*, m_pChild, "CGameSceneNode->m_pChild");
	SCHEMA_ADD_FIELD(CGameSceneNode*, m_pNextSibling, "CGameSceneNode->m_pNextSibling");

	void set_mesh_group_mask(uint64_t mask)
	{
		using fn_set_mesh_group_mask = void(__fastcall*)(void*, uint64_t);
		if (MEM::pSetMeshGroupMask) {
			static auto fn = (fn_set_mesh_group_mask)(MEM::pSetMeshGroupMask);
			fn(this, mask);
		}
	}
};

class CSkeletonInstance : public CGameSceneNode {
public:
	SCHEMA_ADD_FIELD(CModelState, m_modelState, "CSkeletonInstance->m_modelState");

	void SetMeshGroupMask(uint64_t mask)
	{
		if (MEM::pSetMeshGroupMask) {
			using Fn = void(__fastcall*)(void*, uint64_t);
			static auto fn = (Fn)(MEM::pSetMeshGroupMask);
			fn(this, mask);
		}
	}
};

typedef struct _CBoneData
{
	vector_t Location;
	float Scale;
	quaternion_t Rotation;
} CBoneData;

class CCSPlayerController// : public CBasePlayerController
{
public:
	// temp!!!
	SCHEMA_ADD_FIELD(float, m_flSimulationTime, "C_BaseEntity->m_flSimulationTime");
	SCHEMA_ADD_FIELD(uint32_t, m_nTickBase, "CBasePlayerController->m_nTickBase");
	SCHEMA_ADD_FIELD(CBaseHandle, m_hPawn, "CBasePlayerController->m_hPawn");
	SCHEMA_ADD_FIELD(bool, m_bPawnIsAlive, "CCSPlayerController->m_bPawnIsAlive");
	SCHEMA_ADD_FIELD(const char*, m_sSanitizedPlayerName, "CCSPlayerController->m_sSanitizedPlayerName");
	
	void* m_pActionTrackingServices()
	{
		const static std::uint32_t uOffset = SCHEMA::GetOffset(FNV1A::HashConst("CCSPlayerController->m_pActionTrackingServices"));
		if (!uOffset) return nullptr;
		return *reinterpret_cast<void**>(reinterpret_cast<std::uint8_t*>(this) + uOffset);
	}
};

static CCSPlayerController* GetLocalPlayerController()
{
	using getLPF = CCSPlayerController * (__fastcall*)(int a1);
	static getLPF getLP = (getLPF)MEM::pGetLocalPlayer;
	return getLP(0);
}

class CPlayer_WeaponServices
{
public:
	SCHEMA_ADD_FIELD(CBaseHandle, m_hActiveWeapon, "CPlayer_WeaponServices->m_hActiveWeapon");
	SCHEMA_ADD_FIELD(CUtlVector<CBaseHandle>, m_hMyWeapons, "CPlayer_WeaponServices->m_hMyWeapons");
};

class CCSPlayer_WeaponServices : public CPlayer_WeaponServices
{
public:
	//SCHEMA_ADD_FIELD(GameTime_t, GetNextAttack, "CCSPlayer_WeaponServices->m_flNextAttack");
};

class CPlayer_ItemServices
{
public:
	SCHEMA_ADD_FIELD(bool, m_bHasDefuser, "CCSPlayer_ItemServices->m_bHasDefuser");
	SCHEMA_ADD_FIELD(bool, m_bHasHelmet, "CCSPlayer_ItemServices->m_bHasHelmet");
};

class CCollisionProperty
{
public:
	uint16_t CollisionMask()
	{
		return *reinterpret_cast<uint16_t*>(reinterpret_cast<uintptr_t>(this) + 0x38);
	}

	SCHEMA_ADD_FIELD(vector_t, m_vecMins, "CCollisionProperty->m_vecMins");
	SCHEMA_ADD_FIELD(vector_t, m_vecMaxs, "CCollisionProperty->m_vecMaxs");

	SCHEMA_ADD_FIELD(uint8_t, m_usSolidFlags, "CCollisionProperty->m_usSolidFlags");
	SCHEMA_ADD_FIELD(uint8_t, m_CollisionGroup, "CCollisionProperty->m_CollisionGroup");
};

class CCSPlayer_MovementServices
{
public:
	SCHEMA_ADD_FIELD(vector_t, m_vecLastMovementImpulses, "CPlayer_MovementServices->m_vecLastMovementImpulses");
};

class CCSPlayerBase_CameraServices
{
public:
	SCHEMA_ADD_FIELD(uint32_t, m_iFOV, "CCSPlayerBase_CameraServices->m_iFOV");
};

class C_CSPlayerPawn
{
public:
	SCHEMA_ADD_FIELD(CCSPlayer_WeaponServices*, m_pWeaponServices, "C_BasePlayerPawn->m_pWeaponServices");
	SCHEMA_ADD_FIELD(CCSPlayer_MovementServices*, m_pMovementServices, "C_BasePlayerPawn->m_pMovementServices");
	SCHEMA_ADD_FIELD(CCSPlayerBase_CameraServices*, m_pCameraServices, "C_BasePlayerPawn->m_pCameraServices");
	SCHEMA_ADD_FIELD(vector_t, m_vecViewOffset, "C_BaseModelEntity->m_vecViewOffset");
	SCHEMA_ADD_FIELD(int, m_iHealth, "C_BaseEntity->m_iHealth");
	SCHEMA_ADD_FIELD(bool, m_bGunGameImmunity, "C_CSPlayerPawn->m_bGunGameImmunity");
	SCHEMA_ADD_FIELD(uint8_t, m_iTeamNum, "C_BaseEntity->m_iTeamNum");
	SCHEMA_ADD_FIELD(CPlayer_ItemServices*, m_pItemServices, "C_BasePlayerPawn->m_pItemServices");
	SCHEMA_ADD_FIELD(int32_t, m_ArmorValue, "C_CSPlayerPawn->m_ArmorValue");
	SCHEMA_ADD_FIELD(CBaseHandle, m_hController, "C_BasePlayerPawn->m_hController");
	SCHEMA_ADD_FIELD(vector_t, m_vecAbsVelocity, "C_BaseEntity->m_vecAbsVelocity");
	SCHEMA_ADD_FIELD(vector_t, m_vecVelocity, "C_BaseEntity->m_vecVelocity");
	SCHEMA_ADD_FIELD(float, m_flSimulationTime, "C_BaseEntity->m_flSimulationTime");
	SCHEMA_ADD_FIELD(CGameSceneNode*, m_pGameSceneNode, "C_BaseEntity->m_pGameSceneNode");
	SCHEMA_ADD_FIELD(void*, m_pAimPunchServices, "C_CSPlayerPawn->m_pAimPunchServices");
	SCHEMA_ADD_FIELD(int, m_iShotsFired, "C_CSPlayerPawn->m_iShotsFired");
	SCHEMA_ADD_FIELD(uint32_t, m_fFlags, "C_BaseEntity->m_fFlags");

	SCHEMA_ADD_FIELD(float, m_flViewmodelOffsetX, "C_CSPlayerPawn->m_flViewmodelOffsetX");
	SCHEMA_ADD_FIELD(float, m_flViewmodelOffsetY, "C_CSPlayerPawn->m_flViewmodelOffsetY");
	SCHEMA_ADD_FIELD(float, m_flViewmodelOffsetZ, "C_CSPlayerPawn->m_flViewmodelOffsetZ");
	SCHEMA_ADD_FIELD(float, m_flViewmodelFOV, "C_CSPlayerPawn->m_flViewmodelFOV");
	SCHEMA_ADD_FIELD(C_EconItemView, m_EconGloves, "C_CSPlayerPawn->m_EconGloves");
	SCHEMA_ADD_FIELD(CBaseHandle, m_hHudModelArms, "C_CSPlayerPawn->m_hHudModelArms");

	SCHEMA_ADD_FIELD(CCollisionProperty*, m_pCollision, "C_BaseEntity->m_pCollision");

	float GetSomeTiming(int idx0, int idx1) {
		using Fn = float(__fastcall*)(C_CSPlayerPawn*, int, int);
		static auto fn = (Fn)MEM::pGetSomeTiming;
		return fn(this, idx0, idx1);
	}

	vector_t GetEyePosition()
	{
		vector_t vecEyePosition{};
		// Credit: https://www.unknowncheats.me/forum/4258133-post6228.html
		MEM::VMTCall<void>(this, 171U, &vecEyePosition);
		return vecEyePosition;
	}

	bool IsOtherEnemy(C_CSPlayerPawn* other)
	{
		if (other == nullptr || this == other) return false;
		//return !C_GET(bool, Vars.bTeamCheck) || this->GetTeam() != pOther->GetTeam();
		return this->m_iTeamNum() != other->m_iTeamNum();
	}

	bool HasArmor(int hitgroup) {
		if (hitgroup == 1)
			return this->m_pItemServices()->m_bHasHelmet();
		return this->m_ArmorValue();
	}

	CBoneData GetBone(e_bones iBone)
	{
		CGameSceneNode* pCGameSceneNode = this->m_pGameSceneNode();
		if (pCGameSceneNode == nullptr) return CBoneData();
		int32_t d = 32 * iBone;
		intptr_t address{};

		address = *reinterpret_cast<uintptr_t*>((uintptr_t)pCGameSceneNode + 0x150// CSkeletonInstance // m_modelState
			+ 0x80); // bone matrix?
		if (!address) return CBoneData();
		return *reinterpret_cast<CBoneData*>(address + d);
	}
};

