#pragma once
#include "../memory/memory.hpp"

class CUtlBuffer
{
public:
	MEM_PAD(0x80);

	CUtlBuffer(int a1, int nSize, int a3)
	{
		static auto fnUtlBufferInit = (void(__fastcall*)(CUtlBuffer*, int, int, int))MEM::pUtlBufferInit;
		fnUtlBufferInit(this, a1, nSize, a3);
	}

	void PutString(const char* szString)
	{
		static auto fnUtlBufferPutString = (void(__fastcall*)(CUtlBuffer*, const char*))MEM::pUtlBufferPutString;
		fnUtlBufferPutString(this, szString);
	}

	void EnsureCapacity(int nSize)
	{
		static auto fnUtlBufferEnsureCapacity = (void(__fastcall*)(CUtlBuffer*, int))MEM::pUtlBufferEnsureCapacity;
		fnUtlBufferEnsureCapacity(this, nSize);
	}
};
