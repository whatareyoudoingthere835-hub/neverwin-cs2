#pragma once
#include "../../base.hpp"
// used: pad and findpattern
//#include "../../utilities/memory.h"
#include "vector.hpp"
#include "entity.hpp"
#include "enums.hpp"
#include <array>

struct Ray_t
{
public:
	vector_t m_vecStart;
	vector_t m_vecEnd;
	vector_t m_vecMins;
	vector_t m_vecMaxs;
	MEM_PAD(0x4);
	uint8_t UnkType;
};
// static_assert(sizeof(Ray_t) == 0x38);

struct SurfaceData_t
{
public:
	MEM_PAD(0x8);
	float m_flPenetrationModifier;
	float m_flDamageModifier;
	MEM_PAD(0x4);
	int m_iMaterial;
};
// static_assert(sizeof(SurfaceData_t) == 0x18);

struct TraceHitboxData_t
{
public:
	MEM_PAD(0x38);
	int m_nHitGroup;
	MEM_PAD(0x4);
	int m_nHitboxId;
};
// static_assert(sizeof(TraceHitboxData_t) == 0x44);

struct GameTrace_t
{
public:
	__int64 Init()
	{
		using fnGameTraceInit = __int64(__fastcall*)(GameTrace_t*);
		static auto oGameTraceInit = reinterpret_cast<fnGameTraceInit>(MEM::pGameTraceInit);
		return oGameTraceInit(this);
	}

	//SurfaceData_t* GetSurfaceData();
	int GetHitgroup()
	{
		if (m_pHitboxData)
			return m_pHitboxData->m_hitgroup;
		return 0;
	}

	void* m_pSurface;
	C_CSPlayerPawn* m_pHitEntity;
	CHitbox* m_pHitboxData;
	MEM_PAD(0x38);
	std::uint32_t m_uContents;
	MEM_PAD(0x24);
	vector_t m_vecStartPos;
	vector_t m_vecEndPos;
	vector_t m_vecNormal;
	vector_t m_vecPosition;
	MEM_PAD(0x4);
	float m_flFraction;
	MEM_PAD(0x6);
	bool m_bAllSolid;
	MEM_PAD(0x4D)
};
// static_assert(sizeof(GameTrace_t) == 0x108);

struct TraceFilter_t
{
public:
	MEM_PAD(0x8);
	int64_t m_uTraceMask;
	std::array<int64_t, 2> m_v1;
	std::array<int32_t, 4> m_arrSkipHandles;
	std::array<int16_t, 2> m_arrCollisions;
	int16_t m_v2;
	uint8_t m_v3;
	uint8_t m_v4;
	uint8_t m_v5;
	uint8_t m_v6;

	TraceFilter_t() = default;
	TraceFilter_t(std::uint64_t uMask, C_CSPlayerPawn* pSkip1, C_CSPlayerPawn* pSkip2, int nLayer);
	void Init(C_CSPlayerPawn* pawn, uint64_t mask, uint8_t layer, uint16_t unknown)
	{
		using fn_init_trace_t = TraceFilter_t * (__fastcall*)(TraceFilter_t*, void*, uint64_t, uint8_t, uint16_t);
		static fn_init_trace_t fn = reinterpret_cast<fn_init_trace_t>(MEM::pInitTrace);
		fn(this, pawn, mask, layer, unknown);
	}
};
// static_assert(sizeof(TraceFilter_t) == 0x40);

struct trace_array_element_t {
	uint8_t pad_001[0x30];
};

struct update_value_t {
	float m_previous_length_mod{ };
	float m_current_length_mod{ };
	uint8_t pad_001[0x8];
	short m_handle_index{ };
	uint8_t pad_002[0x6];
};

struct handle_bulllet_penetration_data_t {
	handle_bulllet_penetration_data_t(const float damage, const float pen, const float range_mod, const float range, const int pen_count, const bool failed) :
		m_damage(damage),
		m_penetration(pen),
		m_range_modifier(range_mod),
		m_range(range),
		m_pen_count(pen_count),
		m_failed(failed)
	{
	}

	float m_damage{ };
	float m_penetration{ };
	float m_range_modifier{ };
	float m_range{ };
	int m_pen_count{ };
	bool m_failed{ };
};

struct penetration_data {
	MEM_PAD(0x8);
	float damage{ };
	int penetrationCount{ };
	MEM_PAD(0x8);
};
// static_assert(sizeof(penetration_data) == 0x18);


struct trace_data_t {
	int uk1{ };
	float uk2{ 52.0f };
	void* arr_pointer{ };
	int uk3{ 128 };
	int uk4{ static_cast<int32_t>(0x80000000) };
	std::array< trace_array_element_t, 0x80 > arr = { };
	uint8_t pad_001[0x8];
	int64_t num_update{ };
	void* pointer_update_value{ };
	uint8_t pad_002[0xC8];
	vector_t start{ }, end{ };
	uint8_t pad_003[0x50];

	void Init()
	{
		using fn_trace_data_init = __int64(__fastcall*) (trace_data_t*);
		fn_trace_data_init fn = reinterpret_cast<fn_trace_data_init>(MEM::pTraceDataInit);
		fn(this);
	}

	__int64 GetInfo(GameTrace_t* const hit, const float unknown_float, void* unknown)
	{
		using fnGetGameTraceIngo = __int64(__fastcall*)(trace_data_t* a1, GameTrace_t* a2, float a3, void* a4);
		static auto oGetGameTraceIngo = reinterpret_cast<fnGetGameTraceIngo>(MEM::pGetGameTraceInfo);
		return oGetGameTraceIngo(this, hit, unknown_float, unknown);
	}

	bool HandleBulletPenetration(handle_bulllet_penetration_data_t* stats, update_value_t* const mod_value, const int team_num) {
		using fn_handle_bullet_penetration = bool(__fastcall*) (trace_data_t*, handle_bulllet_penetration_data_t*, update_value_t*, int, void*);
		static fn_handle_bullet_penetration fn = reinterpret_cast<fn_handle_bullet_penetration>(MEM::pHandleBulletPenetration);

		return fn(this, stats, mod_value, team_num, nullptr);
	}

	uint64_t CreateTrace(vector_t* start, vector_t* end, TraceFilter_t* filter, int penetration_count) {
		using fn_create_trace_t = uint64_t(__fastcall*) (trace_data_t*, vector_t*, vector_t*, TraceFilter_t*, int, char);
		static fn_create_trace_t fn = reinterpret_cast<fn_create_trace_t>(MEM::pCreateTrace);

		return fn(this, start, end, filter, penetration_count, 1);
	}
};

inline bool CheckHitgroup(int hitgroup)
{
	//if (hitgroup == hitgroup_head || hitgroup == hitgroup_neck)
	//	return C_GET(uint32_t, Vars.nHitGroups) & (1 << 1 - 1);
	//if (hitgroup == hitgroup_chest)
	//	return C_GET(uint32_t, Vars.nHitGroups) & (1 << 2 - 1);
	//if (hitgroup == hitgroup_stomach)
	//	return C_GET(uint32_t, Vars.nHitGroups) & (1 << 3 - 1);
	//if (hitgroup == hitgroup_left_hand)
	//	return C_GET(uint32_t, Vars.nHitGroups) & (1 << 4 - 1);
	//if (hitgroup == hitgroup_right_hand)
	//	return C_GET(uint32_t, Vars.nHitGroups) & (1 << 4 - 1);
	//if (hitgroup == hitgroup_left_leg)
	//	return C_GET(uint32_t, Vars.nHitGroups) & (1 << 5 - 1);
	//if (hitgroup == hitgroup_right_leg)
	//	return C_GET(uint32_t, Vars.nHitGroups) & (1 << 5 - 1);
	//return false;
	return true;
}
