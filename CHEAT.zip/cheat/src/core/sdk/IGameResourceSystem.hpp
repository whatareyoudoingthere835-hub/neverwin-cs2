#pragma once
#include "../../base.hpp"
#include "CGameEntitySystem.hpp"

class IGameResourceService
{
public:
	MEM_PAD(0x58);
	CGameEntitySystem* pGameEntitySystem;
};