#pragma once
#include "../memory/memory.hpp"
#include <cstdint>

struct ui_panel_t;

struct panel_2d_t {
    const void* vfptr;
    ui_panel_t* ui_panel;
};

struct ui_panel_t {
    const void* vfptr;
    panel_2d_t* client_panel;
};

class c_ui_engine_source2 {
public:
    void run_script(ui_panel_t* panel, const char* script) {
        // vtable index 77
        using fn = void(__thiscall*)(void*, ui_panel_t*, const char*, const char*, int);
        MEM::VMTCall<void>(this, 77, panel, script, "", 1);
    }
};

class i_panorama_ui_engine {
public:
    c_ui_engine_source2* access_ui_engine() {
        // vtable index 13
        return MEM::VMTCall<c_ui_engine_source2*>(this, 13);
    }
};

namespace I {
    inline i_panorama_ui_engine* PanoramaUIEngine = nullptr;
}
