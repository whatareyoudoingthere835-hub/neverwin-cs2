#pragma once
#include "../../base.hpp"
#include "vector.hpp"
#include "CUserCmd.hpp"
#include "entity.hpp"

class CCSPlayerController;

#define MULTIPLAYER_BACKUP 150

struct InterpInfo
{
	timestamp_t renderTimeStamp;
	timestamp_t playerTimeStamp;
	vector_t viewAngles;
	vector_t position;
	int nTargetEntIndex;
	vector_t headPos;
	vector_t pTargetAbsPositionCheck;
	vector_t pTargetAngPositionCheck;
	int nFrameNumber;
	int cmdNum;
	char pad0[8];

	uint64_t FillInputHistoryEntry(CCSGOInputHistoryEntryPB* historyEntry, bool a3, timestamp_t a4, timestamp_t a5, C_CSPlayerPawn* a6)
	{
		using FillInputHistoryEntryFn = uint64_t(__fastcall*)(InterpInfo*, CCSGOInputHistoryEntryPB*, bool, timestamp_t, timestamp_t, C_CSPlayerPawn*);
		static auto FillInputHistoryEntry = (FillInputHistoryEntryFn)MEM::pFillInputHistoryEntry;
		return FillInputHistoryEntry(this, historyEntry, a3, a4, a5, a6);
	}
};
static_assert(sizeof(InterpInfo) == 0x60);

class CUserCmdArray {
public:
	inline uint32_t& m_nSequenceNumber() {
		return *(uint32_t*)((uintptr_t)this + 0x5910);
	}
};

class CCSGOInput
{
public:
	inline bool& m_in_thirdperson() {
		return *(bool*)((uintptr_t)this + 0x5201);
	}

	inline vector_t& m_thirdperson_angles() {
		return *(vector_t*)((uintptr_t)this + 0x5208);
	}

	char pad0[0xBC0];
	int nAttack1StartHistoryIndex;
	int nAttack2StartHistoryIndex;
	CUtlVector<InterpInfo> interpInfoArr;

	void CalculateCRC(CUserCmd* cmd)
	{
		MEM::VMTCall<void>(this, 6, cmd);
	}

	void SetViewAngle(vector_t* angView)
	{
		using fnSetViewAngle = std::int64_t(__fastcall*)(void*, int32_t, vector_t*);
		static auto oSetViewAngle = reinterpret_cast<fnSetViewAngle>(MEM::pSetViewAngle);
		oSetViewAngle(this, 0, angView);
	}

	vector_t GetViewAngles()
	{
		using fnGetViewAngles = std::int64_t(__fastcall*)(CCSGOInput*, int32_t);
		static auto oGetViewAngles = reinterpret_cast<fnGetViewAngles>(MEM::pGetViewAngle);
		return *reinterpret_cast<vector_t*>(oGetViewAngles(this, 0));
	}

	// A BIG PASTE FROM IDA
	float GetSubtickFraction()
	{
		uintptr_t v7 = ((uintptr_t)this + 0x228ULL);
		uintptr_t v74 = v7 + 0x70ULL;
		uintptr_t v71;
		*(__int64*)&v71 = *((unsigned int*)v74 - 4);
		float time = *(float*)&v71;
		return time;
	}

	// A BIG PASTE FROM IDA
	CUserCmd* GetCurrentCmd(CCSPlayerController* localPlayer)
	{
		int32_t outputTick = 0;

		using getCUserCmdTickFn = void(__fastcall*)(CCSPlayerController*, int32_t*);
		static auto getCUserCmdTick = (getCUserCmdTickFn)MEM::pGetCUserCmdTick;
		getCUserCmdTick(localPlayer, &outputTick);

		int32_t tick = outputTick - 1;
		if (outputTick == -1)
			tick = -1;

		if (tick < 0) return nullptr;
		if (!MEM::pCUserCmdArray) return nullptr;

		using getCUserCmdArrayFn = CUserCmdArray * (__fastcall*)(CUserCmd**, int);
		static auto getCUserCmdArray = (getCUserCmdArrayFn)MEM::pGetCUserCmdArray;
		auto cmdArray = getCUserCmdArray(*(CUserCmd***)MEM::pCUserCmdArray, tick);

		if (!cmdArray) return nullptr;

		auto sequenceNumber = cmdArray->m_nSequenceNumber();
		if (!sequenceNumber) return nullptr;

		using getCUserCmdBySequenceNumberFn = CUserCmd * (__fastcall*)(CCSPlayerController*, uint32_t);
		static auto getCUserCmdBySequenceNumber = (getCUserCmdBySequenceNumberFn)MEM::pGetCUserCmdBySequenceNumber;
		return getCUserCmdBySequenceNumber(localPlayer, sequenceNumber);
	}

	void ReadFrameInput(int nSlot)
	{
		using ReadFrameInputFn = void(__fastcall*)(CCSGOInput*, int);
		static auto ReadFrameInput = (ReadFrameInputFn)MEM::pReadFrameInput;
		ReadFrameInput(this, nSlot);
	}
};