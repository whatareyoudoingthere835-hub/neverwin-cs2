#pragma once
#include "../../base.hpp"
#include "CBaseHandle.hpp"

class C_BaseEntity;

class CGameEntitySystem
{
public:
	/// GetClientEntity
	template <typename T = C_BaseEntity>
	T* Get(int nIndex)
	{
		return reinterpret_cast<T*>(this->GetEntityByIndex(nIndex, *reinterpret_cast<uintptr_t*>(this + 0x10)));
	}

	/// GetClientEntityFromHandle
	template <typename T = C_BaseEntity>
	T* Get(const CBaseHandle hHandle)
	{
		if (!hHandle.IsValid())
			return nullptr;

		return reinterpret_cast<T*>(this->GetEntityByIndex(hHandle.GetIndex(), *(uintptr_t*)(this + 0x8 * (hHandle.GetEntryIndex() >> 9) + 0x10)));
	}

	int GetHighestEntityIndex()
	{
		return *reinterpret_cast<int*>(reinterpret_cast<std::uintptr_t>(this) + 0x1510);
	}

private:
	void* GetEntityByIndex(int nIndex, uintptr_t entry = 0)
	{
		if (!entry) return nullptr;
		auto entity = *reinterpret_cast<C_BaseEntity**>(entry + (nIndex & 0x1FF) * 0x70);
		return (void*)entity;
	}
};