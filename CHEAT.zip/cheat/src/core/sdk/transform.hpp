#pragma once

// used: matResult
#include "matrix.hpp"
// used: quaternion
#include "vector.hpp"

class CTransform
{
public:
	VectorAligned_t vecPosition;
	QuaternionAligned_t quatOrientation;
};

static_assert(alignof(CTransform) == 16);