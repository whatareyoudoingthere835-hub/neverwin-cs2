#pragma once
#include "../memory/memory.hpp"

class IEngineClient
{
public:
	int GetMaxClients()
	{
		return MEM::VMTCall<int>(this, 35);
	}

	bool IsInGame()
	{
		return MEM::VMTCall<bool>(this, 36);
	}

	bool IsConnected()
	{
		return MEM::VMTCall<bool>(this, 37);
	}

	void ExecuteClientCmd(const char* szCmdString)
	{
		// Currently 40 seems to be the valid index for cs2 based on some sources
		MEM::VMTCall<void>(this, 40, szCmdString);
	}
};
