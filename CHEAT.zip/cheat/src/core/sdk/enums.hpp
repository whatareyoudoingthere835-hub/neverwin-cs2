#pragma once
#include "../../base.hpp"

using ItemDefinitionIndex_t = uint16_t;
enum EItemDefinitionIndexes : ItemDefinitionIndex_t
{
	WEAPON_NONE,
	WEAPON_DESERT_EAGLE,
	WEAPON_DUAL_BERETTAS,
	WEAPON_FIVE_SEVEN,
	WEAPON_GLOCK_18,
	WEAPON_AK_47 = 7,
	WEAPON_AUG,
	WEAPON_AWP,
	WEAPON_FAMAS,
	WEAPON_G3SG1,
	WEAPON_GALIL_AR = 13,
	WEAPON_M249,
	WEAPON_M4A4 = 16,
	WEAPON_MAC_10,
	WEAPON_P90 = 19,
	WEAPON_REPULSOR_DEVICE,
	WEAPON_MP5_SD = 23,
	WEAPON_UMP_45,
	WEAPON_XM1014,
	WEAPON_PP_BIZON,
	WEAPON_MAG_7,
	WEAPON_NEGEV,
	WEAPON_SAWED_OFF,
	WEAPON_TEC_9,
	WEAPON_ZEUS_X27,
	WEAPON_P2000,
	WEAPON_MP7,
	WEAPON_MP9,
	WEAPON_NOVA,
	WEAPON_P250,
	WEAPON_RIOT_SHIELD,
	WEAPON_SCAR_20,
	WEAPON_SG_553,
	WEAPON_SSG_08,
	WEAPON_KNIFE0,
	WEAPON_KNIFE1,
	WEAPON_FLASHBANG,
	WEAPON_HIGH_EXPLOSIVE_GRENADE,
	WEAPON_SMOKE_GRENADE,
	WEAPON_MOLOTOV,
	WEAPON_DECOY_GRENADE,
	WEAPON_INCENDIARY_GRENADE,
	WEAPON_C4_EXPLOSIVE,
	WEAPON_KEVLAR_VEST,
	WEAPON_KEVLAR_and_HELMET,
	WEAPON_HEAVY_ASSAULT_SUIT,
	WEAPON_NO_LOCALIZED_NAME0 = 54,
	WEAPON_DEFUSE_KIT,
	WEAPON_RESCUE_KIT,
	WEAPON_MEDI_SHOT,
	WEAPON_MUSIC_KIT,
	WEAPON_KNIFE2,
	WEAPON_M4A1_S,
	WEAPON_USP_S,
	WEAPON_TRADE_UP_CONTRACT,
	WEAPON_CZ75_AUTO,
	WEAPON_R8_REVOLVER,
	WEAPON_TACTICAL_AWARENESS_GRENADE = 68,
	WEAPON_BARE_HANDS,
	WEAPON_BREACH_CHARGE,
	WEAPON_TABLET = 72,
	WEAPON_KNIFE3 = 74,
	WEAPON_AXE,
	WEAPON_HAMMER,
	WEAPON_WRENCH = 78,
	WEAPON_SPECTRAL_SHIV = 80,
	WEAPON_FIRE_BOMB,
	WEAPON_DIVERSION_DEVICE,
	WEAPON_FRAG_GRENADE,
	WEAPON_SNOWBALL,
	WEAPON_BUMP_MINE,
	WEAPON_BAYONET = 500,
	WEAPON_CLASSIC_KNIFE = 503,
	WEAPON_FLIP_KNIFE = 505,
	WEAPON_GUT_KNIFE,
	WEAPON_KARAMBIT,
	WEAPON_M9_BAYONET,
	WEAPON_HUNTSMAN_KNIFE,
	WEAPON_FALCHION_KNIFE = 512,
	WEAPON_BOWIE_KNIFE = 514,
	WEAPON_BUTTERFLY_KNIFE,
	WEAPON_SHADOW_DAGGERS,
	WEAPON_PARACORD_KNIFE,
	WEAPON_SURVIVAL_KNIFE,
	WEAPON_URSUS_KNIFE,
	WEAPON_NAVAJA_KNIFE,
	WEAPON_NOMAD_KNIFE,
	WEAPON_STILETTO_KNIFE,
	WEAPON_TALON_KNIFE,
	WEAPON_SKELETON_KNIFE = 525,
};

enum e_bones {
	BONE_HIP = 1,                 // PELVIS (был 0x0)
	BONE_SPINE = 2,               // SPINE0 (был 0x1)
	BONE_SPINE1 = 3,              // SPINE1 (был 0x2)
	BONE_SPINE2 = 4,              // SPINE2 (был 0x3)
	BONE_SPINE3 = 23,             // CHEST (в старой структуре часто был 0x4)
	BONE_NECK = 6,                // NECK (был 0x5)
	BONE_HEAD = 7,                // HEAD (был 0x6)

	// Левая рука
	BONE_LEFT_UPPER_ARM = 9,      // SHOULDER_L (был 0x8)
	BONE_LEFT_LOWER_ARM = 10,     // ELBOW_L (был 0x9)
	BONE_LEFT_ARM = 11,           // HAND_L (был 0xA)

	// Правая рука
	BONE_RIGHT_UPPER_ARM = 13,    // SHOULDER_R (был 0xD)
	BONE_RIGHT_LOWER_ARM = 14,    // ELBOW_R (был 0xE)
	BONE_RIGHT_ARM = 15,          // HAND_R (был 0xF)

	// Левая нога
	BONE_LEFT_UPPER_LEG = 17,     // HIP_L (был 0x16)
	BONE_LEFT_LOWER_LEG = 18,     // KNEE_L (был 0x17)
	BONE_LEFT_ANKLE = 19,         // FOOT_HEEL_L (был 0x18)

	// Правая нога
	BONE_RIGHT_UPPER_LEG = 20,    // HIP_R (был 0x19)
	BONE_RIGHT_LOWER_LEG = 21,    // KNEE_R (был 0x1A)
	BONE_RIGHT_ANKLE = 22,        // FOOT_HEEL_R (был 0x1B)

	//// Дополнительные (полезные для CS2)
	//BONE_EYE_L = 25,
	//BONE_EYE_R = 26,
	//BONE_CHEST = 23
};

constexpr e_bones all_bones[] = {
	BONE_SPINE,
	BONE_SPINE1,
	BONE_SPINE2,
	BONE_SPINE3,
	BONE_NECK,
	BONE_HEAD,
	BONE_LEFT_UPPER_ARM,
	BONE_LEFT_LOWER_ARM,
	BONE_LEFT_ARM,
	BONE_RIGHT_UPPER_ARM,
	BONE_RIGHT_LOWER_ARM,
	BONE_RIGHT_ARM,
	BONE_LEFT_UPPER_LEG ,
	BONE_LEFT_LOWER_LEG ,
	BONE_LEFT_ANKLE ,
	BONE_RIGHT_UPPER_LEG ,
	BONE_RIGHT_LOWER_LEG ,
	BONE_RIGHT_ANKLE ,
};

enum e_hitgroups
{
	hitgroup_gear,
	hitgroup_head,
	hitgroup_chest,
	hitgroup_stomach,
	hitgroup_left_hand,
	hitgroup_right_hand,
	hitgroup_left_leg,
	hitgroup_right_leg,
	hitgroup_neck
};
enum e_hitboxes {
	/* HEAD */
	HITBOX_HEAD,
	HITBOX_NECK,
	/* BODY */
	HITBOX_PELVIS,
	HITBOX_STOMACH,
	HITBOX_CHEST,
	HITBOX_LOWER_CHEST,
	HITBOX_UPPER_CHEST,
	/* LEGS */
	HITBOX_RIGHT_THIGH,
	HITBOX_LEFT_THIGH,
	HITBOX_RIGHT_CALF,
	HITBOX_LEFT_CALF,
	HITBOX_RIGHT_FOOT,
	HITBOX_LEFT_FOOT,
	/* ARMS */
	HITBOX_RIGHT_HAND,
	HITBOX_LEFT_HAND,
	HITBOX_RIGHT_UPPER_ARM,
	HITBOX_RIGHT_FOREARM,
	HITBOX_LEFT_UPPER_ARM,
	HITBOX_LEFT_FOREARM,
	HITBOX_MAX
};
constexpr e_hitboxes all_hitboxes[] =
{
	/* HEAD */
	HITBOX_HEAD, //(3,3) 2 s, e OR 1 c
	HITBOX_NECK, //(1 45) 1 c
	/* BODY */
	HITBOX_PELVIS, // 2 s, c, e
	HITBOX_STOMACH, // 2 s, c, e
	HITBOX_CHEST, // 2 s, c, e 
	HITBOX_LOWER_CHEST, // 2 s, c, e
	HITBOX_UPPER_CHEST, // 2 s, c, e
	/* LEGS */
	HITBOX_RIGHT_THIGH, // 4 in all * 2
	HITBOX_LEFT_THIGH,
	HITBOX_RIGHT_CALF,
	HITBOX_LEFT_CALF,
	HITBOX_RIGHT_FOOT, // 1 e * 2
	HITBOX_LEFT_FOOT,
	/* ARMS */
	HITBOX_RIGHT_HAND,  // 1 e * 2
	HITBOX_LEFT_HAND,
	HITBOX_RIGHT_UPPER_ARM, // 3 in all * 2
	HITBOX_RIGHT_FOREARM,
	HITBOX_LEFT_UPPER_ARM,
	HITBOX_LEFT_FOREARM,
};

enum EWeaponType : std::uint32_t
{
	WEAPONTYPE_KNIFE = 0,
	WEAPONTYPE_PISTOL = 1,
	WEAPONTYPE_SUBMACHINEGUN = 2,
	WEAPONTYPE_RIFLE = 3,
	WEAPONTYPE_SHOTGUN = 4,
	WEAPONTYPE_SNIPER_RIFLE = 5,
	WEAPONTYPE_MACHINEGUN = 6,
	WEAPONTYPE_C4 = 7,
	WEAPONTYPE_TASER = 8,
	WEAPONTYPE_GRENADE = 9,
	WEAPONTYPE_EQUIPMENT = 10,
	WEAPONTYPE_STACKABLEITEM = 11,
	WEAPONTYPE_FISTS = 12,
	WEAPONTYPE_BREACHCHARGE = 13,
	WEAPONTYPE_BUMPMINE = 14,
	WEAPONTYPE_TABLET = 15,
	WEAPONTYPE_MELEE = 16,
	WEAPONTYPE_SHIELD = 17,
	WEAPONTYPE_ZONE_REPULSOR = 18,
	WEAPONTYPE_UNKNOWN = 19
};

enum EFlags : int
{
	FL_ONGROUND = (1 << 0), // entity is at rest / on the ground
	FL_DUCKING = (1 << 1), // player is fully crouched/uncrouched
	FL_ANIMDUCKING = (1 << 2), // player is in the process of crouching or uncrouching but could be in transition
	FL_WATERJUMP = (1 << 3), // player is jumping out of water
	FL_ONTRAIN = (1 << 4), // player is controlling a train, so movement commands should be ignored on client during prediction
	FL_INRAIN = (1 << 5), // entity is standing in rain
	FL_FROZEN = (1 << 6), // player is frozen for 3rd-person camera
	FL_ATCONTROLS = (1 << 7), // player can't move, but keeps key inputs for controlling another entity
	FL_CLIENT = (1 << 8), // entity is a client (player)
	FL_FAKECLIENT = (1 << 9), // entity is a fake client, simulated server side; don't send network messages to them
	FL_INWATER = (1 << 10), // entity is in water
	FL_FLY = (1 << 11),
	FL_SWIM = (1 << 12),
	FL_CONVEYOR = (1 << 13),
	FL_NPC = (1 << 14),
	FL_GODMODE = (1 << 15),
	FL_NOTARGET = (1 << 16),
	FL_AIMTARGET = (1 << 17),
	FL_PARTIALGROUND = (1 << 18), // entity is standing on a place where not all corners are valid
	FL_STATICPROP = (1 << 19), // entity is a static property
	FL_GRAPHED = (1 << 20),
	FL_GRENADE = (1 << 21),
	FL_STEPMOVEMENT = (1 << 22),
	FL_DONTTOUCH = (1 << 23),
	FL_BASEVELOCITY = (1 << 24), // entity have applied base velocity this frame
	FL_WORLDBRUSH = (1 << 25), // entity is not moveable/removeable brush (part of the world, but represented as an entity for transparency or something)
	FL_OBJECT = (1 << 26),
	FL_KILLME = (1 << 27), // entity is marked for death and will be freed by the game
	FL_ONFIRE = (1 << 28),
	FL_DISSOLVING = (1 << 29),
	FL_TRANSRAGDOLL = (1 << 30), // entity is turning into client-side ragdoll
	FL_UNBLOCKABLE_BY_PLAYER = (1 << 31)
};

using VisualChamMaterial_t = int;
enum EVisualsChamMaterials : VisualChamMaterial_t
{
	VISUAL_MATERIAL_PRIMARY_WHITE = 0,
	VISUAL_MATERIAL_ILLUMINATE,
	VISUAL_MATERIAL_MAX
};
