#pragma once
#include "../../base.hpp"
#include "../memory/memory.hpp"

#define TICK_INTERVAL 0.015625f
#define TIME_TO_TICKS(TIME) (static_cast<int>(0.5f + static_cast<float>(TIME) / TICK_INTERVAL))
#define TICKS_TO_TIME(TICKS) (TICK_INTERVAL * static_cast<float>(TICKS))
#define ROUND_TO_TICKS(TIME) (TICK_INTERVAL * TIME_TO_TICKS(TIME))
#define TICK_NEVER_THINK (-1)

struct timestamp_t {
	int m_tick;
	float m_frac;

	timestamp_t() = default;

	timestamp_t(int m_tick, float m_frac)
	{
		this->m_tick = m_tick;
		this->m_frac = m_frac;
	}

	timestamp_t(float time) {
		auto temp = std::fmodf(time, TICK_INTERVAL);
		m_frac = temp * 64;
		m_tick = TIME_TO_TICKS(time - temp);
	}
};
static_assert(sizeof(timestamp_t) == 0x8);

// @source: server.dll
enum ECommandButtons : uint64_t
{
	IN_ATTACK = 1 << 0,
	IN_JUMP = 1 << 1,
	IN_DUCK = 1 << 2,
	IN_FORWARD = 1 << 3,
	IN_BACK = 1 << 4,
	IN_USE = 1 << 5,
	IN_LEFT = 1 << 7,
	IN_RIGHT = 1 << 8,
	IN_MOVELEFT = 1 << 9,
	IN_MOVERIGHT = 1 << 10,
	IN_SECOND_ATTACK = 1 << 11,
	IN_RELOAD = 1 << 13,
	IN_SPRINT = 1 << 16,
	IN_JOYAUTOSPRINT = 1 << 17,
	IN_SHOWSCORES = 1ULL << 33,
	IN_ZOOM = 1ULL << 34,
	IN_LOOKATWEAPON = 1ULL << 35
};

template <typename T>
struct RepeatedPtrField_t
{
	struct Rep_t
	{
		int nAllocatedSize;
		T* tElements[(INT_MAX - 2 * sizeof(int)) / sizeof(void*)];
	};

	void* pArena;
	int nCurrentSize;
	int nTotalSize;
	Rep_t* pRep;

	template <typename T>
	T* add(T* element)
	{
		static auto add_to_rep_addr = reinterpret_cast<T * (__fastcall*)(RepeatedPtrField_t*, T*)>(MEM::padd_to_rep_addr);
		return add_to_rep_addr(this, element);
	}
};

class CBasePB
{
public:
	MEM_PAD(0x8);
	uint32_t nHasBits;
	uint64_t nCachedBits;

	void SetField(int fieldNum)
	{
		nHasBits |= (1 << fieldNum);
	}
};
static_assert(sizeof(CBasePB) == 0x18);

class CMsgQAngle : public CBasePB
{
public:
	vector_t angValue;
};
static_assert(sizeof(CMsgQAngle) == 0x28);

class CMsgVector : public CBasePB
{
public:
	vector_t vecValue;
};
static_assert(sizeof(CMsgVector) == 0x28);

class CCSGOInterpolationInfoPB : public CBasePB
{
public:
	float flFraction;
	int nSrcTick;
	int nDstTick;
};
static_assert(sizeof(CCSGOInterpolationInfoPB) == 0x28);

class CCSGOInputHistoryEntryPB : public CBasePB
{
public:
	CMsgQAngle* pViewAngles;
	CCSGOInterpolationInfoPB* cl_interp;
	CCSGOInterpolationInfoPB* sv_interp0;
	CCSGOInterpolationInfoPB* sv_interp1;
	CCSGOInterpolationInfoPB* player_interp;
	CMsgVector* pShootPosition;
	CMsgVector* pTargetHeadPositionCheck;
	CMsgVector* pTargetAbsPositionCheck;
	CMsgQAngle* pTargetAngPositionCheck;
	timestamp_t renderStamp;
	timestamp_t playerStamp;
	int nFrameNumber;
	int nTargetEntIndex;
};
static_assert(sizeof(CCSGOInputHistoryEntryPB) == 0x78);

struct CInButtonStatePB : CBasePB
{
	uint64_t nValue;
	uint64_t nValueChanged;
	uint64_t nValueScroll;
};
static_assert(sizeof(CInButtonStatePB) == 0x30);

struct CSubtickMoveStep : CBasePB
{
public:
	uint64_t nButton;
	bool bPressed;
	float flWhen;
	float flAnalogForwardDelta;
	float flAnalogLeftDelta;
};
static_assert(sizeof(CSubtickMoveStep) == 0x30);

class CBaseUserCmdPB : public CBasePB
{
public:
	RepeatedPtrField_t<CSubtickMoveStep> subtickMovesField;
	char* strMoveCrc;
	CInButtonStatePB* pInButtonState;
	CMsgQAngle* pViewAngles;
	char** ignoredReason;
	int32_t nLegacyCommandNumber;
	int32_t nClientTick;
	//float pad0;
	//float pad1;
	float flForwardMove;
	float flSideMove;
	float flUpMove;
	int32_t nImpulse;
	int32_t nWeaponSelect;
	int32_t nRandomSeed;
	int32_t nMousedX;
	int32_t nMousedY;
	unsigned int m_prediction_offset_ticks_x256;
	uint32_t nConsumedServerAngleChanges;
	int32_t nCmdFlags;
	uint32_t nPawnEntityHandle;

	CSubtickMoveStep* add_subtick_move()
	{
		using fn_add_subtick_move_step = CSubtickMoveStep * (__fastcall*)(void*);
		static fn_add_subtick_move_step fn_create_new_subtick_move_step = reinterpret_cast<fn_add_subtick_move_step>(MEM::padd_subtick_move_step);

		if (subtickMovesField.pRep && subtickMovesField.nCurrentSize < subtickMovesField.pRep->nAllocatedSize)
			return subtickMovesField.pRep->tElements[subtickMovesField.nCurrentSize++];

		CSubtickMoveStep* subtick = fn_create_new_subtick_move_step(nullptr);
		subtickMovesField.add(subtick);

		return subtick;
	}
};
static_assert(sizeof(CBaseUserCmdPB) == 0x88);

class CCSGOUserCmdPB : CBasePB
{
public:
	RepeatedPtrField_t<CCSGOInputHistoryEntryPB> inputHistoryField;
	CBaseUserCmdPB* pBaseCmd;
	bool bLeftHandDesired;
	int32_t nAttack1StartHistoryIndex;
	int32_t nAttack2StartHistoryIndex;

	CCSGOInputHistoryEntryPB* add_input_history()
	{
		using fn_create_new_input_history = CCSGOInputHistoryEntryPB * (__fastcall*)(void*);
		static auto create_new_input_history = reinterpret_cast<fn_create_new_input_history>(MEM::pcreate_new_input_history);

		if (inputHistoryField.pRep && inputHistoryField.nCurrentSize < inputHistoryField.pRep->nAllocatedSize)
			return inputHistoryField.pRep->tElements[inputHistoryField.nCurrentSize++];

		CCSGOInputHistoryEntryPB* history = create_new_input_history(nullptr);
		inputHistoryField.add(history);

		return history;
	}

	CCSGOInputHistoryEntryPB* GetInputHistoryEntry(int nIndex)
	{
		if (nIndex >= inputHistoryField.pRep->nAllocatedSize || nIndex >= inputHistoryField.nCurrentSize)
			return nullptr;

		return inputHistoryField.pRep->tElements[nIndex];
	}

	void SetSubTickAngle(const vector_t& angView)
	{
		for (int i = 0; i < this->inputHistoryField.pRep->nAllocatedSize; i++)
		{
			CCSGOInputHistoryEntryPB* pInputEntry = this->GetInputHistoryEntry(i);
			if (!pInputEntry || !pInputEntry->pViewAngles)
				continue;
			pInputEntry->pViewAngles->angValue = angView;
		}
	}

	void Attack(int playerTick, int attack, vector_t aimAngle)
	{
		CCSGOInputHistoryEntryPB* pInputEntry = this->GetInputHistoryEntry(0);
		if (!pInputEntry || !pInputEntry->pViewAngles)
			return;
		pInputEntry->pViewAngles->angValue = aimAngle;
		pInputEntry->playerStamp.m_tick = playerTick;
		this->SetAttackHistory(attack, 0);
	}

	void SetAttackHistory(int attack, int value)
	{
		((int32_t*)(&this->nAttack1StartHistoryIndex))[attack - 1] = value;
		this->SetField(5 + attack - 1);
	}
};
static_assert(sizeof(CCSGOUserCmdPB) == 0x48);

struct CInButtonState
{
public:
	MEM_PAD(0x8);
	uint64_t nValue;
	uint64_t nValueChanged;
	uint64_t nValueScroll;
};
static_assert(sizeof(CInButtonState) == 0x20);

class CUserCmd
{
public:
	MEM_PAD(0x8);
	int cmdNum;
	CCSGOUserCmdPB csgoUserCmd;
	CInButtonState nButtons;
	MEM_PAD(0x8);
	MEM_PAD(0x8);
	MEM_PAD(0x10);
};
static_assert(sizeof(CUserCmd) == 0x98);
