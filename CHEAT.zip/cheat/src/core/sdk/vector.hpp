#pragma once
#include <cmath>

inline constexpr float PI = 3.141592654f;
inline constexpr float epsilon = 1e-7f;

#define M_DEG2RAD(DEGREES) ((DEGREES) * (PI / 180.f))
#define M_RAD2DEG(RADIANS) ((RADIANS) * (180.f / PI))

struct vector_t
{ 
	float x, y, z;

	constexpr vector_t(const float x = 0.0f, const float y = 0.0f, const float z = 0.0f) :
		x(x), y(y), z(z) {}

	constexpr vector_t(const float* arrVector) :
		x(arrVector[0]), y(arrVector[1]), z(arrVector[2]) {}

	vector_t operator*(float a)
	{
		return { this->x * a, this->y * a, this->z * a };
	}

	vector_t operator/(const float flDivide)
	{
		return { this->x / flDivide, this->y / flDivide, this->z / flDivide };
	}

	vector_t operator+(vector_t a)
	{
		return { this->x + a.x, this->y + a.y, this->z + a.z };
	}

	vector_t operator-(vector_t a)
	{
		return { this->x - a.x, this->y - a.y, this->z - a.z };
	}

	vector_t& operator-=(const vector_t& angBase)
	{
		this->x -= angBase.x;
		this->y -= angBase.y;
		this->z -= angBase.z;
		return *this;
	}

	vector_t& operator+=(const vector_t& angBase)
	{
		this->x += angBase.x;
		this->y += angBase.y;
		this->z += angBase.z;
		return *this;
	}

	float length()
	{
		return sqrtf(x * x + y * y + z * z);
	}

	vector_t normalize()
	{
		const float len = this->length();
		const float flRadius = 1 / len;
		this->x *= flRadius;
		this->y *= flRadius;
		this->z *= flRadius;
		return *this;
	}

	vector_t get_normal(vector_t point)
	{
		return (point - *this).normalize();
	}

	vector_t to_angles()
	{
		float flPitch, flYaw;
		if (this->x == 0.0f && this->y == 0.0f)
		{
			flPitch = (this->z > 0.0f) ? 270.f : 90.f;
			flYaw = 0.0f;
		}
		else
		{
			flPitch = M_RAD2DEG(std::atan2f(-this->z, this->length()));

			if (flPitch < 0.f)
				flPitch += 360.f;

			flYaw = M_RAD2DEG(std::atan2f(this->y, this->x));

			if (flYaw < 0.f)
				flYaw += 360.f;
		}

		return { flPitch, flYaw, 0.0f };
	}

	constexpr float dot_product(const vector_t& vecDot) const
	{
		return (this->x * vecDot.x + this->y * vecDot.y + this->z * vecDot.z);
	}
};

template<typename T>
struct CUtlVector
{
	int nSize;
	T* pElements;
};

static void AngleVectors(const vector_t angles, vector_t* forward, vector_t* right = nullptr, vector_t* up = nullptr) {
	float sp, sy, cp, cy, sr, cr;
	float pitch = angles.x * (PI / 180.0f);
	float yaw = angles.y * (PI / 180.0f);
	float roll = angles.z * (PI / 180.0f);

	sp = sin(pitch); cp = cos(pitch);
	sy = sin(yaw);   cy = cos(yaw);
	sr = sin(roll);  cr = cos(roll);

	if (forward) {
		forward->x = cp * cy;
		forward->y = cp * sy;
		forward->z = -sp;
	}

	if (right) {
		right->x = -1 * sr * sp * cy + -1 * cr * -sy;
		right->y = -1 * sr * sp * sy + -1 * cr * cy;
		right->z = -1 * sr * cp;
	}

	if (up) {
		up->x = cr * sp * cy + -sr * -sy;
		up->y = cr * sp * sy + -sr * cy;
		up->z = cr * cp;
	}
}

struct ResourceBinding_t
{
	void* pData;
};

template <typename T>
class CStrongHandle
{
public:
	operator T* () const
	{
		if (pBinding == nullptr)
			return nullptr;

		return static_cast<T*>(pBinding->pData);
	}

	T* operator->() const
	{
		if (pBinding == nullptr)
			return nullptr;

		return static_cast<T*>(pBinding->pData);
	}

	const ResourceBinding_t* pBinding;
};

struct quaternion_t
{
	constexpr quaternion_t(const float x = 0.0f, const float y = 0.0f, const float z = 0.0f, const float w = 0.0f) :
		x(x), y(y), z(z), w(w) {
	}

	bool IsValid() const
	{
		return (std::isfinite(x) && std::isfinite(y) && std::isfinite(z) && std::isfinite(w));
	}

	float x, y, z, w;
};

struct alignas(16) VectorAligned_t : vector_t
{
	VectorAligned_t() = default;

	explicit VectorAligned_t(const vector_t& vecBase)
	{
		this->x = vecBase.x;
		this->y = vecBase.y;
		this->z = vecBase.z;
		this->w = 0.0f;
	}

	constexpr VectorAligned_t& operator=(const vector_t& vecBase)
	{
		this->x = vecBase.x;
		this->y = vecBase.y;
		this->z = vecBase.z;
		this->w = 0.0f;
		return *this;
	}

	float w = 0.0f;
};
static_assert(alignof(VectorAligned_t) == 16);

struct alignas(16) QuaternionAligned_t : quaternion_t
{
	QuaternionAligned_t& operator=(const quaternion_t& quatOther)
	{
		this->x = quatOther.x;
		this->y = quatOther.y;
		this->z = quatOther.z;
		this->w = quatOther.w;
		return *this;
	}
};
static_assert(alignof(QuaternionAligned_t) == 16);