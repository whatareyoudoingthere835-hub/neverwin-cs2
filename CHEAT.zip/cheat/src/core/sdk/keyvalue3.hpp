#pragma once
#include "../memory/memory.hpp"
#include "utlbuffer.hpp"

struct KV3ID_t
{
	const char* szName;
	uint64_t unk0;
	uint64_t unk1;
};

class CKeyValues3
{
public:
	MEM_PAD(0x100);
	uint64_t uKey;
	void* pValue;
	MEM_PAD(0x8);

	inline void LoadFromBuffer(const char* szString)
	{
		CUtlBuffer buffer(0, (strlen(szString) + 10), 1);
		buffer.PutString(szString);
		LoadKV3(&buffer);
	}

	inline bool LoadKV3(CUtlBuffer* buffer)
	{
		using fnLoadKeyValues = bool(__fastcall*)(CKeyValues3*, void*, CUtlBuffer*, KV3ID_t*, void*, void*, void*, void*, const char*);
		static const fnLoadKeyValues oLoadKeyValues = reinterpret_cast<fnLoadKeyValues>(MEM::pLoadKeyValues);

		const char* szName = CS_XOR("");
		KV3ID_t kv3ID = KV3ID_t(CS_XOR("generic"), 0x41B818518343427E, 0xB5F447C23C0CDF8C);
		return oLoadKeyValues(this, nullptr, buffer, &kv3ID, nullptr, nullptr, nullptr, nullptr, CS_XOR(""));
	}

	static CKeyValues3* CreateMaterialResource()
	{
		using fnSetTypeKV3 = CKeyValues3 * (__fastcall*)(CKeyValues3*, unsigned int, unsigned int);
		static const fnSetTypeKV3 oSetTypeKV3 = reinterpret_cast<fnSetTypeKV3>(MEM::pSetTypeKV3);

		CKeyValues3* pKeyValue = new CKeyValues3[0x10];
		return oSetTypeKV3(pKeyValue, 1U, 6U);
	}
};
