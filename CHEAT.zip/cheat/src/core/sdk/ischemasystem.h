#pragma once
#include "../memory/memory.hpp"
#include "vector.hpp"
#include "utlhash.hpp"

#define SCHEMASYSTEM_TYPE_SCOPES_OFFSET 0x188
#define SCHEMASYSTEMTYPESCOPE_OFF1 0x3F8
#define SCHEMASYSTEMTYPESCOPE_OFF2 0x8

using SchemaString_t = const char*;
struct SchemaMetadataEntryData_t;

class CSchemaSystemTypeScope;
class CSchemaType;

struct CSchemaClassBinding
{
	CSchemaClassBinding* pParent;
	const char* szBinaryName;
	const char* szModuleName;
	const char* szClassName;
	void* pClassInfoOldSynthesized;
	void* pClassInfo;
	void* pThisModuleBindingPointer;
	CSchemaType* pSchemaType;
};

class CSchemaType
{
public:
	bool GetSizes(int* pOutSize, uint8_t* unkPtr)
	{
		return MEM::VMTCall<bool>(this, 3, pOutSize, unkPtr);
	}

public:
	bool GetSize(int* out_size)
	{
		uint8_t smh = 0;
		return GetSizes(out_size, &smh);
	}

public:
	void* pVtable;
	const char* szName;

	CSchemaSystemTypeScope* pSystemTypeScope;
	uint8_t nTypeCategory;
	uint8_t nAatomicCategory;
};

struct SchemaClassFieldData_t
{
	SchemaString_t szName;
	CSchemaType* pSchemaType;
	std::uint32_t nSingleInheritanceOffset;
	std::int32_t nMetadataSize;
	SchemaMetadataEntryData_t* pMetaData;
};

struct SchemaClassInfoData_t;

struct SchemaBaseClassInfoData_t
{
	int32_t nOffset;
	SchemaClassInfoData_t* pClass;
};

struct SchemaClassInfoData_t
{
private:
	void* pVtable;                          // 0x0000
public:
	const char* szName;                         // 0x0008
	char* szDescription;                        // 0x0010
	void* pUnk0018;                             // 0x0018
	int32_t m_nSize;                            // 0x0020
	int16_t nFieldSize;                         // 0x0024
	int16_t nStaticSize;                        // 0x0026
	int16_t nMetadataSize;                      // 0x0028 (0x01FF = 511)
	uint8_t nAlignOf;                           // 0x002A (0x04)
	uint8_t nBaseClassesCount;                  // 0x002B (0x00)
	int32_t nUnk002C;                           // 0x002C (3)
	SchemaClassFieldData_t* pFields;            // 0x0030 (0 = NULL для этого класса)
	char pad0038[0x8];                          // 0x0034 + 0x0038
	SchemaBaseClassInfoData_t* pBaseClasses;    // 0x0038
	char pad0040[0x8];                          // 0x0040
	void* pUnk0048;                             // 0x0048
	char pad0050[0x8];                          // 0x004C + 0x0050... 
	CSchemaSystemTypeScope* pTypeScope;         // 0x0050
	CSchemaType* pDeclaredClass;				// 0x0058
	int32_t nUnk0060;                           // 0x0060
	int32_t nUnk0064;                           // 0x0064
	void* pUnk0068;                             // 0x0068
	void* pUnk0070;                             // 0x0070

	bool InheritsFrom(SchemaClassInfoData_t* pClassInfo)
	{
		if (pClassInfo == this && pClassInfo != nullptr)
			return true;
		else if (pBaseClasses == nullptr || pClassInfo == nullptr)
			return false;

		for (int i = 0; i < nBaseClassesCount; i++)
		{
			auto& baseClass = pBaseClasses[i];
			if (baseClass.pClass->InheritsFrom(pClassInfo))
				return true;
		}

		return false;
	}
};


struct SchemaEnumeratorInfoData_t
{
	SchemaString_t szName;

	union
	{
		unsigned char value_char;
		unsigned short value_short;
		unsigned int value_int;
		unsigned long long value;
	};

	MEM_PAD(0x10);
};

class CSchemaEnumInfo
{
public:
	SchemaEnumeratorInfoData_t enumInfoData;
};

class CSchemaEnumBinding
{
public:
	virtual const char* GetBindingName() = 0;
	virtual CSchemaClassBinding* AsClassBinding() = 0;
	virtual CSchemaEnumBinding* AsEnumBinding() = 0;
	virtual const char* GetBinaryName() = 0;
	virtual const char* GetProjectName() = 0;

public:
	char* szBindingName_;
	char* szDllName_;
	std::int8_t nAlign_; 
	MEM_PAD(0x3);
	std::int16_t nSize_;
	std::int16_t nFlags_;
	SchemaEnumeratorInfoData_t* pEnumInfo_;
	MEM_PAD(0x8);
	CSchemaSystemTypeScope* pTypeScope_;
	MEM_PAD(0x8);
	std::int32_t unk1_;
};

class CSchemaSystemTypeScope
{
public:
	void FindDeclaredClass(SchemaClassInfoData_t** pReturnClass, const char* szClassName)
	{
		return MEM::VMTCall<void>(this, 2, pReturnClass, szClassName);
	}

	CSchemaType* FindSchemaTypeByName(const char* szName, std::uintptr_t* pSchema)
	{
		return MEM::VMTCall<CSchemaType*>(this, 4, szName, pSchema);
	}

	CSchemaType* FindTypeDeclaredClass(const char* szName)
	{
		return MEM::VMTCall<CSchemaType*>(this, 5, szName);
	}

	CSchemaType* FindTypeDeclaredEnum(const char* szName)
	{
		return MEM::VMTCall<CSchemaType*>(this, 6, szName);
	}

	CSchemaClassBinding* FindRawClassBinding(const char* szName)
	{
		return MEM::VMTCall<CSchemaClassBinding*>(this, 7, szName);
	}

	void* pVtable; // 0x0000
	char szName[256U]; // 0x0008
	MEM_PAD(0x458); // 0x0108 SCHEMASYSTEMTYPESCOPE_OFF1
	CUtlTSHash<CSchemaClassBinding*, 256, unsigned int> hashClasses; // 0x560
	MEM_PAD(SCHEMASYSTEMTYPESCOPE_OFF2); // 0x05C8 ?
	CUtlTSHash<CSchemaEnumBinding*, 256, unsigned int> hashEnumes; // 0x2DD0 ?
};

class ISchemaSystem
{
public:
	CSchemaSystemTypeScope* FindTypeScopeForModule(const char* m_module_name)
	{
		return MEM::VMTCall<CSchemaSystemTypeScope*>(this, 13, m_module_name, nullptr);
	}

private:
	MEM_PAD(SCHEMASYSTEM_TYPE_SCOPES_OFFSET); // 0x0000
public:
	// table of type scopes
	CUtlVector<CSchemaSystemTypeScope*> vecTypeScopes; // SCHEMASYSTEM_TYPE_SCOPES_OFFSET
};
