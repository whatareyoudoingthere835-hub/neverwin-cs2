#pragma once
#include "../../ext/imgui/imgui.h"
#include <vector>
#include <string>
#include <map>

namespace Settings
{
    // Aimbot - Aim Assist
    inline bool aimbot_enabled = false;
    inline float aimbot_fov = 5.0f;
    inline float aimbot_smooth = 1.0f;
    inline bool aimbot_humanized = false;
    inline float aimbot_hitchance = 0.0f;
    inline int aimbot_bones = 0; // 0 = Head, 1 = Neck, 2 = Chest

    // Aimbot - Trigger
    inline bool trigger_enabled = false;
    inline float trigger_fov = 1.0f;
    inline float trigger_hitchance = 0.0f;
    inline bool trigger_seeded = false;

    // Visuals
    inline bool esp_enabled = false;
    inline bool esp_show_team = false;
    inline float esp_scale = 1.0f;
    inline float esp_max_dist = 4000.0f;
    
    inline bool esp_box = false;
    inline int esp_box_style = 0; // 0=Corner, 1=Outline, 2=Coal, 3=Filled
    inline bool esp_box_shadow = false;
    inline float esp_box_thick = 1.0f;
    inline ImVec4 esp_team_col = ImVec4(0.31f, 0.55f, 1.0f, 0.9f);
    inline ImVec4 esp_enemy_col = ImVec4(1.0f, 0.35f, 0.35f, 0.9f);

    inline bool esp_name = false;
    inline float esp_name_size = 14.0f;

    inline bool esp_health = false;
    inline int esp_health_style = 0; // 0=Gradient, 1=Solid Green, 2=Box Color
    inline int esp_health_pos = 0; // 0=Left, 1=Top, 2=Right
    
    inline bool esp_lines = false;
    inline int esp_line_anchor = 1; // 0=Top, 1=Center, 2=Bottom
    
    inline bool esp_weapon = false;
    inline bool esp_weapon_icon = false;
    inline bool esp_ammo = false;
    inline int esp_ammo_style = 0;
    inline ImVec4 esp_ammo_col1 = ImVec4(0.2f, 0.8f, 0.9f, 0.96f);
    inline ImVec4 esp_ammo_col2 = ImVec4(0.8f, 0.2f, 0.9f, 0.96f);

    inline bool esp_flags = false; // For Flashed, Defusing, Planting, etc.
    
    inline bool fov_enabled = false;
    inline float fov_value = 90.0f;
    
    inline bool hitmarker_enabled = false;
    inline float hitmarker_duration = 0.4f;
    inline bool hitsound_enabled = false;
    inline int hitsound_idx = 0;
    inline std::vector<std::string> hitsound_list;

    inline bool soundpuddle_enabled = false;
    inline float soundpuddle_scale = 1.0f;
    inline float soundpuddle_alpha = 1.0f;
    
    inline bool tracers_enabled = false;
    inline ImVec4 tracers_col = ImVec4(1.0f, 0.8f, 0.1f, 1.0f);
    // Chams
    inline bool chams_enabled = false;
    inline ImVec4 chams_color = { 1.0f, 1.0f, 1.0f, 1.0f };
    inline bool chams_invisible = false;
    inline ImVec4 chams_invisible_color = { 1.0f, 0.0f, 0.0f, 1.0f };

    // Movement & Misc
    inline bool movement_bhop = false;
    inline bool misc_hitlogs = false;
    inline int misc_hitlogs_output = 0; // 0 = Screen, 1 = Chat
    inline bool misc_hitlogs_console = true;

    // Watermark widgets
    inline bool watermark_time = true;
    inline bool watermark_fps = true;
    inline bool watermark_ram = true;
    inline bool watermark_spotify = false;
    inline bool watermark_netspd = false;
    inline bool watermark_quote = false;
    inline bool watermark_mood = false;
    inline bool watermark_keypress = false;
    inline ImVec4 watermark_color = { 0.125f, 0.843f, 0.376f, 1.0f };
    
    // Spotify credentials
    inline char spotify_client_id[ 128 ] = "";
    inline char spotify_client_secret[ 128 ] = "";
    inline char spotify_refresh_token[ 512 ] = "";

    // Skinchanger
    inline bool skinchanger_knife_enabled = false;
    inline int skinchanger_knife_model = 0;
    inline float skinchanger_knife_paint_kit = 0.0f;
    inline float skinchanger_knife_wear = 0.001f;

    inline bool skinchanger_glove_enabled = false;
    inline int skinchanger_glove_model = 0;
    inline float skinchanger_glove_paint_kit = 0.0f;
    inline float skinchanger_glove_wear = 0.001f;

    inline bool skinchanger_enabled = false;

    // World Particles — 0=None 1=Ashes 2=Snow 3=Stars 4=Rain
    inline int   particles_type    = 0;
    inline float particles_density = 1.0f;
}
