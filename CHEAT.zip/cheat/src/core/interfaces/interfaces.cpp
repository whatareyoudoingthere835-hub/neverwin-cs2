#include "interfaces.hpp"
#include "../memory/memory.hpp"

#include "../sdk/panorama.hpp"

// https://github.com/sezzyaep/CS2-OFFSETS/blob/main/interfaces.cs
#define SCHEMA_SYSTEM CS_XOR("SchemaSystem_001")
#define GAME_RESOURCE_SERVICE_CLIENT CS_XOR("GameResourceServiceClientV001")
#define INPUT_SYSTEM_VERSION CS_XOR("InputSystemVersion001")
#define SOURCE2_ENGINE_TO_CLIENT CS_XOR("Source2EngineToClient001")
#define PANORAMA_UI_ENGINE CS_XOR("PanoramaUIEngine001")

void I::Init()
{
	SchemaSystem = CreateInterface<ISchemaSystem>(SCHEMA_SYSTEM_DLL, SCHEMA_SYSTEM);
	GameResourceService = CreateInterface<IGameResourceService>(ENGINE2_DLL, GAME_RESOURCE_SERVICE_CLIENT);
	InputSystem = CreateInterface<IInputSystem>(INPUTSYSTEM_DLL, INPUT_SYSTEM_VERSION);
	EngineClient = CreateInterface<IEngineClient>(ENGINE2_DLL, SOURCE2_ENGINE_TO_CLIENT);
	PanoramaUIEngine = CreateInterface<i_panorama_ui_engine>("panorama.dll", PANORAMA_UI_ENGINE);
}