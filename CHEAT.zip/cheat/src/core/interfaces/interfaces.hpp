#pragma once
#include "../../base.hpp"

class ISchemaSystem;
class IGameResourceService;
class IInputSystem;
class IEngineClient;

namespace I
{
	void Init();
	template<typename Interface>
	Interface* CreateInterface(const char* moduleName, const char* interfaceName)
	{
		using CreateInterfaceFn = Interface*(__fastcall*)(const char* name, int* a2);
		const auto createInterface = (CreateInterfaceFn)GetProcAddress(GetModuleHandleA(moduleName), CS_XOR("CreateInterface"));
		assert(createInterface);
		return createInterface(interfaceName, nullptr);
	}

	inline ISchemaSystem* SchemaSystem = nullptr;
	inline IGameResourceService* GameResourceService = nullptr;
	inline IInputSystem* InputSystem = nullptr;
	inline IEngineClient* EngineClient = nullptr;
}