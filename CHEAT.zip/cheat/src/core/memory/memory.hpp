#pragma once
#include "../../base.hpp"

#define CLIENT_DLL CS_XOR("client.dll")
#define SCHEMA_SYSTEM_DLL CS_XOR("schemasystem.dll")
#define ENGINE2_DLL CS_XOR("engine2.dll")
#define GAMEOVERLAYRENDERER64_DLL CS_XOR("gameoverlayrenderer64.dll")
#define SCENESYSTEM_DLL CS_XOR("scenesystem.dll")
#define TIER0_DLL CS_XOR("tier0.dll")
#define MATERIAL_SYSTEM2_DLL CS_XOR("materialsystem2.dll")
#define INPUTSYSTEM_DLL CS_XOR("inputsystem.dll")

// @ida: #STR: "cl: %d ===========================\n"
#define PRE_CREATE_MOVE CS_XOR("85 D2 0F 85 ? ? ? ? 48 8B C4 44 88 40")
// @ida: #STR: "cl: CreateMove clamped invalid attack h" go down a bit and you will find it
// @ida: #STR: "cl: CreateMove - Invalid player history [ %d, %d, %.3f ] f
#define ADD_TO_REP_ADDR CS_XOR("48 89 5C 24 ? 57 48 83 EC ? 48 8B D9 48 8B FA 48 8B 49 ? 48 85 C9 74 ? ? ? 3B 43")
#define ADD_SUBTICK_MOVE_STEP CS_XOR("E8 ? ? ? ? 48 8B D0 48 8B CE E8 ? ? ? ? 48 8B C8")
#define ADD_NEW_INPUT_ENTRY CS_XOR("E8 ? ? ? ? 48 8B D0 48 8D 4B ? E8 ? ? ? ? 48 8B F0")
// @ida: this got called before GetMatricesForView
// @ida: #STR: "bot_takeover" a bit below
#define SET_VIEW_ANGLE CS_XOR("85 D2 75 ? 48 63 81")
// @ida: #STR: "C:\\buildworker\\csgo_rel_win64\\build\\src\\game\\client\\fx_tracer.cpp" a bit below
#define GET_VIEW_ANGLE CS_XOR("4C 8B C1 85 D2 74 ? 48 8D 05")
// PreCreateMove
#define GET_CUSERCMD_TICK CS_XOR("48 83 EC ? 4C 8B 0D ? ? ? ? 4C 8B DA")
#define GET_CUSERCMD_ARRAY CS_XOR("48 89 4C 24 ? 41 56 41 57")
#define CUSERCMD_ARRAY CS_XOR("48 8B 0D ? ? ? ? E8 ? ? ? ? 48 8B CF 48 8B F0")
#define GET_CUSERCMD_BY_NUMBER CS_XOR("40 53 48 83 EC ? 8B DA E8 ? ? ? ? 4C 8B C0")
#define GET_LOCAL_PLAYER CS_XOR("E8 ? ? ? ? 48 89 44 24 ? 48 8B F8 48 85 C0 0F 84 ? ? ? ? 48 89 B4 24")
// CreateMove
#define READ_FRAME_INPUT CS_XOR("40 53 57 48 81 EC ? ? ? ? 80 B9 ? ? ? ? 00 8B DA")
#define FILL_INPUT_HISTORY_ENTRY CS_XOR("48 89 5C 24 ? 55 57 41 56 48 8D 6C 24 ? 48 81 EC ? ? ? ? ? ? 48 8B F9")
#define GET_SEED CS_XOR("48 89 5C 24 ? 57 48 81 EC ? ? ? ? ? ? ? ? 48 8D 8C 24")
#define GET_SOME_TIMING CS_XOR("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 49 63 D8 48 8B F1")
#define UPDATE_ACCURACY_PENALITY CS_XOR("40 53 57 48 83 EC ? 48 8B F9 E8 ? ? ? ? 48 8B D8")
#define GET_SPREAD CS_XOR("48 83 EC ? 48 63 91 ? ? ? ? 48 8B 81 ? ? ? ? 0F 29 74 24 ? 85 D2")
#define GET_INACCURACY CS_XOR("48 89 5C 24 ? 55 56 57 48 81 EC ? ? ? ? 44 0F 29 84 24")
#define CALCULATE_SPREAD_ANGLE CS_XOR("48 8B C4 48 89 58 08 48 89 68 18 48 89 70 20 57 41 54 41 55 41 56 41 57 48 81")
#define GAME_TRACE_INIT CS_XOR("40 55 41 55 41 57 48 83 EC")
#define INIT_TRACE CS_XOR("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F B6 41 ? 33 FF 24")
#define TRACE_SHAPE CS_XOR("48 89 5C 24 ? 48 89 4C 24 ? 55 57")
#define TRACE_DATA_INIT CS_XOR("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8D 79 ? 33 F6 C7 47 ? ? ? ? ? 48 8B D9 ? ? ? C7 47 ? ? ? ? ? 40 F6 C7 ? 74 ? E8 ? ? ? ? 48 8D 47 ? ? ? ? 48 8D BB ? ? ? ? ? ? 40 88 B3")
#define GET_GAME_TRACE_INFO CS_XOR("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B E9 0F 29 74 24 ? 48 8B CA")
#define HANDLE_BULLET_PENETRATION CS_XOR("48 8B C4 44 89 48 ? 48 89 50 ? 48 89 48 ? 55 57")
#define CREATE_TRACE CS_XOR("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? ? ? ? ? 4D 8D 71")

#define SWAP_CHAIN CS_XOR("48 8B 0D ? ? ? ? 4C 89 71")
#define GET_AIM_PUNCH CS_XOR("48 89 5C 24 ? 57 48 83 EC ? 48 8B FA 48 8B D9 48 8D 54 24 ? E8 ? ? ? ? F3 0F 10 5B")
#define VIEW_MATRIX CS_XOR("48 8D 0D ? ? ? ? 48 89 44 24 ? 48 89 4C 24 ? 4C 8D 0D")
#define SET_TYPE_KV3 CS_XOR("40 53 48 83 EC ? 4C 8B 11 41 B9")
#define UTL_BUFFER_INIT CS_XOR("??0CUtlBuffer@@QEAA@HHW4BufferFlags_t@0@@Z")
#define UTL_BUFFER_PUT_STRING CS_XOR("?PutString@CUtlBuffer@@QEAAXPEBD@Z")
#define UTL_BUFFER_ENSURE_CAPACITY CS_XOR("?EnsureCapacity@CUtlBuffer@@QEAAXH@Z")
#define LOAD_KEY_VALUES CS_XOR("E8 ? ? ? ? EB ? F7 43")
#define CREATE_MATERIAl CS_XOR("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 8B F2")
#define DRAW_OBJECT CS_XOR("48 8B C4 53 57 41 54 48 81 EC ?? ?? ?? ?? 49 63 F9 49")
#define INPUT CS_XOR("48 8B 0D ? ? ? ? 4C 8B C5 ? ? E8 ? ? ? ? 4C 8D 5C 24")
#define IS_ON_MAP CS_XOR("8B 3D ? ? ? ? 83 EF ? 8B 05")
#define CALCVIEWMODEL CS_XOR("40 53 48 83 EC 20 C6 05 ? ? ? ? 00")
#define GET_IMAGE_VIEW CS_XOR("48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 48 89 4C 24 ? 55 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 33 DB 4D 0F BE F8 89 5D ? 45 0F B6 E1 48 8B 02 4C 8B F2 4C 8B 2D ? ? ? ? 48 85 C0 0F 84 ? ? ? ? 8B 40 ? 85 C0 0F 8E ? ? ? ? 48 8B 02 48 8B 30 48 85 F6 0F 84 ? ? ? ? 41 80 FF")
#define MAIN_MENU_PANEL CS_XOR("48 83 EC ? 48 8B 05 ? ? ? ? 48 8D 15")
#define WORLD CS_XOR("4C 8B 05 ? ? ? ? 4D 85 C0 74 ? 83 F9 ? 74 ? 8B C1 25 ? ? ? ? 8B D0 48 C1 E8 ? ? ? ? ? 4D 85 DB")
#define UPDATE_SUBCLASS CS_XOR("4C 8B DC 53 48 81 EC ? ? ? ? 48 8B 41")
#define UPDATE_MODEL CS_XOR("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 44 0F B6 F2")
#define REGEN_WEAPON_SKIN CS_XOR("40 55 53 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 44 0F B6 FA")
#define SET_MESH_GROUP_MASK CS_XOR("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8D 99 ? ? ? ? 48 8B 71")
#define FRAME_STAGE_NOTIFY CS_XOR("40 55 53 56 57 41 54 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85")

// Particles — CGameParticleManager
// Primary: read from global variable via mov rcx,[rip+rel32]
#define PARTICLES_MGR_GLOBAL   CS_XOR("48 8B 0D ? ? ? ? 41 B8 ? ? ? ? F3 0F 11 74 24 ? 48 C7 44 24")
// Legacy fallback: E8-style factory getter
#define PARTICLES_MGR_LEGACY   CS_XOR("E8 ? ? ? ? 89 74 24 38 4C 8D 05")
#define PARTICLES_CREATE_INDEX CS_XOR("4C 8B DC 53 48 81 EC ? ? ? ? F2 0F 10 05")
#define PARTICLES_SET_SETTINGS CS_XOR("48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 50 F3 0F 10 1D ? ? ? ? 41 8B F8 8B DA 4C")
#define PARTICLES_DELETE_EFFECT CS_XOR("83 FA ? 0F 84 ? ? ? ? 41 54")

namespace MEM
{
	void Init();

	// base funcs
	uintptr_t FindPattern(const char* module, const char* pattern);
	uintptr_t GetAbsoluteAddress(uintptr_t pRelativeAddress, int nPreOffset = 0x0, int nPostOffset = 0x0);
	template<typename Return, typename ... Params>
	Return VMTCall(void* class_instance, uint64_t index, Params ... params)
	{
		using Fn = Return(__thiscall*)(void*, decltype(params) ...);
		return (*reinterpret_cast<Fn**>(class_instance))[index](class_instance, params ...);
	}
	static void* GetVFunc(void* class_instance, size_t index)
	{
		return (*reinterpret_cast<void***>(class_instance))[index];
	}

	// global vars
	inline void* pViewMatrix = nullptr;
	inline void* pSwapChain = nullptr;
	inline void* pInput = nullptr;
	inline void* pIsOnMap = nullptr;

	// modules
	inline uintptr_t client_dll = 0;
	inline uintptr_t tier0_dll = 0;

	// funcs
	inline void* pPreCreateMove = nullptr;
	inline void* padd_to_rep_addr = nullptr;
	inline void* padd_subtick_move_step = nullptr;
	inline void* pcreate_new_input_history = nullptr;
	inline void* pSetViewAngle = nullptr;
	inline void* pGetViewAngle = nullptr;
	inline void* pGetCUserCmdTick = nullptr;
	inline void* pGetCUserCmdArray = nullptr;
	inline void* pCUserCmdArray = nullptr;
	inline void* pGetCUserCmdBySequenceNumber = nullptr;
	inline void* pGetLocalPlayer = nullptr;
	inline void* pReadFrameInput = nullptr;
	inline void* pFillInputHistoryEntry = nullptr;
	inline void* pGetSeed = nullptr;
	inline void* pGetSomeTiming = nullptr;
	inline void* pUpdateAccuracyPenality = nullptr;
	inline void* pGetSpread = nullptr;
	inline void* pGetInaccuracy = nullptr;
	inline void* pCalculateSpreadAngle = nullptr;
	inline void* pGameTraceInit = nullptr;
	inline void* pInitTrace = nullptr;
	inline void* pTraceDataInit = nullptr;
	inline void* pGetGameTraceInfo = nullptr;
	inline void* pHandleBulletPenetration = nullptr;
	inline void* pCreateTrace = nullptr;
	inline void* pGetAimPunch = nullptr;
	inline void* pSetTypeKV3 = nullptr;
	inline void* pUtlBufferInit = nullptr;
	inline void* pUtlBufferPutString = nullptr;
	inline void* pUtlBufferEnsureCapacity = nullptr;
	inline void* pLoadKeyValues = nullptr;
	inline void* pCreateMaterial = nullptr;
	inline void* pDrawObject = nullptr;
	inline void* pCalcViewModel = nullptr;
	inline void* pGetImageView = nullptr;
	inline void* pMainMenuPanel = nullptr;
	inline void* pWorld = nullptr;
	inline void* pUpdateSubclass = nullptr;
	inline void* pUpdateModel = nullptr;
	inline void* pRegenWeaponSkin = nullptr;
	inline void* pSetMeshGroupMask = nullptr;
	inline void* pFrameStageNotify = nullptr;

	// Particles
	inline void* pParticleMgrGlobal   = nullptr; // void** — pointer to the CParticleSystemMgr* global
	inline void* pParticleGetMgr      = nullptr; // legacy E8 factory getter
	inline void* pParticleCreate      = nullptr;
	inline void* pParticleSetSettings = nullptr;
	inline void* pParticleDelete      = nullptr;
}