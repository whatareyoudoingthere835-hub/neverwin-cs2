#include "memory.hpp"
#include "dxgi.h"

class ISwapChainDx11
{
	MEM_PAD(0x170);
	IDXGISwapChain* pDXGISwapChain;
};

void MEM::Init()
{
	client_dll = (uintptr_t)GetModuleHandleA(CLIENT_DLL);
	tier0_dll = (uintptr_t)GetModuleHandleA(TIER0_DLL);

	pPreCreateMove = (void*)MEM::FindPattern(CLIENT_DLL, PRE_CREATE_MOVE);
	padd_to_rep_addr = (void*)MEM::FindPattern(CLIENT_DLL, ADD_TO_REP_ADDR);
	padd_subtick_move_step = (void*)MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, ADD_SUBTICK_MOVE_STEP), 0x1);
	pcreate_new_input_history = (void*)MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, ADD_NEW_INPUT_ENTRY), 0x1);
	pSetViewAngle = (void*)MEM::FindPattern(CLIENT_DLL, SET_VIEW_ANGLE);
	pGetViewAngle = (void*)MEM::FindPattern(CLIENT_DLL, GET_VIEW_ANGLE);
	pGetCUserCmdTick = (void*)MEM::FindPattern(CLIENT_DLL, GET_CUSERCMD_TICK);
	pGetCUserCmdArray = (void*)MEM::FindPattern(CLIENT_DLL, GET_CUSERCMD_ARRAY);
	pCUserCmdArray = (void*)MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, CUSERCMD_ARRAY), 0x3);
	pGetCUserCmdBySequenceNumber = (void*)MEM::FindPattern(CLIENT_DLL, GET_CUSERCMD_BY_NUMBER);
	pGetLocalPlayer = (void*)MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, GET_LOCAL_PLAYER), 0x1);
	pReadFrameInput = (void*)MEM::FindPattern(CLIENT_DLL, READ_FRAME_INPUT);
	pFillInputHistoryEntry = (void*)MEM::FindPattern(CLIENT_DLL, FILL_INPUT_HISTORY_ENTRY);
	pGetSeed = (void*)MEM::FindPattern(CLIENT_DLL, GET_SEED);
	pGetSomeTiming = (void*)MEM::FindPattern(CLIENT_DLL, GET_SOME_TIMING);
	pUpdateAccuracyPenality = (void*)MEM::FindPattern(CLIENT_DLL, UPDATE_ACCURACY_PENALITY);
	pGetSpread = (void*)MEM::FindPattern(CLIENT_DLL, GET_SPREAD);
	pGetInaccuracy = (void*)MEM::FindPattern(CLIENT_DLL, GET_INACCURACY);
	pCalculateSpreadAngle = (void*)MEM::FindPattern(CLIENT_DLL, CALCULATE_SPREAD_ANGLE);
	pGameTraceInit = (void*)MEM::FindPattern(CLIENT_DLL, GAME_TRACE_INIT);
	pInitTrace = (void*)MEM::FindPattern(CLIENT_DLL, INIT_TRACE);
	pTraceDataInit = (void*)MEM::FindPattern(CLIENT_DLL, TRACE_DATA_INIT);
	pGetGameTraceInfo = (void*)MEM::FindPattern(CLIENT_DLL, GET_GAME_TRACE_INFO);
	pHandleBulletPenetration = (void*)MEM::FindPattern(CLIENT_DLL, HANDLE_BULLET_PENETRATION);
	pCreateTrace = (void*)MEM::FindPattern(CLIENT_DLL, CREATE_TRACE);
	pSwapChain = *(void**)(*(uintptr_t*)(MEM::GetAbsoluteAddress(MEM::FindPattern(GAMEOVERLAYRENDERER64_DLL, SWAP_CHAIN), 0x3)) + 0x18ULL);
	pGetAimPunch = (void*)MEM::FindPattern(CLIENT_DLL, GET_AIM_PUNCH);
	pViewMatrix = (void*)MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, VIEW_MATRIX), 3);
	pSetTypeKV3 = (void*)MEM::FindPattern(CLIENT_DLL, SET_TYPE_KV3);

	pUtlBufferInit = (void*)GetProcAddress((HMODULE)tier0_dll, UTL_BUFFER_INIT);
	pUtlBufferPutString = (void*)GetProcAddress((HMODULE)tier0_dll, UTL_BUFFER_PUT_STRING);
	pUtlBufferEnsureCapacity = (void*)GetProcAddress((HMODULE)tier0_dll, UTL_BUFFER_ENSURE_CAPACITY);

	pLoadKeyValues = (void*)MEM::GetAbsoluteAddress(MEM::FindPattern(TIER0_DLL, LOAD_KEY_VALUES), 0x1);
	pCreateMaterial = (void*)MEM::FindPattern(MATERIAL_SYSTEM2_DLL, CREATE_MATERIAl);
	pDrawObject = (void*)MEM::FindPattern(SCENESYSTEM_DLL, DRAW_OBJECT);
	pInput = *reinterpret_cast<void***>(MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, INPUT), 0x3));
	pIsOnMap = (void*)MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, IS_ON_MAP), 0x2);
	pCalcViewModel = (void*)MEM::FindPattern(CLIENT_DLL, CALCVIEWMODEL);
	pGetImageView = (void*)MEM::FindPattern("rendersystemdx11.dll", GET_IMAGE_VIEW);
	
	uintptr_t pMainMenuPanelAddr = MEM::FindPattern(CLIENT_DLL, MAIN_MENU_PANEL);
	if (pMainMenuPanelAddr) {
		pMainMenuPanel = (void*)MEM::GetAbsoluteAddress(pMainMenuPanelAddr + 0x4, 0x3, 0x0); // "48 8B 05" + 3
	}

	pWorld = (void*)MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, WORLD), 0x3);
	pUpdateSubclass = (void*)MEM::FindPattern(CLIENT_DLL, UPDATE_SUBCLASS);
	pUpdateModel = (void*)MEM::FindPattern(CLIENT_DLL, UPDATE_MODEL);
	pRegenWeaponSkin = (void*)MEM::FindPattern(CLIENT_DLL, REGEN_WEAPON_SKIN);
	pSetMeshGroupMask = (void*)MEM::FindPattern(CLIENT_DLL, SET_MESH_GROUP_MASK);
	pFrameStageNotify = (void*)MEM::FindPattern(CLIENT_DLL, FRAME_STAGE_NOTIFY);

	// Particles
	uintptr_t particleGlobMov = MEM::FindPattern(CLIENT_DLL, PARTICLES_MGR_GLOBAL);
	if (particleGlobMov)
		pParticleMgrGlobal = reinterpret_cast<void*>(MEM::GetAbsoluteAddress(particleGlobMov, 3, 0));
	uintptr_t particleLegacy = MEM::FindPattern(CLIENT_DLL, PARTICLES_MGR_LEGACY);
	if (particleLegacy)
		pParticleGetMgr = reinterpret_cast<void*>(MEM::GetAbsoluteAddress(particleLegacy, 1, 0));
	pParticleCreate      = (void*)MEM::FindPattern(CLIENT_DLL, PARTICLES_CREATE_INDEX);
	pParticleSetSettings = (void*)MEM::FindPattern(CLIENT_DLL, PARTICLES_SET_SETTINGS);
	pParticleDelete      = (void*)MEM::FindPattern(CLIENT_DLL, PARTICLES_DELETE_EFFECT);

	int END = 1;
}

uintptr_t MEM::GetAbsoluteAddress(uintptr_t pRelativeAddress, int nPreOffset, int nPostOffset)
{
	pRelativeAddress += nPreOffset;
	pRelativeAddress += sizeof(std::int32_t) + *reinterpret_cast<std::int32_t*>(pRelativeAddress);
	pRelativeAddress += nPostOffset;
	return pRelativeAddress;
}

uintptr_t MEM::FindPattern(const char* moduleName, const char* pattern)
{
	const auto moduleHandle = GetModuleHandleA(moduleName);
	if (!moduleHandle) return 0;

	const auto pIDH = reinterpret_cast<PIMAGE_DOS_HEADER>(moduleHandle);
	const auto pINH = reinterpret_cast<PIMAGE_NT_HEADERS>(reinterpret_cast<uintptr_t>(moduleHandle) + pIDH->e_lfanew);

	const uint8_t* scanStart = reinterpret_cast<uint8_t*>(moduleHandle);
	const size_t scanSize = pINH->OptionalHeader.SizeOfImage;

	std::vector<std::pair<uint8_t, bool>> parsedPattern;
	std::string_view patternView(pattern);

	for (size_t i = 0; i < patternView.length(); ++i) {
		if (patternView[i] == ' ') continue;

		if (patternView[i] == '?') {
			parsedPattern.push_back({ 0, false });
			if (i + 1 < patternView.length() && patternView[i + 1] == '?') i++; // ?? or ? support
		}
		else {
			parsedPattern.push_back({ static_cast<uint8_t>(strtoul(&patternView[i], nullptr, 16)), true });
			i++;
		}
	}

	for (size_t i = 0; i < scanSize - parsedPattern.size(); ++i) {
		bool found = true;

		for (size_t j = 0; j < parsedPattern.size(); ++j) {
			if (parsedPattern[j].second && scanStart[i + j] != parsedPattern[j].first) {
				found = false;
				break;
			}
		}

		if (found) {
			return reinterpret_cast<uintptr_t>(scanStart + i);
		}
	}

	return 0;
}