#pragma once
#include "../sdk/CCSGOInput.hpp"
#include <dxgi.h>
#include "../sdk/sceneobject.hpp"

#include <D3D11.h>
#include "../../../ext/imgui/imgui_impl_win32.h"
#include "../../../ext/imgui/imgui_impl_dx11.h"

inline ID3D11Device* g_device;
inline ID3D11DeviceContext* g_context;
inline IDXGISwapChain* g_swap_chain;
inline ID3D11RenderTargetView* g_render_target_view;
inline HWND g_window;
inline WNDPROC g_wndProcOriginal;

#include "../../render/menu.h"
#include "../interfaces/interfaces.hpp"


inline bool show_window = true;

class CMeshData;

namespace HOOKS
{
	void Init();

	void __fastcall PreCreateMove(CCSGOInput* input, int slot, char active);
	inline decltype(&PreCreateMove) oPreCreateMove;

	HRESULT __stdcall Present(IDXGISwapChain* pSwapChain, UINT uSyncInterval, UINT uFlags);
	inline decltype(&Present) oPresent;

	bool DrawObject(void* pAnimatableSceneObjectDesc, void* pDx11, CMeshData* arrMeshDraw, int nDataCount, void* pSceneView, void* pSceneLayer, void* pUnk, void* pUnk2);
	inline decltype(&DrawObject) oDrawObject;

	bool MouseInputEnabled(void* pThisptr);
	inline decltype(&MouseInputEnabled) oMouseInputEnabled;

	void* IsRelativeMouseMode(void* pThisptr, bool bActive);
	inline decltype(&IsRelativeMouseMode) oIsRelativeMouseMode;

	void* hkCalcViewModel(void* a1, vector_t* a2, vector_t* rot);
	inline void* oCalcViewModel;

	void* getImageViewHook(void* a1, int** a2, char a3, char a4, int a5);
	inline void* oGetImageView;

	void __fastcall FrameStageNotify(void* thisptr, int stage);
	inline decltype(&FrameStageNotify) oFrameStageNotify;
}

extern void* g_previewTexture;

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

inline int g_KeypressCount = 0;

static LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static bool singleton = true;
	static bool browser_init = false;


	if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN)
	{
		g_KeypressCount++;
	}

	if (InterlopeMenu_IsOpen())
	{
		ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam);
		HOOKS::oIsRelativeMouseMode(I::InputSystem, false);
		return singleton = true; // просто сокращение строчек
	}
	if (singleton && *(bool*)MEM::pIsOnMap) HOOKS::oIsRelativeMouseMode(I::InputSystem, !(singleton = false) /*типо true*/);
	return CallWindowProcA(g_wndProcOriginal, hWnd, msg, wParam, lParam);
}
