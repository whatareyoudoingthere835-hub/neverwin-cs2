#include "hooks.hpp"
#include "../memory/memory.hpp"
#include <iostream>
#include "../../../ext/minhook/minhook.h"
#include "../sdk/entity.hpp"
#include "../sdk/panorama.hpp"

// handlers
#include "../../features/aimbot/aimbot.hpp"
#include "../../features/world_modulation/worldmodulation.hpp"
#include "../../features/movement/movement.hpp"
#include "../../features/visuals/visuals.hpp"
#include "../gui/gui.hpp"
#include "../../features/visuals/chams.hpp"
#include "../../features/skinchanger/skinchanger.hpp"
#include "../../features/skins/skins.hpp"
#include "../../features/visuals/particles.hpp"
#include "../settings.hpp"

void HOOKS::Init()
{
	MH_Initialize();

	MH_CreateHook(
		MEM::pPreCreateMove, 
		&PreCreateMove,
		(void**)&oPreCreateMove);

	MH_CreateHook(
		MEM::GetVFunc(MEM::pSwapChain, 8),
		&Present,
		(void**)&oPresent);

    MH_CreateHook(
        MEM::pDrawObject,
        &DrawObject,
        (void**)&oDrawObject);

    MH_CreateHook(
        MEM::GetVFunc(MEM::pInput, 20),
        &MouseInputEnabled,
        (void**)&oMouseInputEnabled);

    MH_CreateHook(
        MEM::GetVFunc(I::InputSystem, 76),
        &IsRelativeMouseMode,
        (void**)&oIsRelativeMouseMode);

    if (MEM::pCalcViewModel)
    {
        MH_CreateHook(
            MEM::pCalcViewModel,
            &hkCalcViewModel,
            (void**)&oCalcViewModel);
    }

    if (MEM::pGetImageView)
    {
        MH_CreateHook(
            MEM::pGetImageView,
            &getImageViewHook,
            (void**)&oGetImageView);
    }

    if (MEM::pFrameStageNotify)
    {
        MH_CreateHook(
            MEM::pFrameStageNotify,
            &FrameStageNotify,
            (void**)&oFrameStageNotify);
    }

	MH_EnableHook(MH_ALL_HOOKS);
}

void __fastcall HOOKS::PreCreateMove(CCSGOInput* input, int slot, char active)
{
	HOOKS::oPreCreateMove(input, slot, active);

	const auto localPlayer = GetLocalPlayerController();
	if (!localPlayer) return;

	CUserCmd* cmd = input->GetCurrentCmd(localPlayer);
	if (!cmd) return;

	MV::PreCreateMoveHook(input, slot, active, localPlayer, cmd);
	AIM::PreCreateMoveHook(input, slot, active, localPlayer, cmd);
	VISUALS::PreCreateMoveHook(input, slot, active, localPlayer, cmd);

	input->CalculateCRC(cmd);
}

HRESULT __stdcall HOOKS::Present(IDXGISwapChain* pSwapChain, UINT uSyncInterval, UINT uFlags)
{
	static bool init = false;
	if (!init)
	//if (pSwapChain != g_swap_chain)
	{
		g_swap_chain = pSwapChain;
		g_swap_chain->GetDevice(__uuidof(ID3D11Device), (void**)&g_device);
		g_device->GetImmediateContext(&g_context);
		DXGI_SWAP_CHAIN_DESC sd;
		g_swap_chain->GetDesc(&sd);
		g_window = sd.OutputWindow;
		ID3D11Texture2D* pBackBuffer;
		g_swap_chain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer);
		g_device->CreateRenderTargetView(pBackBuffer, NULL, &g_render_target_view);
		pBackBuffer->Release();
		g_wndProcOriginal = (WNDPROC)SetWindowLongPtr(g_window, GWLP_WNDPROC, (LONG_PTR)WndProc);

		ImGui::CreateContext();
		ImGuiIO& io = ImGui::GetIO(); (void)io;
		io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;
		ImGui::StyleColorsDark();
		ImGui_ImplWin32_Init(g_window);
		ImGui_ImplDX11_Init(g_device, g_context);

		GUI::Init();
		init = true;
	}

	static bool js_injected = false;
	if (!js_injected && InterlopeMenu_IsOpen() && I::PanoramaUIEngine && MEM::pMainMenuPanel) {
		auto* ui_engine = I::PanoramaUIEngine->access_ui_engine();
		if (ui_engine) {
			auto* pMainMenu = *(panel_2d_t**)MEM::pMainMenuPanel;
			if (pMainMenu && pMainMenu->ui_panel) {
				const char* script = 
					"var mainPanel = $.CreatePanel('MapPlayerPreviewPanel', $.GetContextPanel(), 'preview_texture_name', { "
					"map: 'ui/buy_menu', "
					"camera: 'cam_loadoutmenu_ct', "
					"'require-composition-layer': true, "
					"playermodel: 'characters/models/tm_professional/tm_professional_varf.vmdl', "
					"playername: 'vanity_character', "
					"'composition-layer-texture-name': 'preview_texture_name', "
					"animgraphcharactermode: 'buy-menu', "
					"player: true, "
					"mouse_rotate: true, "
					"sync_spawn_addons: true, "
					"'transparent-background': true, "
					"'pin-fov': 'vertical', "
					"csm_split_plane0_distance_override: '250.0', "
					"style: 'y: 5px; vertical-align: top; width: 300px; height: 300px; horizontal-align: center;' "
					"});";
				ui_engine->run_script(pMainMenu->ui_panel, script);
				js_injected = true;
			}
		}
	}

	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	VISUALS::Present(pSwapChain, uSyncInterval, uFlags);
    SKINS::Draw();
    GUI::Present(pSwapChain, uSyncInterval, uFlags);

	ImGui::Render();

	g_context->OMSetRenderTargets(1, &g_render_target_view, NULL);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

	return HOOKS::oPresent(pSwapChain, uSyncInterval, uFlags);
}

void lol()
{
    WNDCLASSEXA windowClass;
    windowClass.cbSize = sizeof(WNDCLASSEX);
    windowClass.style = CS_HREDRAW | CS_VREDRAW;
    windowClass.lpfnWndProc = DefWindowProc;
    windowClass.cbClsExtra = 0;
    windowClass.cbWndExtra = 0;
    windowClass.hInstance = GetModuleHandle(NULL);
    windowClass.hIcon = NULL;
    windowClass.hCursor = NULL;
    windowClass.hbrBackground = NULL;
    windowClass.lpszMenuName = NULL;
    windowClass.lpszClassName = "Kiero";
    windowClass.hIconSm = NULL;

    ::RegisterClassExA(&windowClass);

    HWND window = ::CreateWindowExA(0, "Kiero", "Kiero DirectX Window", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, NULL, NULL, windowClass.hInstance, NULL);
    HMODULE libD3D11 = ::GetModuleHandleA("d3d11.dll");

    void* D3D11CreateDeviceAndSwapChain = (void*)::GetProcAddress(libD3D11, "D3D11CreateDeviceAndSwapChain");

    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevels[] = { D3D_FEATURE_LEVEL_10_1, D3D_FEATURE_LEVEL_11_0 };

    DXGI_RATIONAL refreshRate;
    refreshRate.Numerator = 60;
    refreshRate.Denominator = 1;

    DXGI_MODE_DESC bufferDesc;
    bufferDesc.Width = 100;
    bufferDesc.Height = 100;
    bufferDesc.RefreshRate = refreshRate;
    bufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    bufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
    bufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;

    DXGI_SAMPLE_DESC sampleDesc;
    sampleDesc.Count = 1;
    sampleDesc.Quality = 0;

    DXGI_SWAP_CHAIN_DESC swapChainDesc;
    swapChainDesc.BufferDesc = bufferDesc;
    swapChainDesc.SampleDesc = sampleDesc;
    swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    swapChainDesc.BufferCount = 1;
    swapChainDesc.OutputWindow = window;
    swapChainDesc.Windowed = 1;
    swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    swapChainDesc.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

    IDXGISwapChain* swapChain;
    ID3D11Device* device;
    ID3D11DeviceContext* context;

    ((long(__stdcall*)(
        IDXGIAdapter*,
        D3D_DRIVER_TYPE,
        HMODULE,
        UINT,
        const D3D_FEATURE_LEVEL*,
        UINT,
        UINT,
        const DXGI_SWAP_CHAIN_DESC*,
        IDXGISwapChain**,
        ID3D11Device**,
        D3D_FEATURE_LEVEL*,
        ID3D11DeviceContext**))(D3D11CreateDeviceAndSwapChain))(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, featureLevels, 2, D3D11_SDK_VERSION, &swapChainDesc, &swapChain, &device, &featureLevel, &context);

    std::cout << std::hex << swapChain << std::endl;
}

bool HOOKS::DrawObject(void* pAnimatableSceneObjectDesc, void* pDx11, CMeshData* arrMeshDraw, int nDataCount, void* pSceneView, void* pSceneLayer, void* pUnk, void* pUnk2)
{
    CHAMS::OnDrawObject(pAnimatableSceneObjectDesc, pDx11, arrMeshDraw, nDataCount, pSceneView, pSceneLayer, pUnk, pUnk2);
	return HOOKS::oDrawObject(pAnimatableSceneObjectDesc, pDx11, arrMeshDraw, nDataCount, pSceneView, pSceneLayer, pUnk, pUnk2);
}

bool HOOKS::MouseInputEnabled(void* pThisptr)
{
    return InterlopeMenu_IsOpen() ? false : HOOKS::oMouseInputEnabled(pThisptr);
}

void* HOOKS::IsRelativeMouseMode(void* pThisptr, bool bActive)
{
    return HOOKS::oIsRelativeMouseMode(pThisptr, InterlopeMenu_IsOpen() ? false : bActive);
}

void* HOOKS::hkCalcViewModel(void* a1, vector_t* a2, vector_t* rot)
{
	static auto oCalcViewModel_fn = reinterpret_cast<void*(__fastcall*)(void*, vector_t*, vector_t*)>(HOOKS::oCalcViewModel);
	
	// Call the original function first so we get the base viewmodel vectors
	void* result = oCalcViewModel_fn(a1, a2, rot);

	return result;
}

void* g_previewTexture = nullptr;

// A simple hash function to avoid dragging in heavy dependencies or redefining things unnecessarily
constexpr unsigned int HashRuntime(const char* str) {
    unsigned int hash = 0x811c9dc5;
    while (*str) {
        hash ^= (unsigned char)*str++;
        hash *= 0x1000193;
    }
    return hash;
}

void* HOOKS::getImageViewHook(void* a1, int** a2, char a3, char a4, int a5)
{
    static auto oGetImageView_fn = reinterpret_cast<void*(__fastcall*)(void*, int**, char, char, int)>(HOOKS::oGetImageView);
    auto result = oGetImageView_fn(a1, a2, a3, a4, a5);
    
    if (InterlopeMenu_IsOpen()) {
        const char* tex_name = nullptr;
        if (a2 && *a2) {
            auto* base_ptr = reinterpret_cast<std::uintptr_t*>(*a2);
            auto** string_ptr = reinterpret_cast<const char**>(base_ptr[1]);
            if (string_ptr) tex_name = *string_ptr;
        }
        
        if (tex_name) {
            if (HashRuntime(tex_name) == HashRuntime("preview_texture_name")) {
                g_previewTexture = result;
            }
        }
    }

    return result;
}

void __fastcall HOOKS::FrameStageNotify(void* thisptr, int stage)
{
    HOOKS::oFrameStageNotify(thisptr, stage);

    // stage 6 = FRAME_RENDER_END — game thread, safe for resource loading (particles)
    if (stage == 6)
        Particles::Update();
}
