#include "schema.hpp"
#include "../sdk/ischemasystem.h"
#include "../interfaces/interfaces.hpp"

// TODO: fix collisions with different modules
std::unordered_map<FNV1A_t, uint32_t> gMapSchemaData;

void SCHEMA::Init()
{
	Setup(CLIENT_DLL); // and other staff
}

bool SCHEMA::Setup(const char* szModuleName)
{
	CSchemaSystemTypeScope* pTypeScope = I::SchemaSystem->FindTypeScopeForModule(szModuleName);
	if (pTypeScope == nullptr)
		return false;

	const int nTableSize = pTypeScope->hashClasses.Count();

	UtlTSHashHandle_t* pElements = new UtlTSHashHandle_t[nTableSize + 1U];
	const auto nElements = pTypeScope->hashClasses.GetElements(0, nTableSize, pElements);

	for (int i = 0; i < nElements; i++)
	{
		const UtlTSHashHandle_t hElement = pElements[i];

		if (hElement == 0)
			continue;

		CSchemaClassBinding* pClassBinding = pTypeScope->hashClasses[hElement];
		if (pClassBinding == nullptr)
			continue;

		SchemaClassInfoData_t* pDeclaredClassInfo = nullptr;
		pTypeScope->FindDeclaredClass(&pDeclaredClassInfo, pClassBinding->szBinaryName);

		if (pDeclaredClassInfo == nullptr)
			continue;

		if (pDeclaredClassInfo->nFieldSize == 0)
			continue;

		SchemaClassFieldData_t* pFields = pDeclaredClassInfo->pFields;

		for (auto j = 0; j < pDeclaredClassInfo->nFieldSize; j++)
		{
			auto classField = std::format("{}->{}", pClassBinding->szBinaryName, pFields[j].szName);
			auto fnvName = FNV1A::Hash(classField.c_str());
			gMapSchemaData[fnvName] = pFields[j].nSingleInheritanceOffset;
		}
	}

	delete[] pElements;

	return true;
}

uint32_t SCHEMA::GetOffset(FNV1A_t uHashedFieldName)
{
	bool isThere = gMapSchemaData.contains(uHashedFieldName);
	assert(isThere);
	return isThere ? gMapSchemaData[uHashedFieldName] : 0;
}