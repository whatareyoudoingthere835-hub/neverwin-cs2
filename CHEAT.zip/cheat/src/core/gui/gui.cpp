#include "gui.hpp"
#include "../../render/menu.h"
#include "../../../ext/imgui/imgui.h"
#include <d3d11.h>
#include "../../zhironium/src/kallcode/blur/blur.hpp"

extern ID3D11Device* g_device;
extern ID3D11DeviceContext* g_context;

#include "../../zhironium/src/kallcode/blur/blur.hpp"


void GUI::Init()
{
	ImGuiIO& io = ImGui::GetIO();
	g_blur.Initialize(g_device, g_context);
	InterlopeMenu_Initialize(io, g_device, g_context);

	// Browser initialized in WndProc instead to ensure it's on a thread with a message pump
}

void GUI::Present(IDXGISwapChain* pSwapChain, UINT uSyncInterval, UINT uFlags)
{
	g_blur.OnPresent(pSwapChain);

	if (GetAsyncKeyState(VK_INSERT) & 1) InterlopeMenu_Toggle();

	if (InterlopeMenu_IsOpen()) {
		using SDL_SetRelativeMouseMode_t = int(*)(bool);
		static SDL_SetRelativeMouseMode_t SDL_SetRelativeMouseMode = nullptr;
		if (!SDL_SetRelativeMouseMode) {
			SDL_SetRelativeMouseMode = (SDL_SetRelativeMouseMode_t)GetProcAddress(GetModuleHandleA("SDL3.dll"), "SDL_SetRelativeMouseMode");
			if (!SDL_SetRelativeMouseMode)
				SDL_SetRelativeMouseMode = (SDL_SetRelativeMouseMode_t)GetProcAddress(GetModuleHandleA("SDL2.dll"), "SDL_SetRelativeMouseMode");
		}
		if (SDL_SetRelativeMouseMode) {
			SDL_SetRelativeMouseMode(false);
		}
		
		g_blur.OnPresent(pSwapChain);
	}

	InterlopeMenu_Render();
}
