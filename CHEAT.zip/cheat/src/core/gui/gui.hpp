#pragma once
#include <dxgi.h>

namespace GUI
{
	void Init();
	void Present(IDXGISwapChain* pSwapChain, UINT uSyncInterval, UINT uFlags);
}