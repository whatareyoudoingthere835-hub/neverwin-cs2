#include "chams.hpp"
#include "../../core/sdk/keyvalue3.hpp"
#include "../../core/sdk/enums.hpp"
#include "../../core/sdk/vector.hpp"
#include "../../core/sdk/matrix.hpp"
#include "../../core/sdk/CBaseHandle.hpp"
#include "../../core/sdk/ischemasystem.h"
#include "../../core/sdk/entity.hpp"
#include "../../core/interfaces/interfaces.hpp"
#include "../../core/sdk/IGameResourceSystem.hpp"
#include "../../core/settings.hpp"
#include "../../core/hooks/hooks.hpp"

#include "../../core/sdk/sceneobject.hpp"

struct Color_t
{
	uint8_t r, g, b, a;
};

//class CSceneAnimatableObject
//{
//	MEM_PAD(0xC0);
//	CBaseHandle hOwner;
//};	
class CSceneAnimatableObject
{
public:
	MEM_PAD(0x78);
	uint32_t flags;
	MEM_PAD(0x44);
	CBaseHandle hOwner;
};
class CMeshData
{
public:
	MEM_PAD(0x18); // 0x0
	CSceneAnimatableObject* pSceneAnimatableObject; // 0x18
	CMaterial2* pMaterial; // 0x20
	MEM_PAD(0x28); // 0x28 to 0x50
	Color_t colValue; // 0x50 to 0x54 (4 bytes)
	MEM_PAD(0x14); // 0x54 to 0x68
};

CMaterial2** CHAMS::CreateMaterial(const char* szMaterialName, const char szVmatBuffer[])
{
	CKeyValues3* pKeyValues3 = CKeyValues3::CreateMaterialResource();
	pKeyValues3->LoadFromBuffer(szVmatBuffer);

	CMaterial2** pCustomMaterial = {};

	static auto fnCreateMaterial = (int64_t(__fastcall*)(void*, void*, const char*, void*, unsigned int, unsigned int))MEM::pCreateMaterial;
	fnCreateMaterial(nullptr, &pCustomMaterial, szMaterialName, pKeyValues3, 0, 1);

	return pCustomMaterial;
}

struct CustomMaterial_t
{
	CMaterial2* pMaterial;
	CMaterial2* pMaterialInvisible;
};

static CustomMaterial_t arrMaterials[VISUAL_MATERIAL_MAX];

bool CHAMS::Initialize()
{
	// check if we already initialized materials
	if (bInitialized)
		return bInitialized;

	arrMaterials[VISUAL_MATERIAL_PRIMARY_WHITE] = CustomMaterial_t{
		.pMaterial = *CreateMaterial(CS_XOR("materials/dev/primary_white.vmat"), szVMatBufferWhiteVisible),
		.pMaterialInvisible = *CreateMaterial(CS_XOR("materials/dev/primary_white.vmat"), szVMatBufferWhiteInvisible)
	};

	arrMaterials[VISUAL_MATERIAL_ILLUMINATE] = CustomMaterial_t{
		.pMaterial = *CreateMaterial(CS_XOR("materials/dev/primary_white.vmat"), szVMatBufferIlluminateVisible),
		.pMaterialInvisible = *CreateMaterial(CS_XOR("materials/dev/primary_white.vmat"), szVMatBufferIlluminateInvisible)
	};

	bInitialized = true;
	for (auto& [pMaterial, pMaterialInvisible] : arrMaterials)
	{
		if (pMaterial == nullptr || pMaterialInvisible == nullptr)
			bInitialized = false;
	}

	return bInitialized;
}

void CHAMS::Destroy()
{
	//for (auto& [pVisible, pInvisible] : arrMaterials)
	//{
	//	if (pVisible)
	//		I::ResourceHandleUtils->DeleteResource(pVisible.pBinding);

	//	if (pInvisible)
	//		I::ResourceHandleUtils->DeleteResource(pInvisible.pBinding);
	//}
}

//C_ViewmodelAttachmentModel - for chams on local arms
//C_CSGOViewModel - for chams on weapon in hands

bool CHAMS::OnDrawObject(void* pAnimatableSceneObjectDesc, void* pDx11, CMeshData* arrMeshDraw, int nDataCount, void* pSceneView, void* pSceneLayer, void* pUnk, void* pUnk2)
{
	if (!Settings::chams_enabled)
		return false;
		
	if (!bInitialized) {
		if (!Initialize()) return false;
	}

	if (arrMeshDraw == nullptr)
		return false;

	if (arrMeshDraw->pSceneAnimatableObject == nullptr)
		return false;

	CBaseHandle hOwner = arrMeshDraw->pSceneAnimatableObject->hOwner;

	if (!I::GameResourceService || !I::GameResourceService->pGameEntitySystem)
		return false;

	auto pEntity = I::GameResourceService->pGameEntitySystem->Get<C_BaseEntity>(hOwner);
	if (pEntity == nullptr)
		return false;

	SchemaClassInfoData_t* pClassInfo = pEntity->GetSchemaClassInfo();
	if (!pClassInfo) return false;
	if (strcmp(pClassInfo->szName, CS_XOR("C_CSPlayerPawn")) != 0 && strcmp(pClassInfo->szName, CS_XOR("C_CSGO_PreviewPlayer")) != 0)

		return false;

	auto pPlayerPawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(hOwner);
	if (pPlayerPawn == nullptr)
		return false;

	if (pPlayerPawn->m_iHealth() <= 0)
		return false;

	return OverrideMaterial(pAnimatableSceneObjectDesc, pDx11, arrMeshDraw, nDataCount, pSceneView, pSceneLayer, pUnk, pUnk2);
}

bool CHAMS::OverrideMaterial(void* pAnimatableSceneObjectDesc, void* pDx11, CMeshData* arrMeshDraw, int nDataCount, void* pSceneView, void* pSceneLayer, void* pUnk, void* pUnk2)
{
	const CustomMaterial_t customMaterial = arrMaterials[VISUAL_MATERIAL_ILLUMINATE];
    if (!customMaterial.pMaterial || !customMaterial.pMaterialInvisible)
        return false;

	auto clamp_color = [](float v) -> uint8_t { return static_cast<uint8_t>(v >= 1.0f ? 255 : (v <= 0.0f ? 0 : v * 255.0f)); };
	Color_t visible_color = { 
		clamp_color(Settings::chams_color.x), 
		clamp_color(Settings::chams_color.y), 
		clamp_color(Settings::chams_color.z), 
		clamp_color(Settings::chams_color.w) 
	};
	Color_t invisible_color = { 
		clamp_color(Settings::chams_invisible_color.x), 
		clamp_color(Settings::chams_invisible_color.y), 
		clamp_color(Settings::chams_invisible_color.z), 
		clamp_color(Settings::chams_invisible_color.w) 
	};

	// Disable PVS for all meshes first
	for (int i = 0; i < nDataCount; i++)
	{
		if (arrMeshDraw[i].pSceneAnimatableObject)
			arrMeshDraw[i].pSceneAnimatableObject->flags &= ~(1 << 3); // disable PVS
	}

	if (Settings::chams_invisible)
	{
		// Pass 1: Invisible (draws behind walls)
		for (int i = 0; i < nDataCount; i++)
		{
			arrMeshDraw[i].pMaterial = customMaterial.pMaterialInvisible;
			arrMeshDraw[i].colValue = invisible_color;
		}

		HOOKS::oDrawObject(pAnimatableSceneObjectDesc, pDx11, arrMeshDraw, nDataCount, pSceneView, pSceneLayer, pUnk, pUnk2);
	}

	// Pass 2: Visible
    for (int i = 0; i < nDataCount; i++)
    {
		arrMeshDraw[i].pMaterial = customMaterial.pMaterial;
		arrMeshDraw[i].colValue = visible_color;
    }

	return true; // we modified it, the caller (hkDrawObject) will call original
}

