#include "../../base.hpp"
#include <dxgi.h>

#include "../../core/sdk/CCSGOInput.hpp"

class CCSPlayerController;
class CUserCmd;

namespace VISUALS
{
	void PreCreateMoveHook(CCSGOInput* input, int slot, char active, CCSPlayerController* localPlayer, CUserCmd* cmd);
	void Present(IDXGISwapChain* pSwapChain, UINT uSyncInterval, UINT uFlags);
}