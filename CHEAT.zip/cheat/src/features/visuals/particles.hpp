#pragma once

namespace Particles
{
    enum Type {
        WORLD_NONE  = 0,
        WORLD_ASHES = 1,
        WORLD_SNOW  = 2,
        WORLD_STARS = 3,
        WORLD_RAIN  = 4,
    };

    // Call every frame (Present hook)
    void Update();
    // Call on DLL unload
    void Release();
}
