#include "particles.hpp"
#include "../../core/memory/memory.hpp"
#include "../../core/interfaces/interfaces.hpp"
#include "../../core/sdk/IGameResourceSystem.hpp"
#include "../../core/sdk/entity.hpp"
#include "../../core/settings.hpp"

#include <vector>
#include <cstdint>

namespace
{
    using CreateIndex_t  = void (__fastcall*)(void*, uint32_t*, const char*, int, __int64, __int64, __int64, int);
    using SetSettings_t  = void (__fastcall*)(void*, uint32_t, int, void*, int);
    using DeleteEffect_t = void (__fastcall*)(void*, int, int, int);

    enum EParticleSetting : int {
        SETTING_POSITION = 0,
        SETTING_DENSITY  = 2,
        SETTING_COLOR    = 16,
    };

    constexpr const char* EMBER_PATH1 = "bin/falling_ember1.vpcf";
    constexpr const char* EMBER_PATH2 = "bin/falling_ember2.vpcf";
    constexpr const char* SNOW_PATH   = "bin/falling_snow1.vpcf";
    constexpr const char* STARS_PATH  = "bin/nomove_stars.vpcf";
    constexpr const char* RAIN_PATH   = "bin/rain.vpcf";

    bool                  g_Broken     = false;
    std::vector<uint32_t> g_Effects;
    uint32_t              g_EffectIdx1 = 0;
    uint32_t              g_EffectIdx2 = 0;
    int                   g_LastType   = -1;
    void*                 g_LastPawnPtr = nullptr;
    bool                  g_LastAlive   = false;

    bool PatternsOk()
    {
        bool haveAccess = MEM::pParticleMgrGlobal || MEM::pParticleGetMgr;
        return haveAccess && MEM::pParticleCreate && MEM::pParticleSetSettings && MEM::pParticleDelete;
    }

    // ---- manager access ----
    static void* SehGetMgrGlobal()
    {
        __try { return *reinterpret_cast<void**>(MEM::pParticleMgrGlobal); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    static void* SehGetMgrLegacy()
    {
        using GetMgr_t = void*(__fastcall*)();
        __try { return reinterpret_cast<GetMgr_t>(MEM::pParticleGetMgr)(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    void* GetManager()
    {
        if (MEM::pParticleMgrGlobal) {
            auto* m = SehGetMgrGlobal();
            if (m) return m;
        }
        if (MEM::pParticleGetMgr)
            return SehGetMgrLegacy();
        return nullptr;
    }

    // ---- effect helpers ----
    static bool SehCreate(void* mgr, uint32_t* outIdx, const char* path)
    {
        __try {
            *outIdx = 0;
            reinterpret_cast<CreateIndex_t>(MEM::pParticleCreate)(mgr, outIdx, path, 2, 0ll, 0ll, 0ll, 0);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    static bool SehDestroy(void* mgr, uint32_t idx)
    {
        if (!idx) return true;
        __try {
            if (MEM::pParticleDelete)
                reinterpret_cast<DeleteEffect_t>(MEM::pParticleDelete)(mgr, static_cast<int>(idx), 1, 1);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    void ForgetEffects()
    {
        g_Effects.clear();
        g_EffectIdx1 = g_EffectIdx2 = 0;
    }

    void DestroyAll()
    {
        if (g_Broken) { ForgetEffects(); return; }
        void* mgr = GetManager();
        if (!mgr) { ForgetEffects(); return; }
        for (uint32_t idx : g_Effects) {
            if (!idx) continue;
            if (!SehDestroy(mgr, idx)) { g_Broken = true; break; }
        }
        ForgetEffects();
    }

    void RecreateForType(void* mgr, int type, bool soft)
    {
        if (soft) ForgetEffects();
        else      DestroyAll();
        if (g_Broken) { g_LastType = type; return; }

        if (type != Particles::WORLD_NONE) {
            const char* p1 = nullptr;
            const char* p2 = nullptr;
            switch (type) {
            case Particles::WORLD_ASHES: p1 = EMBER_PATH1; p2 = EMBER_PATH2; break;
            case Particles::WORLD_SNOW:  p1 = SNOW_PATH;  break;
            case Particles::WORLD_STARS: p1 = STARS_PATH; break;
            case Particles::WORLD_RAIN:  p1 = RAIN_PATH;  break;
            default: break;
            }

            if (p1) {
                uint32_t idx = 0;
                if (!SehCreate(mgr, &idx, p1)) g_Broken = true;
                else if (idx) { g_EffectIdx1 = idx; g_Effects.push_back(idx); }
            }
            if (!g_Broken && p2) {
                uint32_t idx = 0;
                if (!SehCreate(mgr, &idx, p2)) g_Broken = true;
                else if (idx) { g_EffectIdx2 = idx; g_Effects.push_back(idx); }
            }
        }

        g_LastType = type;
    }


    void UpdateInternal(void* mgr, C_CSPlayerPawn* localPawn)
    {
        auto* scene    = localPawn->m_pGameSceneNode();
        vector_t originAbs = scene ? scene->m_vecAbsOrigin() : vector_t{};
        vector_t viewOff   = localPawn->m_vecViewOffset();
        vector_t eyePos    = { originAbs.x + viewOff.x,
                               originAbs.y + viewOff.y,
                               originAbs.z + viewOff.z };

        float density     = Settings::particles_density;
        float densArr[3]  = { density, 0.f, 0.f };
        float color[3]    = { 1.f, 1.f, 1.f };

        auto SetS = reinterpret_cast<SetSettings_t>(MEM::pParticleSetSettings);
        for (uint32_t idx : g_Effects) {
            if (!idx) continue;
            if (idx == g_EffectIdx1) {
                SetS(mgr, idx, SETTING_POSITION, &eyePos,  0);
                SetS(mgr, idx, SETTING_COLOR,    color,    0);
            } else {
                SetS(mgr, idx, SETTING_POSITION, &originAbs, 0);
            }
            SetS(mgr, idx, SETTING_DENSITY, densArr, 0);
        }
    }

    // SEH wrapper: __try can't coexist with C++ objects in the same function (C2712).
    static bool SehUpdateInternal(void* mgr, C_CSPlayerPawn* localPawn)
    {
        __try { UpdateInternal(mgr, localPawn); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
}

namespace Particles
{

void Release()
{
    DestroyAll();
    g_LastType    = -1;
    g_LastPawnPtr = nullptr;
    g_LastAlive   = false;
}

void Update()
{
    if (g_Broken || !PatternsOk()) return;

    int type = Settings::particles_type;

    if (type == WORLD_NONE) {
        if (!g_Effects.empty()) DestroyAll();
        g_LastType = -1;
        g_Broken   = false;
        return;
    }

    void* mgr = GetManager();
    if (!mgr) return;

    const auto local_controller = GetLocalPlayerController();
    if (!local_controller) return;
    auto* localPawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(local_controller->m_hPawn());
    if (!localPawn) return;

    bool alive      = localPawn->m_iHealth() > 0;
    bool pawnChanged = localPawn != g_LastPawnPtr;
    bool revived     = alive && !g_LastAlive;

    // On pawn change or respawn the engine kills all our effects.
    // Forget cached indices and force a recreate.
    if (pawnChanged || revived) {
        g_LastPawnPtr = localPawn;
        g_LastAlive   = alive;
        g_LastType    = -1;
        ForgetEffects();
    } else {
        g_LastAlive = alive;
    }

    if (type != g_LastType) {
        bool soft = g_Effects.empty(); // effects already gone — skip delete calls
        RecreateForType(mgr, type, soft);
        if (g_Broken) return;
    }

    if (g_Effects.empty()) return;

    if (!SehUpdateInternal(mgr, localPawn))
        g_Broken = true;
}

} // namespace Particles
