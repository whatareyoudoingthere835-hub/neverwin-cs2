#include "visuals.hpp"
#include "../hitlogs/hitlogs.hpp"
#include "../../core/interfaces/interfaces.hpp"
#include "../../core/sdk/IGameResourceSystem.hpp"
#include "../../core/sdk/entity.hpp"
#include "../../core/sdk/transform.hpp"
#include "../../core/sdk/iengineclient.hpp"
#include "../../core/settings.hpp"

#include "../../../ext/imgui/imgui.h"

#include <math.h>
#include <algorithm>
#include <windows.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

#include "../../zhironium/src/core.hpp"
#include "../../zhironium/src/kallcode/fonts/fonts.hpp"

#include <deque>
#include <vector>
#include <unordered_map>

struct Hitmarker {
    uint64_t time;
    int damage;
};

struct BulletTrace {
    vector_t start;
    vector_t end;
    float lifetime;
    float maxlife;
    ImU32 color;
};

struct SoundPuddle {
    vector_t pos;
    float lifetime;
    float maxlife;
};

static std::deque<Hitmarker> g_hitmarkers;
static std::deque<BulletTrace> g_traces;
static std::deque<SoundPuddle> g_puddles;
static int g_lastShotsFired = 0;
static vector_t g_lastViewAngles = {0, 0, 0};

inline bool WorldToScreen(vector_t pWorldPos, vector_t& pScreenPos, float* pMatrixPtr, const FLOAT pWinWidth = 1920, const FLOAT pWinHeight = 1080)
{
	float matrix2[4][4];

	memcpy(matrix2, pMatrixPtr, 16 * sizeof(float));

	const float mX{ pWinWidth / 2 };
	const float mY{ pWinHeight / 2 };

	const float w{
		matrix2[3][0] * pWorldPos.x +
		matrix2[3][1] * pWorldPos.y +
		matrix2[3][2] * pWorldPos.z +
		matrix2[3][3] };

	if (w < 0.65f) return false;

	const float x{
		matrix2[0][0] * pWorldPos.x +
		matrix2[0][1] * pWorldPos.y +
		matrix2[0][2] * pWorldPos.z +
		matrix2[0][3] };

	const float y{
		matrix2[1][0] * pWorldPos.x +
		matrix2[1][1] * pWorldPos.y +
		matrix2[1][2] * pWorldPos.z +
		matrix2[1][3] };

	pScreenPos.x = (mX + mX * x / w);
	pScreenPos.y = (mY - mY * y / w);
	pScreenPos.z = 0;

	return true;
}

bool GetEntityBoundingBox(C_CSPlayerPawn* pEntity, ImVec4* pVecOut)
{
	CCollisionProperty* pCollision = pEntity->m_pCollision();
	if (pCollision == nullptr)
		return false;

	CGameSceneNode* pGameSceneNode = pEntity->m_pGameSceneNode();
	if (pGameSceneNode == nullptr)
		return false;

	CTransform nodeToWorldTransform = pGameSceneNode->m_nodeToWorld();
	Matrix3x4_t matTransform = transform(&nodeToWorldTransform.quatOrientation, nodeToWorldTransform.vecPosition);
	//const Matrix3x4_t matTransform = nodeToWorldTransform.quatOrientation.transform(nodeToWorldTransform.vecPosition);

	const vector_t vecMins = pCollision->m_vecMins();
	const vector_t vecMaxs = pCollision->m_vecMaxs();

	pVecOut->x = pVecOut->y = (std::numeric_limits<float>::max)();
	pVecOut->z = pVecOut->w = -(std::numeric_limits<float>::max)();

	for (int i = 0; i < 8; ++i)
	{
		vector_t vecPoint{
			i & 1 ? vecMaxs.x : vecMins.x,
			i & 2 ? vecMaxs.y : vecMins.y,
			i & 4 ? vecMaxs.z : vecMins.z
		};
		vector_t vecScreen;
		if (!WorldToScreen(matTransform.transform(vecPoint), vecScreen, (float*)MEM::pViewMatrix, ImGui::GetIO().DisplaySize.x, ImGui::GetIO().DisplaySize.y))
			return false;

		pVecOut->x = (std::min)(pVecOut->x, vecScreen.x);
		pVecOut->y = (std::min)(pVecOut->y, vecScreen.y);
		pVecOut->z = (std::max)(pVecOut->z, vecScreen.x);
		pVecOut->w = (std::max)(pVecOut->w, vecScreen.y);
	}

	return true;
}

static ImU32 HealthCol(int hp){
    float t = std::clamp(hp / 100.f, 0.f, 1.f);
    return IM_COL32((int)(255 * (1.f - t)), (int)(210 * t), (int)(50 * t), 255);
}

static void DrawCornerBox(ImDrawList* dl, float l, float t, float r, float b, ImU32 col, float thick){
    float lx = (r - l) * 0.22f, ly = (b - t) * 0.22f;
    dl->AddLine({l, t}, {l + lx, t}, col, thick); dl->AddLine({l, t}, {l, t + ly}, col, thick);
    dl->AddLine({r, t}, {r - lx, t}, col, thick); dl->AddLine({r, t}, {r, t + ly}, col, thick);
    dl->AddLine({l, b}, {l + lx, b}, col, thick); dl->AddLine({l, b}, {l, b - ly}, col, thick);
    dl->AddLine({r, b}, {r - lx, b}, col, thick); dl->AddLine({r, b}, {r, b - ly}, col, thick);
}

static void DrawCoalBox(ImDrawList* dl, float l, float t, float r, float b, ImU32 col, float thick){
    float lx = (r - l) * 0.25f, ly = (b - t) * 0.25f;
    dl->AddLine({l, t}, {l + lx, t}, col, thick); dl->AddLine({l, t}, {l, t + ly}, col, thick);
    dl->AddLine({r, t}, {r - lx, t}, col, thick); dl->AddLine({r, t}, {r, t + ly}, col, thick);
    dl->AddLine({l, b}, {l + lx, b}, col, thick); dl->AddLine({l, b}, {l, b - ly}, col, thick);
    dl->AddLine({r, b}, {r - lx, b}, col, thick); dl->AddLine({r, b}, {r, b - ly}, col, thick);
}

static void DrawOutlineBox(ImDrawList* dl, float l, float t, float r, float b, ImU32 col, float thick){
    dl->AddRect({l - 1.f, t - 1.f}, {r + 1.f, b + 1.f}, IM_COL32(0, 0, 0, (int)(235)), 0.f, 0, thick + 1.f);
    dl->AddRect({l + 1.f, t + 1.f}, {r - 1.f, b - 1.f}, IM_COL32(0, 0, 0, (int)(130)), 0.f, 0, thick);
    dl->AddRect({l, t}, {r, b}, col, 0.f, 0, thick);
}

static void DrawOutlineCoalBox(ImDrawList* dl, float l, float t, float r, float b, ImU32 col, float thick){
    ImU32 black = IM_COL32(0, 0, 0, 255);
    DrawCoalBox(dl, l, t, r, b, black, thick + 1.f);
    DrawCoalBox(dl, l + 1.f, t + 1.f, r - 1.f, b - 1.f, col, thick);
    DrawCoalBox(dl, l + 2.f, t + 2.f, r - 2.f, b - 2.f, black, thick);
}

static ImU32 LerpColor(ImU32 c1, ImU32 c2, float t) {
    int r1 = (c1 >> IM_COL32_R_SHIFT) & 0xFF; int g1 = (c1 >> IM_COL32_G_SHIFT) & 0xFF; int b1 = (c1 >> IM_COL32_B_SHIFT) & 0xFF; int a1 = (c1 >> IM_COL32_A_SHIFT) & 0xFF;
    int r2 = (c2 >> IM_COL32_R_SHIFT) & 0xFF; int g2 = (c2 >> IM_COL32_G_SHIFT) & 0xFF; int b2 = (c2 >> IM_COL32_B_SHIFT) & 0xFF; int a2 = (c2 >> IM_COL32_A_SHIFT) & 0xFF;
    int r = (int)(r1 + (r2 - r1) * t);
    int g = (int)(g1 + (g2 - g1) * t);
    int b = (int)(b1 + (b2 - b1) * t);
    int a = (int)(a1 + (a2 - a1) * t);
    return IM_COL32(r, g, b, a);
}

static const char* GetWeaponName(uint16_t defidx) {
    static const std::unordered_map<uint16_t, const char*> k = {
        {1,"Desert Eagle"},{2,"Dual Berettas"},{3,"Five-SeveN"},{4,"Glock-18"},
        {7,"AK-47"},{8,"AUG"},{9,"AWP"},{10,"FAMAS"},{11,"G3SG1"},
        {13,"Galil AR"},{14,"M249"},{16,"M4A4"},{17,"MAC-10"},
        {19,"P90"},{23,"MP5-SD"},{24,"UMP-45"},{25,"XM1014"},
        {26,"PP-Bizon"},{27,"MAG-7"},{28,"Negev"},{29,"Sawed-Off"},
        {30,"Tec-9"},{31,"Zeus x27"},{32,"P2000"},{33,"MP7"},
        {34,"MP9"},{35,"Nova"},{36,"P250"},{38,"SCAR-20"},
        {39,"SG 553"},{40,"SSG 08"},{42,"Flashbang"},{43,"HE Grenade"},
        {44,"Smoke"},{45,"Molotov"},{46,"Decoy"},{47,"Incendiary"},
        {48,"C4"},{60,"M4A1-S"},{61,"USP-S"},{63,"CZ75-Auto"},{64,"R8 Revolver"},
    };
    auto it = k.find(defidx);
    return it != k.end() ? it->second : nullptr;
}

static int GetWeaponMaxClip(uint16_t defidx) {
    static const std::unordered_map<uint16_t, int> k = {
        {1,7},{2,30},{3,20},{4,20},{7,30},{8,30},{9,10},{10,25},
        {11,20},{13,35},{14,100},{16,30},{17,30},{19,50},{23,30},
        {24,25},{25,7},{26,64},{27,5},{28,150},{29,7},{30,18},
        {31,1},{32,13},{33,30},{34,30},{35,8},{36,13},{38,20},
        {39,30},{40,10},{48,1},{60,20},{61,12},{63,12},{64,8},
    };
    auto it = k.find(defidx);
    return it != k.end() ? it->second : 30;
}

void DrawPlayer(CCSPlayerController* controller, C_CSPlayerPawn* pawn)
{
	ImVec4 vecBox = {};
	if (!GetEntityBoundingBox(pawn, &vecBox))
		return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    if (!dl) return;

    auto local_controller = GetLocalPlayerController();
    if (!local_controller) return;
    auto local_pawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(local_controller->m_hPawn());
    if (!local_pawn) return;

    bool enemy = local_pawn->IsOtherEnemy(pawn);
    if (!enemy && !Settings::esp_show_team) return;

    {
        CGameSceneNode* myNode = local_pawn->m_pGameSceneNode();
        CGameSceneNode* theirNode = pawn->m_pGameSceneNode();
        if (myNode && theirNode) {
            float dist = (theirNode->m_vecAbsOrigin() - myNode->m_vecAbsOrigin()).length();
            if (dist > Settings::esp_max_dist) return;
        }
    }

    ImVec4 ecolVec = enemy ? Settings::esp_enemy_col : Settings::esp_team_col;
    float* ecol = &ecolVec.x;

    float alpha = 1.0f; // Visibility check could adjust this
    float s = std::clamp(Settings::esp_scale, 0.7f, 1.5f);
    float boxThick = Settings::esp_box_thick * s;
    float bl = vecBox.x, bt2 = vecBox.y, br = vecBox.z, bb = vecBox.w;
    float bw = br - bl, bh = bb - bt2, cx = (bl + br) * 0.5f;

    ImU32 boxCol = IM_COL32((int)(ecol[0] * 255), (int)(ecol[1] * 255), (int)(ecol[2] * 255), (int)(alpha * 255));
    ImU32 dimCol = IM_COL32(160, 160, 170, (int)(180 * alpha));
    float belowY = bb + 3.f * s;
    const float boxRnd = 3.5f * s;

    if (Settings::esp_box) {
        if (Settings::esp_box_shadow) {
            dl->AddRectFilled({bl + 4.f, bt2 + 4.f}, {br + 4.f, bb + 4.f}, IM_COL32(0, 0, 0, (int)(34 * alpha)), boxRnd + 1.5f);
            dl->AddRectFilled({bl + 2.f, bt2 + 2.f}, {br + 2.f, bb + 2.f}, IM_COL32(0, 0, 0, (int)(48 * alpha)), boxRnd + 0.5f);
        }
        for (int g = 3; g >= 1; g--) {
            int r = (boxCol >> IM_COL32_R_SHIFT) & 0xFF, g_ = (boxCol >> IM_COL32_G_SHIFT) & 0xFF, b = (boxCol >> IM_COL32_B_SHIFT) & 0xFF;
            int ga = (g == 3) ? 30 : (g == 2) ? 16 : 7;
            dl->AddRect({bl - (float)g, bt2 - (float)g}, {br + (float)g, bb + (float)g}, IM_COL32(r, g_, b, (int)(ga * alpha)), 0.f, 0, 1.15f);
        }
        if (Settings::esp_box_style == 0) {
            DrawCornerBox(dl, bl, bt2, br, bb, IM_COL32(0, 0, 0, (int)(200 * alpha)), boxThick + 1.0f);
            DrawCornerBox(dl, bl, bt2, br, bb, boxCol, boxThick);
        }
        else if (Settings::esp_box_style == 1) {
            dl->AddRect({bl, bt2}, {br, bb}, IM_COL32(0, 0, 0, (int)(200 * alpha)), boxRnd, 0, boxThick + 1.0f);
            dl->AddRect({bl, bt2}, {br, bb}, boxCol, boxRnd, 0, boxThick);
        }
        else if (Settings::esp_box_style == 2) {
            dl->AddRectFilled({bl, bt2}, {br, bb}, IM_COL32((int)(ecol[0] * 255), (int)(ecol[1] * 255), (int)(ecol[2] * 255), (int)(42 * alpha)), boxRnd);
            DrawCornerBox(dl, bl, bt2, br, bb, IM_COL32(0, 0, 0, (int)(200 * alpha)), boxThick + 1.0f);
            DrawCornerBox(dl, bl, bt2, br, bb, boxCol, boxThick);
        }
        else if (Settings::esp_box_style == 3) {
            DrawOutlineBox(dl, bl, bt2, br, bb, boxCol, boxThick);
        }
        else if (Settings::esp_box_style == 4) {
            DrawCoalBox(dl, bl, bt2, br, bb, IM_COL32(0, 0, 0, (int)(200 * alpha)), boxThick + 1.0f);
            DrawCoalBox(dl, bl, bt2, br, bb, boxCol, boxThick);
        }
        else if (Settings::esp_box_style == 5) {
            DrawOutlineCoalBox(dl, bl, bt2, br, bb, boxCol, boxThick);
        }
    }

    int hp = pawn->m_iHealth();
    if (Settings::esp_health && hp > 0) {
        float fill = std::clamp((float)hp / 100.f, 0.f, 1.f);
        float barW = 2.f * s, barOff = 8.f * s, barRound = 2.f * s;
        ImU32 hbCol = HealthCol(hp);
        if (Settings::esp_health_style == 1) hbCol = IM_COL32(60, 200, 120, (int)(220 * alpha));
        if (Settings::esp_health_style == 2) hbCol = boxCol;
        
        ImU32 c1 = IM_COL32(255, 60, 60, (int)(240 * alpha));
        ImU32 c2 = IM_COL32(60, 255, 60, (int)(240 * alpha));
        ImU32 cFill = LerpColor(c2, c1, fill);
        ImU32 bgDark = IM_COL32(8, 8, 12, (int)(220 * alpha));
        ImU32 borderCol = IM_COL32(40, 40, 50, (int)(180 * alpha));
        float bx = 0.f, byBar = 0.f;

        if (Settings::esp_health_pos == 0) {
            bx = bl - barOff - barW;
            float fillTop = bt2 + bh * (1.f - fill);
            dl->AddRectFilled({bx - 1.f, bt2 - 1.f}, {bx + barW + 1.f, bb + 1.f}, borderCol, barRound + 1.f);
            dl->AddRectFilled({bx, bt2}, {bx + barW, bb}, bgDark, barRound);
            if (Settings::esp_health_style == 0) {
                dl->AddRectFilled({bx, fillTop}, {bx + barW, bb}, cFill);
            } else {
                dl->AddRectFilled({bx, fillTop}, {bx + barW, bb}, hbCol, barRound);
            }
            byBar = fillTop;
        } else if (Settings::esp_health_pos == 2) {
            bx = br + barOff;
            float fillTop = bt2 + bh * (1.f - fill);
            dl->AddRectFilled({bx - 1.f, bt2 - 1.f}, {bx + barW + 1.f, bb + 1.f}, borderCol, barRound + 1.f);
            dl->AddRectFilled({bx, bt2}, {bx + barW, bb}, bgDark, barRound);
            if (Settings::esp_health_style == 0) {
                dl->AddRectFilledMultiColor({bx, fillTop}, {bx + barW, bb}, cFill, cFill, c2, c2);
            } else {
                dl->AddRectFilled({bx, fillTop}, {bx + barW, bb}, hbCol, barRound);
            }
            byBar = fillTop;
        } else if (Settings::esp_health_pos == 1) {
            float by = bt2 - barOff - barW;
            dl->AddRectFilled({bl - 1.f, by - 1.f}, {br + 1.f, by + barW + 1.f}, borderCol, barRound + 1.f);
            dl->AddRectFilled({bl, by}, {br, by + barW}, bgDark, barRound);
            if (Settings::esp_health_style == 0) {
                dl->AddRectFilledMultiColor({bl, by}, {bl + bw * fill, by + barW}, c2, cFill, cFill, c2);
            } else {
                dl->AddRectFilled({bl, by}, {bl + bw * fill, by + barW}, hbCol, barRound);
            }
        }

        if (hp < 100) {
            char hpBuf[16]; std::snprintf(hpBuf, sizeof(hpBuf), "%d", hp);
            ImFont* font = zhironium::ctx->kallcode->fonts->get( "monospace" ).ptr;
            float fsz = (Settings::esp_health_pos == 1) ? (10.f * s) : (Settings::esp_name_size * 0.85f * s);
            ImVec2 ts = font->CalcTextSizeA(fsz, FLT_MAX, 0.f, hpBuf);
            float tx = bx + (Settings::esp_health_pos == 0 ? barW + 2.f : (Settings::esp_health_pos == 2 ? -ts.x - 2.f : bl + bw * 0.5f - ts.x * 0.5f));
            float ty = (Settings::esp_health_pos == 1) ? bt2 - barOff - barW - ts.y - 1.f : byBar - ts.y * 0.5f;
            dl->AddText(font, fsz, {tx + 1.f, ty + 1.f}, IM_COL32(0, 0, 0, (int)(180 * alpha)), hpBuf);
            dl->AddText(font, fsz, {tx, ty}, IM_COL32(255, 255, 255, (int)(220 * alpha)), hpBuf);
        }
    }

    if (Settings::esp_name) {
        ImFont* font = zhironium::ctx->kallcode->fonts->get( "monospace" ).ptr;
        float nameSize = Settings::esp_name_size * s;
        ImVec2 ts = font->CalcTextSizeA(nameSize, FLT_MAX, 0.f, controller->m_sSanitizedPlayerName());
        float tx = cx - ts.x * 0.5f;
        float ty = bt2 - ts.y - 2.f * s - (Settings::esp_health && Settings::esp_health_pos == 1 ? (5.f * s + 8.f * s) : 0.f);
        dl->AddText(font, nameSize, {tx + 1.f, ty + 1.f}, IM_COL32(0, 0, 0, (int)(140 * alpha)), controller->m_sSanitizedPlayerName());
        dl->AddText(font, nameSize, {tx, ty}, IM_COL32(255, 255, 255, (int)(230 * alpha)), controller->m_sSanitizedPlayerName());
    }

    if (Settings::esp_lines) {
        float sx = ImGui::GetIO().DisplaySize.x * 0.5f;
        float sh = ImGui::GetIO().DisplaySize.y;
        float sy = (Settings::esp_line_anchor == 0) ? 0.f : ((Settings::esp_line_anchor == 2) ? sh : sh * 0.5f);
        int r = (int)(ecol[0] * 255), g_ = (int)(ecol[1] * 255), b = (int)(ecol[2] * 255);
        dl->AddLine({sx, sy}, {cx, bb}, IM_COL32(r, g_, b, (int)(180 * alpha)), 1.5f);
    }

    float textY = bb + 3.f * s;
    ImFont* smallFont = zhironium::ctx->kallcode->fonts->get("monospace").ptr;
    float smallFsz = 10.f * s;

    if (Settings::esp_flags) {
        auto itemSvc = pawn->m_pItemServices();
        if (itemSvc) {
            char flagsBuf[64] = "";
            int fp = 0;
            if (itemSvc->m_bHasHelmet())  fp += std::snprintf(flagsBuf + fp, sizeof(flagsBuf) - fp, "HLM ");
            if (itemSvc->m_bHasDefuser()) fp += std::snprintf(flagsBuf + fp, sizeof(flagsBuf) - fp, "KIT ");
            int armor = pawn->m_ArmorValue();
            if (armor > 0) fp += std::snprintf(flagsBuf + fp, sizeof(flagsBuf) - fp, "%d ARM", armor);
            if (fp > 0) {
                ImVec2 ts = smallFont->CalcTextSizeA(smallFsz, FLT_MAX, 0.f, flagsBuf);
                float tx = cx - ts.x * 0.5f;
                dl->AddText(smallFont, smallFsz, {tx + 1.f, textY + 1.f}, IM_COL32(0, 0, 0, (int)(160 * alpha)), flagsBuf);
                dl->AddText(smallFont, smallFsz, {tx, textY}, IM_COL32(200, 200, 110, (int)(220 * alpha)), flagsBuf);
                textY += ts.y + 1.f * s;
            }
        }
    }

    if (Settings::esp_weapon) {
        auto weaponSvc = pawn->m_pWeaponServices();
        if (weaponSvc) {
            auto weapon = I::GameResourceService->pGameEntitySystem->Get<C_CSWeaponBase>(weaponSvc->m_hActiveWeapon());
            if (weapon) {
                auto* itemView = weapon->m_AttributeManager()->m_Item();
                if (itemView) {
                    uint16_t defidx = itemView->m_iItemDefinitionIndex();
                    const char* wname = GetWeaponName(defidx);
                    char wbuf[32];
                    if (!wname) { std::snprintf(wbuf, sizeof(wbuf), "item_%u", (unsigned)defidx); wname = wbuf; }
                    ImVec2 wts = smallFont->CalcTextSizeA(smallFsz, FLT_MAX, 0.f, wname);
                    float tx = cx - wts.x * 0.5f;
                    dl->AddText(smallFont, smallFsz, {tx + 1.f, textY + 1.f}, IM_COL32(0, 0, 0, (int)(160 * alpha)), wname);
                    dl->AddText(smallFont, smallFsz, {tx, textY}, IM_COL32(220, 220, 220, (int)(220 * alpha)), wname);
                    textY += wts.y + 1.f * s;

                    if (Settings::esp_ammo) {
                        int clip = weapon->m_iClip1();
                        if (clip >= 0) {
                            int maxClip = GetWeaponMaxClip(defidx);
                            float fill = maxClip > 0 ? std::clamp((float)clip / (float)maxClip, 0.f, 1.f) : 1.f;
                            float barH = 3.f * s;
                            ImVec4 c1v = Settings::esp_ammo_col1, c2v = Settings::esp_ammo_col2;
                            ImU32 ca = IM_COL32((int)(c1v.x*255),(int)(c1v.y*255),(int)(c1v.z*255),(int)(alpha*200));
                            ImU32 cb = IM_COL32((int)(c2v.x*255),(int)(c2v.y*255),(int)(c2v.z*255),(int)(alpha*200));
                            dl->AddRectFilled({bl-1.f, textY-1.f},{bl+bw+1.f, textY+barH+1.f}, IM_COL32(40,40,50,(int)(160*alpha)), 1.f);
                            dl->AddRectFilled({bl, textY},{bl+bw, textY+barH}, IM_COL32(8,8,12,(int)(200*alpha)), 1.f);
                            dl->AddRectFilledMultiColor({bl, textY},{bl+bw*fill, textY+barH}, ca, cb, cb, ca);
                            if (Settings::esp_ammo_style == 1) {
                                char abuf[8]; std::snprintf(abuf, sizeof(abuf), "%d", clip);
                                ImVec2 ats = smallFont->CalcTextSizeA(9.f*s, FLT_MAX, 0.f, abuf);
                                float atx = bl + bw + 3.f*s;
                                dl->AddText(smallFont, 9.f*s, {atx+1.f, textY-1.f}, IM_COL32(0,0,0,(int)(140*alpha)), abuf);
                                dl->AddText(smallFont, 9.f*s, {atx, textY-2.f}, IM_COL32(220,220,220,(int)(200*alpha)), abuf);
                            }
                            textY += barH + 2.f*s;
                        }
                    }
                }
            }
        }
    }
}

static vector_t AngleToForward(float pitch, float yaw) {
    float p = pitch * (3.14159265f / 180.f);
    float y = yaw * (3.14159265f / 180.f);
    float cp = cosf(p), sp = sinf(p);
    float cy = cosf(y), sy = sinf(y);
    return { cp * cy, cp * sy, -sp };
}

void VISUALS::PreCreateMoveHook(CCSGOInput* input, int slot, char active, CCSPlayerController* localPlayer, CUserCmd* cmd)
{
	// Viewmodel logic is now handled in hkCalcViewModel to support rotations
	if (cmd && cmd->csgoUserCmd.pBaseCmd && cmd->csgoUserCmd.pBaseCmd->pViewAngles) {
		g_lastViewAngles = cmd->csgoUserCmd.pBaseCmd->pViewAngles->angValue;
	}
}

void VISUALS::Present(IDXGISwapChain* pSwapChain, UINT uSyncInterval, UINT uFlags)
{
	// draw esp
	const auto local_controller = GetLocalPlayerController();
	static int32_t s_prev_hp[65] = {0};
	if (local_controller)
	{
		auto local_pawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(local_controller->m_hPawn());

		if (local_pawn) {
			if (Settings::fov_enabled) {
				CCSPlayerBase_CameraServices* camSvc = local_pawn->m_pCameraServices();
				if (camSvc) {
					camSvc->m_iFOV() = (uint32_t)Settings::fov_value;
				}
			}

			if (Settings::tracers_enabled) {
				int shots = local_pawn->m_iShotsFired();
				if (shots > g_lastShotsFired) {
					CGameSceneNode* node = local_pawn->m_pGameSceneNode();
					if (node) {
						vector_t eye = node->m_vecAbsOrigin() + local_pawn->m_vecViewOffset();
						vector_t fwd = AngleToForward(g_lastViewAngles.x, g_lastViewAngles.y);
						BulletTrace t{};
						t.start = eye;
						t.end = eye + fwd * 3000.f;
						t.maxlife = 1.0f;
						t.lifetime = 1.0f;
						ImVec4 c = Settings::tracers_col;
						t.color = IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), (int)(c.w*255));
						g_traces.push_back(t);
						if (g_traces.size() > 24) g_traces.pop_front();
					}
				}
				g_lastShotsFired = shots;
			} else {
				g_lastShotsFired = local_pawn->m_iShotsFired();
			}
		}

		for (int i = 1; i <= 64; i++)
		{
			auto controller = I::GameResourceService->pGameEntitySystem->Get<CCSPlayerController>(i);
			if (controller == local_controller) continue;
			if (!controller) {
				s_prev_hp[i] = 0;
				continue;
			}
			auto pawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(controller->m_hPawn());
			if (!pawn) {
				s_prev_hp[i] = 0;
				continue;
			}

			// Hitsound & Hitlog logic based on HP tracking
			int32_t curr_hp = pawn->m_iHealth();
			if (local_pawn && local_pawn->IsOtherEnemy(pawn))
			{
				if (s_prev_hp[i] > 0 && curr_hp < s_prev_hp[i])
				{
				    int damage = s_prev_hp[i] - curr_hp;
				    HITLOGS::OnDamage(pawn, controller, damage, curr_hp);
				    
				    if (Settings::hitmarker_enabled) {
				        g_hitmarkers.push_back({ GetTickCount64(), damage });
				    }
				    if (Settings::hitsound_enabled) {
                        if (Settings::hitsound_idx > 0 && Settings::hitsound_idx < Settings::hitsound_list.size()) {
                            std::string filepath = CS_XOR("C:\\Interlope\\hitsounds\\") + Settings::hitsound_list[Settings::hitsound_idx];
                            PlaySoundA(filepath.c_str(), NULL, SND_ASYNC | SND_FILENAME);
                        } else {
                            PlaySoundA(CS_XOR("SystemAsterisk"), NULL, SND_ASYNC | SND_ALIAS);
                        }
                    }
				}
			}
			s_prev_hp[i] = curr_hp;

			if (!controller->m_bPawnIsAlive()) continue;
			if (!local_pawn->IsOtherEnemy(pawn)) continue;

			if (Settings::soundpuddle_enabled) {
			    vector_t vel = pawn->m_vecVelocity();
			    float spd = sqrtf(vel.x * vel.x + vel.y * vel.y);
			    if (spd > 80.f) {
			        SoundPuddle sp;
			        sp.pos = pawn->m_pGameSceneNode()->m_vecAbsOrigin();
			        sp.maxlife = 1.0f;
			        sp.lifetime = 1.0f;
			        g_puddles.push_back(sp);
			        if (g_puddles.size() > 32) g_puddles.pop_front();
			    }
			}

			if (!Settings::esp_enabled) continue;
			DrawPlayer(controller, pawn);
		}
		
		HITLOGS::Draw();

		// Draw Hitmarkers, Kill Effects, Tracers, Puddles
		ImDrawList* dl = ImGui::GetBackgroundDrawList();
		float dt = ImGui::GetIO().DeltaTime;
		
		if (dl) {
		    // Puddles
		    if (Settings::soundpuddle_enabled) {
		        for (auto& p : g_puddles) {
		            p.lifetime -= dt;
		            if (p.lifetime <= 0.f) continue;
		            float a = p.lifetime / p.maxlife;
		            float radius = (1.0f - a) * 200.f * Settings::soundpuddle_scale;
		            vector_t screen;
		            if (WorldToScreen(p.pos, screen, (float*)MEM::pViewMatrix)) {
		                dl->AddCircle({screen.x, screen.y}, radius, IM_COL32(200, 200, 255, (int)(255 * a * Settings::soundpuddle_alpha)), 32, 2.0f);
		            }
		        }
		        g_puddles.erase(std::remove_if(g_puddles.begin(), g_puddles.end(), [](const SoundPuddle& p){return p.lifetime <= 0.f;}), g_puddles.end());
		    }
		    
		    // Tracers
		    if (Settings::tracers_enabled) {
		        for (auto& t : g_traces) {
		            t.lifetime -= dt;
		            if (t.lifetime <= 0.f) continue;
		            float a = std::clamp(t.lifetime / t.maxlife, 0.f, 1.f);
		            vector_t s1, s2;
		            if (WorldToScreen(t.start, s1, (float*)MEM::pViewMatrix) && WorldToScreen(t.end, s2, (float*)MEM::pViewMatrix)) {
		                int r = (t.color >> IM_COL32_R_SHIFT) & 0xFF;
		                int g_ = (t.color >> IM_COL32_G_SHIFT) & 0xFF;
		                int b = (t.color >> IM_COL32_B_SHIFT) & 0xFF;
		                dl->AddLine({s1.x, s1.y}, {s2.x, s2.y}, IM_COL32(r, g_, b, (int)(255 * a)), 2.0f);
		            }
		        }
		        g_traces.erase(std::remove_if(g_traces.begin(), g_traces.end(), [](const BulletTrace& t){return t.lifetime <= 0.f;}), g_traces.end());
		    }

		    // Hitmarkers
		    if (Settings::hitmarker_enabled) {
		        ImVec2 center = { ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f };
		        for (auto& hm : g_hitmarkers) {
		            float elapsed = (GetTickCount64() - hm.time) / 1000.f;
		            if (elapsed >= Settings::hitmarker_duration) continue;
		            float a = 1.0f - (elapsed / Settings::hitmarker_duration);
		            float len = 8.0f;
		            dl->AddLine({center.x - len, center.y - len}, {center.x + len, center.y + len}, IM_COL32(255, 255, 255, (int)(255 * a)), 2.0f);
		            dl->AddLine({center.x - len, center.y + len}, {center.x + len, center.y - len}, IM_COL32(255, 255, 255, (int)(255 * a)), 2.0f);
		        }
		        g_hitmarkers.erase(std::remove_if(g_hitmarkers.begin(), g_hitmarkers.end(), [](const Hitmarker& hm){ return (GetTickCount64() - hm.time) / 1000.f >= Settings::hitmarker_duration; }), g_hitmarkers.end());
		    }
		}
	}
}