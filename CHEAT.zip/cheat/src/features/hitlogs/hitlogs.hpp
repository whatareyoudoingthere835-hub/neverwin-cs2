#pragma once
#include "../../base.hpp"
#include "../../core/sdk/entity.hpp"
#include <dxgi.h>

namespace HITLOGS {
    void Draw();
    void OnDamage(C_CSPlayerPawn* pawn, CCSPlayerController* controller, int damage, int curr_hp);
}
