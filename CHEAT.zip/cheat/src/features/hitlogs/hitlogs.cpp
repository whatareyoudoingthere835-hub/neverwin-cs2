#include "hitlogs.hpp"
#include "../../core/settings.hpp"
#include "../../../ext/imgui/imgui.h"
#include "../../../ext/imgui/imgui_internal.h"
#include "../../zhironium/src/kallcode/ui/elem/elem.hpp"
#include <deque>
#include <string>
#include <thread>
#include <atomic>
#include <windows.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

#include "../../core/interfaces/interfaces.hpp"
#include "../../core/sdk/iengineclient.hpp"

struct HitlogEntry {
    std::string text;
    float time;
    ImColor color;
};
static std::deque<HitlogEntry> s_hitlogs;

static std::string StripColorTags(const std::string& data) {
    std::string out;
    out.reserve(data.size());
    bool insideTag = false;
    for (char c : data) {
        if (c == '<') { insideTag = true; continue; }
        if (c == '>') { insideTag = false; continue; }
        if (!insideTag) out.push_back(c);
    }
    return out;
}

static void RenderColoredText(ImDrawList* draw, ImVec2 pos, const std::string& text, float alpha) {
    ImColor currentColor = ImColor(1.f, 1.f, 1.f, alpha);
    float x = pos.x;
    float y = pos.y;
    const char* s = text.c_str();
    const char* end = s + text.size();

    while (s < end) {
        const char* tagStart = strstr(s, "<color=");
        if (!tagStart) {
            ImVec2 size = ImGui::CalcTextSize(s);
            draw->AddText({ x, y }, currentColor, s);
            x += size.x;
            break;
        }

        if (tagStart > s) {
            std::string before(s, tagStart - s);
            ImVec2 size = ImGui::CalcTextSize(before.c_str());
            draw->AddText({ x, y }, currentColor, before.c_str());
            x += size.x;
        }

        const char* colorStart = tagStart + 7;
        const char* colorEnd = strchr(colorStart, '>');
        if (!colorEnd) break;

        std::string hex(colorStart, colorEnd - colorStart);
        unsigned int r = 255, g = 255, b = 255;
        if (hex.size() == 7 && hex[0] == '#') {
            auto parseHex = [](const std::string& str) -> unsigned int {
                unsigned int val = 0;
                for (char c : str) {
                    val *= 16;
                    if (c >= '0' && c <= '9') val += c - '0';
                    else if (c >= 'a' && c <= 'f') val += c - 'a' + 10;
                    else if (c >= 'A' && c <= 'F') val += c - 'A' + 10;
                    else return 255; // Invalid hex char, fallback to white
                }
                return val;
            };
            r = parseHex(hex.substr(1, 2));
            g = parseHex(hex.substr(3, 2));
            b = parseHex(hex.substr(5, 2));
        }

        currentColor = ImColor((int)r, (int)g, (int)b, (int)(255 * alpha));

        const char* closeTag = strstr(colorEnd + 1, "</color>");
        if (!closeTag) break;

        std::string coloredText(colorEnd + 1, closeTag - (colorEnd + 1));
        ImVec2 size = ImGui::CalcTextSize(coloredText.c_str());
        draw->AddText({ x, y }, currentColor, coloredText.c_str());
        x += size.x;

        s = closeTag + 8;
        currentColor = ImColor(255, 255, 255, (int)(255 * alpha));
    }
}

void HITLOGS::OnDamage(C_CSPlayerPawn* pawn, CCSPlayerController* controller, int damage, int curr_hp) {
    /*
    if (!pawn || !controller) return;
    
    if (Settings::misc_hitlogs) {
        // Hitgroup offset is invalid in current schema without player_hurt event
        // We removed hitgroup names from hitlog to match Zhironium, so we don't need it.
        
        char log_buf[512];
        char plain_buf[256];
        if (curr_hp <= 0) {
            snprintf(log_buf, sizeof(log_buf), "Killed <color=#599cff>%s</color> for <color=#ff6969>%d</color> damage", controller->m_sSanitizedPlayerName(), damage);
            snprintf(plain_buf, sizeof(plain_buf), "[Interlope] Killed %s for %d damage\n", controller->m_sSanitizedPlayerName(), damage);
        } else {
            snprintf(log_buf, sizeof(log_buf), "Hit <color=#599cff>%s</color> for <color=#ff6969>%d</color> damage", controller->m_sSanitizedPlayerName(), damage);
            snprintf(plain_buf, sizeof(plain_buf), "[Interlope] Hit %s for %d damage\n", controller->m_sSanitizedPlayerName(), damage);
        }
        
        if (Settings::misc_hitlogs_output == 0) {
            s_hitlogs.push_back({ std::string(log_buf), (float)ImGui::GetTime(), ImColor(255, 255, 255, 255) });
            if (s_hitlogs.size() > 10) s_hitlogs.pop_front();
        } else if (Settings::misc_hitlogs_output == 1) {
            char chat_cmd[256];
            snprintf(chat_cmd, sizeof(chat_cmd), "say \"%s\"\n", plain_buf);
            I::EngineClient->ExecuteClientCmd(chat_cmd);
        }
        
        if (Settings::misc_hitlogs_console) {
            struct ConColor { unsigned char r, g, b, a; };
            using find_channel_fn_t = int(__cdecl *)(const char *name);
            static auto s_find_channel = (find_channel_fn_t)GetProcAddress(GetModuleHandleA("tier0.dll"), "LoggingSystem_FindChannel");
            using log_direct_fn_t = int(__cdecl *)(int id, int severity, ConColor color, const char *msg);
            static auto s_log_direct = (log_direct_fn_t)GetProcAddress(GetModuleHandleA("tier0.dll"), "LoggingSystem_LogDirect");
            
            if (s_find_channel && s_log_direct) {
                static int s_channel_id = s_find_channel("Console");
                ConColor color = { 255, 105, 105, 255 }; // Light red
                s_log_direct(s_channel_id, 0, color, plain_buf);
            }
        }
    }
    */

}

void HITLOGS::Draw() {
    /*
    if (!Settings::misc_hitlogs || s_hitlogs.empty()) return;
    
    ImFont* font = ImGui::GetIO().Fonts->Fonts.Size > 0 ? ImGui::GetIO().Fonts->Fonts[0] : ImGui::GetFont();
    if (!font) return; // Prevent crash if font is not loaded
    
    float y_offset = 10.0f;
    float current_time = ImGui::GetTime();
    
    for (auto it = s_hitlogs.begin(); it != s_hitlogs.end();) {
        float diff = current_time - it->time;
        if (diff > 5.0f) {
            it = s_hitlogs.erase(it);
            continue;
        }
        
        float alpha = 1.0f;
        if (diff > 4.0f) {
            alpha = (1.0f - (diff - 4.0f));
        }
        
        ImGui::PushFont(font);
        std::string strippedText = StripColorTags(it->text);
        ImVec2 text_size = font->CalcTextSizeA(14.0f, FLT_MAX, 0.0f, strippedText.c_str());
        ImGui::PopFont();
        
        ImVec2 min_pos = ImVec2(10.0f, y_offset);
        ImVec2 max_pos = ImVec2(10.0f + text_size.x + 30.0f, y_offset + text_size.y + 16.0f);

        ImRect wnd_rect = { min_pos, max_pos };
        ImGui::GetBackgroundDrawList()->AddRectFilled(min_pos, max_pos, ImColor(20, 20, 20, (int)(220.0f * alpha)), 10.0f);
        kallcode::CUIElements::applyLiquidGlass( [&]( ImDrawList* draw ) -> void {
            draw->AddRect( min_pos, max_pos, ImColor( 32, 32, 32, (int)(alpha * 255) ), 10.0f, 0, 1.0f );
        }, ImGui::GetBackgroundDrawList(), wnd_rect, ImColor( 32, 32, 32 ), ImColor( 255, 255, 255 ) );
        
        ImGui::PushFont(font);
        RenderColoredText(ImGui::GetBackgroundDrawList(), ImVec2(min_pos.x + 15.0f, min_pos.y + 8.0f), it->text, alpha);
        ImGui::PopFont();
        
        y_offset += (max_pos.y - min_pos.y) + 5.0f;
        ++it;
    }
    */
}
