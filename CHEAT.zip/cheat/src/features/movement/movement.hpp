#include "../../base.hpp"
#include "../../core/sdk/CCSGOInput.hpp"
#include "../../core/sdk/CCSGOInput.hpp"

namespace MV
{
	void __fastcall PreCreateMoveHook(CCSGOInput* input, int slot, char active, CCSPlayerController* local_player, CUserCmd* cmd);
}