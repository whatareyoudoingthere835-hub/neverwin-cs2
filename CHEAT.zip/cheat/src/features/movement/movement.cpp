#include "movement.hpp"
#include "../../core/interfaces/interfaces.hpp"
#include "../../core/sdk/IGameResourceSystem.hpp"
#include "../../core/sdk/enums.hpp"
#include "../../core/settings.hpp"
// params between funcs
static CCSPlayerController* g_local_player = nullptr;
static C_CSPlayerPawn* g_local_pawn = nullptr;
static vector_t g_view{};

static CUserCmd* g_cmd;
static CCSGOInput* g_input;

void bunny_hop()
{
	if (!Settings::movement_bhop) return;

	if (!(g_cmd->nButtons.nValue & IN_JUMP || g_cmd->nButtons.nValueScroll & IN_JUMP)) {
		return;
	}

	g_cmd->nButtons.nValue &= ~IN_JUMP;
	g_cmd->nButtons.nValueScroll &= ~IN_JUMP;
	g_cmd->nButtons.nValueChanged &= ~IN_JUMP;

	if (!(g_local_pawn->m_fFlags() & FL_ONGROUND)) return;

	g_cmd->nButtons.nValue |= IN_JUMP;
	g_cmd->nButtons.nValueChanged |= IN_JUMP;

	auto subtick = g_cmd->csgoUserCmd.pBaseCmd->add_subtick_move();
	subtick->flWhen = 0;
	//subtick->flWhen = g_input->GetSubtickFraction();
	subtick->nButton = IN_JUMP;
	subtick->bPressed = true;
}

void auto_strafe()
{
	static bool dir = 1;
	auto val = 0.5f;

	if (g_local_pawn->m_fFlags() & FL_ONGROUND)
	{
		dir = 1;
		return;
	}

	auto last_impulse = g_local_pawn->m_pMovementServices()->m_vecLastMovementImpulses();
	auto vel = g_local_pawn->m_vecVelocity();
	auto view = g_input->GetViewAngles();
	vector_t forward, right, up;
	AngleVectors(view, &forward, &right, &up);
	auto direct = forward + right + up;
	bool is_same_dir = vel.dot_product(direct) > 0;
	g_cmd->nButtons.nValue |= IN_MOVERIGHT;
	g_cmd->csgoUserCmd.pBaseCmd->flSideMove = (dir ? 1.f : -1.f) * (is_same_dir ? 1 : -1);
	g_cmd->csgoUserCmd.pBaseCmd->flForwardMove = 0.f;
	g_cmd->csgoUserCmd.pBaseCmd->pViewAngles->angValue = { view.x, view.y + (dir ? val : -val), 0 };

	//auto move = g_cmd->csgoUserCmd.pBaseCmd->add_subtick_move();
	//move->bPressed = true;
	//move->flWhen = g_input->GetSubtickFraction();
	//move->nButton |= IN_MOVERIGHT;

	//if (g_cmd->csgoUserCmd.pBaseCmd->subtickMovesField.nCurrentSize >= 32) return;
	//for (int i = g_cmd->csgoUserCmd.pBaseCmd->subtickMovesField.nCurrentSize; i < 32; i++)
	//{
	//	auto move = g_cmd->csgoUserCmd.pBaseCmd->add_subtick_move();
	//	move->bPressed = true;
	//	move->flWhen = i * 1/32;
	//	move->nButton = dir ? IN_MOVERIGHT : IN_MOVELEFT;
	//	move->flAnalogLeftDelta = dir ? -1.f : 1.f;
	//	move->flAnalogForwardDelta = 0.f;

	//	dir = !dir;
	//}
	if (g_cmd->csgoUserCmd.pBaseCmd->subtickMovesField.nCurrentSize >= 32) return;
	for (int i = g_cmd->csgoUserCmd.pBaseCmd->subtickMovesField.nCurrentSize; i < 32; i++)
	{
		auto move = g_cmd->csgoUserCmd.pBaseCmd->add_subtick_move();
		move->flWhen = i / 32.0f;
		move->flAnalogLeftDelta = g_cmd->csgoUserCmd.pBaseCmd->flSideMove - last_impulse.y;
		last_impulse.y += move->flAnalogLeftDelta;
	}

	g_input->SetViewAngle(&g_cmd->csgoUserCmd.pBaseCmd->pViewAngles->angValue);
	dir = !dir;
}

void __fastcall MV::PreCreateMoveHook(CCSGOInput* input, int slot, char active, CCSPlayerController* local_player, CUserCmd* cmd)
{
	g_input = input;
	g_cmd = cmd;

	g_local_player = local_player;
	g_local_pawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(g_local_player->m_hPawn());

	// Thirdperson spoofing removed

	if (!g_local_player || !g_local_pawn || !g_local_pawn->m_iHealth()) return;
	g_view = input->GetViewAngles();

	bunny_hop();
	//auto_strafe();
}