#pragma once
#include "../../base.hpp"
#include "../../core/sdk/sceneobject.hpp"

namespace world_modulation
{
	void* __fastcall UpdateSceneObject(C_AggregateSceneObject* object, void* unk);
}