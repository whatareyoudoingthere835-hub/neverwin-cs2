#include "worldmodulation.hpp"

void* __fastcall world_modulation::UpdateSceneObject(C_AggregateSceneObject* object, void* unk)
{
    if (true)
    {
        //Color colors = config.visuals.modulation.world->get();

        for (int i = 0; i < object->m_nCount; i++)
        {
            object->m_pData[i].r = 255;
            object->m_pData[i].g = 100;
            object->m_pData[i].b = 0;
        }
    }

    return nullptr;
}