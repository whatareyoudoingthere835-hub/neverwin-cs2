#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <winhttp.h>
#include <shellapi.h>

#include "spotify.hpp"
#include "../../core/settings.hpp"
#include "../../base.hpp"
#include "../../zhironium/thirdparty/json/json.hpp"
#include <string>
#include <thread>
#include <atomic>
#include <iostream>
#include <fstream>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "ws2_32.lib")

using json = nlohmann::json;

namespace SPOTIFY
{
    std::string currentTrack = "";
    std::string currentAuthor = "";
    bool isPlaying = false;
    std::string accessToken = "";
    std::atomic<bool> authorized = false;
    std::atomic<bool> authThreadRunning = false;
    std::atomic<bool> updateThreadRunning = false;

    std::string xor_crypt(std::string data)
    {
        const char* key = CS_XOR("AudioStreamCacheKey_9x1");
        size_t key_len = strlen(key);
        for (size_t i = 0; i < data.size(); ++i) {
            data[i] ^= key[i % key_len];
        }
        return data;
    }

    void SaveData()
    {
        CreateDirectoryA(CS_XOR("C:\\Interlope"), NULL);
        std::ofstream out(CS_XOR("C:\\Interlope\\spotify.dat"), std::ios::binary);
        if (out.is_open())
        {
            json j;
            j["client_id"] = std::string(Settings::spotify_client_id);
            j["client_secret"] = std::string(Settings::spotify_client_secret);
            j["refresh_token"] = std::string(Settings::spotify_refresh_token);
            std::string data = j.dump();
            data = xor_crypt(data);
            out.write(data.c_str(), data.size());
            out.close();
        }
    }

    void LoadData()
    {
        std::ifstream in(CS_XOR("C:\\Interlope\\spotify.dat"), std::ios::binary);
        if (in.is_open())
        {
            std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
            if (content.empty()) return;
            in.close();
            content = xor_crypt(content);
            try {
                json j = json::parse(content);
                strcpy_s(Settings::spotify_client_id, std::string(j["client_id"]).c_str());
                strcpy_s(Settings::spotify_client_secret, std::string(j["client_secret"]).c_str());
                strcpy_s(Settings::spotify_refresh_token, std::string(j["refresh_token"]).c_str());
            } catch (...) {}
        }
    }

    std::string HttpRequest(const std::wstring& host, const std::wstring& path, const std::wstring& method, const std::wstring& headers, const std::string& body)
    {
        std::string response = "";
        HINTERNET hSession = WinHttpOpen(CS_XOR(L"WinHttpClient/1.0"), WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (hSession)
        {
            HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
            if (hConnect)
            {
                HINTERNET hRequest = WinHttpOpenRequest(hConnect, method.c_str(), path.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
                if (hRequest)
                {
                    if (headers.length() > 0)
                        WinHttpAddRequestHeaders(hRequest, headers.c_str(), (DWORD)-1, WINHTTP_ADDREQ_FLAG_ADD);

                    BOOL bResults = WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, (LPVOID)body.c_str(), (DWORD)body.length(), (DWORD)body.length(), 0);
                    if (bResults)
                    {
                        bResults = WinHttpReceiveResponse(hRequest, NULL);
                        if (bResults)
                        {
                            DWORD dwSize = 0;
                            DWORD dwDownloaded = 0;
                            do
                            {
                                dwSize = 0;
                                if (!WinHttpQueryDataAvailable(hRequest, &dwSize))
                                    break;

                                if (dwSize == 0)
                                    break;

                                char* pszOutBuffer = new char[dwSize + 1];
                                if (!pszOutBuffer)
                                    break;
                                
                                ZeroMemory(pszOutBuffer, dwSize + 1);
                                if (WinHttpReadData(hRequest, (LPVOID)pszOutBuffer, dwSize, &dwDownloaded))
                                    response += pszOutBuffer;
                                
                                delete[] pszOutBuffer;
                            } while (dwSize > 0);
                        }
                    }
                    WinHttpCloseHandle(hRequest);
                }
                WinHttpCloseHandle(hConnect);
            }
            WinHttpCloseHandle(hSession);
        }
        return response;
    }

    // char* convert
    std::wstring ToWString(const std::string& str)
    {
        if (str.empty()) return std::wstring();
        int size_needed = MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), NULL, 0);
        std::wstring wstrTo(size_needed, 0);
        MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), &wstrTo[0], size_needed);
        return wstrTo;
    }

    void RefreshToken()
    {
        if (strlen(Settings::spotify_refresh_token) == 0) return;

        std::string body = CS_XOR("grant_type=refresh_token&refresh_token=") + std::string(Settings::spotify_refresh_token) + CS_XOR("&client_id=") + std::string(Settings::spotify_client_id) + CS_XOR("&client_secret=") + std::string(Settings::spotify_client_secret);
        std::wstring headers = ToWString(CS_XOR("Content-Type: application/x-www-form-urlencoded\r\n"));

        std::string response = HttpRequest(ToWString(CS_XOR("accounts.spotify.com")), ToWString(CS_XOR("/api/token")), L"POST", headers, body);
        try
        {
            auto j = json::parse(response);
            if (j.contains(CS_XOR("access_token")))
            {
                accessToken = j[CS_XOR("access_token")].get<std::string>();
                if (j.contains(CS_XOR("refresh_token")))
                {
                    std::string newRefresh = j[CS_XOR("refresh_token")].get<std::string>();
                    strcpy_s(Settings::spotify_refresh_token, newRefresh.c_str());
                    SaveData();
                }
                authorized = true;
            }
            else
            {
                authorized = false;
            }
        }
        catch (...) { authorized = false; }
    }

    void AuthListenerThread()
    {
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
        {
            authThreadRunning = false;
            return;
        }

        SOCKET ListenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (ListenSocket == INVALID_SOCKET)
        {
            WSACleanup();
            authThreadRunning = false;
            return;
        }

        sockaddr_in serverAddr;
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        serverAddr.sin_port = htons(8888);

        if (bind(ListenSocket, (SOCKADDR*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
        {
            closesocket(ListenSocket);
            WSACleanup();
            authThreadRunning = false;
            return;
        }

        listen(ListenSocket, 1);
        SOCKET ClientSocket = accept(ListenSocket, NULL, NULL);
        if (ClientSocket != INVALID_SOCKET)
        {
            char recvbuf[4096];
            int iResult = recv(ClientSocket, recvbuf, sizeof(recvbuf), 0);
            if (iResult > 0)
            {
                std::string request(recvbuf, iResult);
                std::string code = "";
                size_t codePos = request.find(CS_XOR("code="));
                if (codePos != std::string::npos)
                {
                    size_t endPos = request.find(CS_XOR(" "), codePos);
                    if (endPos != std::string::npos)
                        code = request.substr(codePos + 5, endPos - codePos - 5);
                }

                
                std::string httpResp = CS_XOR("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<html><body><h2>Successfully authorized! You can close this window and return to the game.</h2></body></html>");
                send(ClientSocket, httpResp.c_str(), (int)httpResp.length(), 0);

                if (!code.empty())
                {
                    
                    std::string body = CS_XOR("grant_type=authorization_code&code=") + code + CS_XOR("&redirect_uri=http://127.0.0.1:8888/callback&client_id=") + std::string(Settings::spotify_client_id) + CS_XOR("&client_secret=") + std::string(Settings::spotify_client_secret);
                    std::wstring headers = ToWString(CS_XOR("Content-Type: application/x-www-form-urlencoded\r\n"));

                    std::string tokenResp = HttpRequest(ToWString(CS_XOR("accounts.spotify.com")), ToWString(CS_XOR("/api/token")), L"POST", headers, body);
                    try
                    {
                        auto j = json::parse(tokenResp);
                        if (j.contains(CS_XOR("access_token")) && j.contains(CS_XOR("refresh_token")))
                        {
                            accessToken = j[CS_XOR("access_token")].get<std::string>();
                            std::string refreshToken = j[CS_XOR("refresh_token")].get<std::string>();
                            strcpy_s(Settings::spotify_refresh_token, refreshToken.c_str());
                            authorized = true;
                            SaveData();
                        }
                    }
                    catch (...) {}
                }
            }
            closesocket(ClientSocket);
        }
        closesocket(ListenSocket);
        WSACleanup();
        authThreadRunning = false;
    }

    void Authenticate()
    {
        if (strlen(Settings::spotify_client_id) == 0) return;
        if (authThreadRunning) return;

        authThreadRunning = true;
        std::thread(AuthListenerThread).detach();

        std::string url = CS_XOR("https://accounts.spotify.com/authorize?client_id=") + std::string(Settings::spotify_client_id) + CS_XOR("&response_type=code&redirect_uri=http://127.0.0.1:8888/callback&scope=user-read-currently-playing");
        ShellExecuteA(0, 0, url.c_str(), 0, 0, SW_SHOW);
    }

    bool IsAuthorized()
    {
        return authorized;
    }

    void UpdateLoop()
    {
        while (updateThreadRunning)
        {
            if (authorized && !accessToken.empty())
            {
                std::wstring headers = ToWString(CS_XOR("Authorization: Bearer ") + accessToken + CS_XOR("\r\n"));
                std::string response = HttpRequest(ToWString(CS_XOR("api.spotify.com")), ToWString(CS_XOR("/v1/me/player/currently-playing")), L"GET", headers, "");

                try
                {
                    if (response.empty() || response.find(CS_XOR("error")) != std::string::npos)
                    {
                        
                        RefreshToken();
                    }
                    else
                    {
                        auto j = json::parse(response);
                        if (j.contains(CS_XOR("is_playing")) && j[CS_XOR("is_playing")].get<bool>())
                        {
                            isPlaying = true;
                            if (j.contains(CS_XOR("item")))
                            {
                                currentTrack = j[CS_XOR("item")][CS_XOR("name")].get<std::string>();
                                if (j[CS_XOR("item")].contains(CS_XOR("artists")) && j[CS_XOR("item")][CS_XOR("artists")].size() > 0)
                                {
                                    currentAuthor = j[CS_XOR("item")][CS_XOR("artists")][0][CS_XOR("name")].get<std::string>();
                                }
                            }
                        }
                        else
                        {
                            isPlaying = false;
                        }
                    }
                }
                catch (...) { }
            }
            else if (strlen(Settings::spotify_refresh_token) > 0 && !authorized)
            {
                
                RefreshToken();
            }

            std::this_thread::sleep_for(std::chrono::seconds(2));
        }
    }

    bool Initialize()
    {
        LoadData();
        if (updateThreadRunning) return true;
        updateThreadRunning = true;
        std::thread(UpdateLoop).detach();
        return true;
    }

    void Update()
    {
        
    }

    std::string GetCurrentTrack()
    {
        return currentTrack;
    }

    std::string GetCurrentAuthor()
    {
        return currentAuthor;
    }

    bool IsPlaying()
    {
        return authorized && isPlaying;
    }
}
