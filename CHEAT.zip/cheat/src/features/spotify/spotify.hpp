#ifndef SPOTIFY_HPP
#define SPOTIFY_HPP

#include <string>

namespace SPOTIFY
{
    bool Initialize();
    void Authenticate();
    bool IsAuthorized();
    void Update();
    std::string GetCurrentTrack();
    std::string GetCurrentAuthor();
    bool IsPlaying();
}

#endif
