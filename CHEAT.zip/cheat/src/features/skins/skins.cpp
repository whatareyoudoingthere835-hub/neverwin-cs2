#include "skins.hpp"
#include "../../core/interfaces/interfaces.hpp"
#include "../../core/sdk/IGameResourceSystem.hpp"

uintptr_t* find_hud_element(const char* name)
{
	using fn_find_hud_element = uintptr_t * (__fastcall*)(const char*);
	static fn_find_hud_element find_hud_element_ = (fn_find_hud_element)MEM::FindPattern(CLIENT_DLL, "4C 8B DC 53 48 83 EC ? 48 8B 05");
	return find_hud_element_(name);
}

C_CS2HudModelArms* get_view_arms(C_CSPlayerPawn* pawn)
{
	auto a = pawn->m_hHudModelArms();
	C_CS2HudModelArms* m_hud_model = I::GameResourceService->pGameEntitySystem->Get<C_CS2HudModelArms>(pawn->m_hHudModelArms());
	if (!m_hud_model)
		return nullptr;
	return m_hud_model;
}

std::vector<C_CS2HudModelWeapon*> get_view_models(C_CSPlayerPawn* pawn)
{
	C_CS2HudModelArms* pViewArms = get_view_arms(pawn); // m_hHudModelArms
	if (!pViewArms)
		return {};

	auto pGameSceneNode = pViewArms->m_pGameSceneNode();
	if (!pGameSceneNode) {
		return {};
	}

	std::vector<C_CS2HudModelWeapon*> vecViewModels = {};
	for (CGameSceneNode* pChild = pGameSceneNode->m_pChild(); pChild; pChild = pChild->m_pNextSibling()) {
		C_BaseEntity* pOwner = reinterpret_cast<C_BaseEntity*>(pChild->m_pOwner());
		if (!pOwner) {
			continue;
		}
		SchemaClassInfoData_t* pClassInfo = pOwner->GetSchemaClassInfo();
		if (pClassInfo && strcmp(pClassInfo->szName, "C_CS2HudModelWeapon") == 0) { // pOwner->GetClassName() == "C_CS2HudModelWeapon"
			vecViewModels.push_back(reinterpret_cast<C_CS2HudModelWeapon*>(pOwner));
		}
	}

	return vecViewModels;
}

C_CS2HudModelWeapon* get_view_model_brutforce(C_CSPlayerPawn* pawn)
{
	auto pWeapon = I::GameResourceService->pGameEntitySystem->Get<C_BaseEntity>(pawn->m_pWeaponServices()->m_hActiveWeapon()); // CPlayer_WeaponServices -> m_hActiveWeapon

	std::vector<C_CS2HudModelWeapon*> vecViewModels = get_view_models(pawn);
	if (vecViewModels.empty()) {
		return nullptr;
	}

	for (C_CS2HudModelWeapon* pViewModel : vecViewModels) {
		auto pOwner = I::GameResourceService->pGameEntitySystem->Get<C_BaseEntity>(pViewModel->m_hOwnerEntity());
		if (!pOwner) {
			continue;
		}

		if (pOwner == pWeapon) {
			return pViewModel;
		}
	}

	return nullptr;
}

void clear_hud_weapon()
{
	auto hud_weapon_selection = (uintptr_t)find_hud_element(CS_XOR("HudWeaponSelection"));
	if (!hud_weapon_selection)
		return;

	uintptr_t hud_weapons = hud_weapon_selection - 0x98;
	if (!hud_weapons)
		return;

	using fn_clear_hud_weapon = int(__fastcall*)(uintptr_t, int, void*);
	static fn_clear_hud_weapon fn_clear_hud_weapon_ = nullptr;

	if (!fn_clear_hud_weapon_)
		return;

	if (!MEM::pWorld)
		return;

	fn_clear_hud_weapon_(hud_weapons, 0, MEM::pWorld);
}

void weapons()
{
	const auto local_controller = GetLocalPlayerController();
	if (!local_controller) return;
	auto local_pawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(local_controller->m_hPawn());

	if (!local_pawn || local_pawn->m_iHealth() <= 0) return;

	auto weaponSvc = local_pawn->m_pWeaponServices();
	if (!weaponSvc) return;
	auto weapons = weaponSvc->m_hMyWeapons();

	CBaseHandle hActiveWeapon = weaponSvc->m_hActiveWeapon();
	auto view_model = get_view_model_brutforce(local_pawn);

	for (int i = 0; i < weapons.nSize; i++)
	{
		auto weapon = I::GameResourceService->pGameEntitySystem->Get<C_BasePlayerWeapon>(weapons.pElements[i]);
		if (!weapon) continue;

		auto attribute_manager = weapon->m_AttributeManager();
		if (!attribute_manager) continue;

		auto item_view = attribute_manager->m_Item();
		if (!item_view) continue;

		auto item_def_index = item_view->m_iItemDefinitionIndex();

		if (item_def_index >= SKINS::skins_size) continue;

		// knives: route any defindex 500-600 to the universal knife slot [500]
		bool is_knife = (item_def_index >= 500 && item_def_index < 600);
		uint16_t cfg_index = is_knife ? 500 : item_def_index;
		auto& weapon_cfg = SKINS::skins_cfg[cfg_index];
		if (weapon_cfg.FallbackPaintKit == -1) continue;

		bool needs = weapon_cfg.needs_apply ||
		             weapon->m_nFallbackPaintKit() != weapon_cfg.FallbackPaintKit ||
		             weapon->m_flFallbackWear()     != weapon_cfg.FallbackWear     ||
		             weapon->m_nFallbackSeed()      != weapon_cfg.FallbackSeed     ||
		             weapon->m_nFallbackStatTrak()  != weapon_cfg.FallbackStatTrak;

		if (needs)
		{
			weapon_cfg.needs_apply = false;

			weapon->m_nFallbackPaintKit() = weapon_cfg.FallbackPaintKit;
			weapon->m_flFallbackWear()    = weapon_cfg.FallbackWear;
			weapon->m_nFallbackSeed()     = weapon_cfg.FallbackSeed;
			weapon->m_nFallbackStatTrak() = weapon_cfg.FallbackStatTrak;

			uint64_t mesh_mask = weapon_cfg.use_old_model ? 2ull : 1ull;
			auto* skelWeapon = reinterpret_cast<CSkeletonInstance*>(weapon->m_pGameSceneNode());
			if (skelWeapon) skelWeapon->SetMeshGroupMask(mesh_mask);
			if (weapons.pElements[i] == hActiveWeapon && view_model) {
				auto* skelVM = reinterpret_cast<CSkeletonInstance*>(view_model->m_pGameSceneNode());
				if (skelVM) skelVM->SetMeshGroupMask(mesh_mask);
			}

			item_view->m_bIsStoreItem()                        = true;
			item_view->m_iItemIDLow()                          = -1;
			item_view->m_iItemIDHigh()                         = -1;
			item_view->m_bDisallowSOC()                        = false;
			item_view->m_bInitialized()                        = true;
			item_view->m_bRestoreCustomMaterialAfterPrecache() = true;

			if (weapon_cfg.FallbackStatTrak >= 0)
				item_view->m_iEntityQuality() = 9;

			MEM::VMTCall<void*>(weapon, 11, true);
			MEM::VMTCall<void*>(weapon, 195);
			MEM::VMTCall<void*>(weapon, 105, true);
			((void(*)(C_BasePlayerWeapon*))(MEM::pUpdateSubclass))(weapon);
			((void(*)(uintptr_t, bool))(MEM::pUpdateModel))((uintptr_t)weapon + 0x608ULL, true);
			((void(*)(C_BasePlayerWeapon*, bool))(MEM::pRegenWeaponSkin))(weapon, false);
		}
	}
	clear_hud_weapon();
}

void SKINS::Draw()
{
	weapons();
}