#pragma once
#include "../../core/sdk/entity.hpp"

struct SKIN_CFG
{
	int FallbackPaintKit;
	float FallbackWear;
	int FallbackSeed;
	int FallbackStatTrak; // -1 = no StatTrak, >= 0 = StatTrak kill count
	bool use_old_model;
	bool needs_apply; // force re-apply on next frame (e.g. only use_old_model changed)

	SKIN_CFG()
	{
		FallbackPaintKit = -1;
		FallbackWear = -1;
		FallbackSeed = -1;
		FallbackStatTrak = -1;
		use_old_model = false;
		needs_apply = false;
	}
	SKIN_CFG(int FallbackPaintKit, float FallbackWear, int FallbackSeed, bool use_old_model, int FallbackStatTrak = -1)
	{
		this->FallbackPaintKit = FallbackPaintKit;
		this->FallbackWear = FallbackWear;
		this->FallbackSeed = FallbackSeed;
		this->FallbackStatTrak = FallbackStatTrak;
		this->use_old_model = use_old_model;
		this->needs_apply = true;
	}
};

namespace SKINS
{
	void Draw();

	constexpr size_t skins_size = 10000;
	inline SKIN_CFG skins_cfg[skins_size];
}