#pragma once
#include "../../core/sdk/CCSGOInput.hpp"

namespace AIM
{
	void __fastcall PreCreateMoveHook(CCSGOInput* input, int slot, char active, CCSPlayerController* local_player, CUserCmd* cmd);
}