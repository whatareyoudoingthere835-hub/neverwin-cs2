#pragma once
#include "../../core/sdk/vector.hpp"
#include "../../core/sdk/entity.hpp"


namespace TRACE
{
	float Trace(vector_t to, C_CSPlayerPawn* localPawn, CCSWeaponBaseVData* weapon_data, C_CSPlayerPawn* target, C_CSPlayerPawn** hitted);
}