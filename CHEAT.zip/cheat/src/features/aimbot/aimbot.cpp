#include "aimbot.hpp"
#include "../../core/memory/memory.hpp"
#include "../../core/interfaces/interfaces.hpp"
#include "../../core/sdk/IGameResourceSystem.hpp"
#include "../../core/sdk/enums.hpp"
#include "../../core/settings.hpp"
#include "trace.hpp"

#include "../../core/sdk/matrix.hpp"

// params between funcs
static CCSPlayerController* g_local_player = nullptr;
static C_CSPlayerPawn* g_local_pawn = nullptr;
static C_CSWeaponBase* g_weapon = nullptr;
static CCSWeaponBaseVData* g_weapon_data = nullptr;
static vector_t g_view{};

static CUserCmd* g_cmd;
static CCSGOInput* g_input;

static C_CSPlayerPawn* g_target;
static vector_t g_aim_point;

vector_t to_angle(vector_t vec)
{
	vector_t res;
	// Вычисляем Yaw (горизонтальный угол)
	res.y = atan2(vec.y, vec.x) * (180.0f / PI);

	// Вычисляем Pitch (вертикальный угол)
	float distance = sqrt(vec.x * vec.x + vec.y * vec.y);
	res.x = -atan2(vec.z, distance) * (180.0f / PI);

	res.z = 0.0f; // Roll обычно равен 0
	return res;
}

vector_t calculate_angle(vector_t from, vector_t to) {
	vector_t delta = to - from;
	return to_angle(delta);
}

float get_fov(vector_t a1, vector_t a2)
{
	return (a1 - a2).length();
}

float HitChance(CHitbox* hitbox, vector_t from, vector_t to, C_CSWeaponBase* weapon)
{
	return (std::min)(
		(std::max)(
			std::atan(hitbox->m_shape_radius / (to - from).length()) /
			(std::atan(weapon->GetSpread()) + std::atan(weapon->GetInaccuracy())),
			0.0f),
		1.0f) * 100.0f;
}

float SpreadRadius(CHitbox* hitbox, vector_t from, vector_t to, C_CSWeaponBase* weapon)
{
	return (to - from).length() * std::tan(std::atan(weapon->GetSpread()) + std::atan(weapon->GetInaccuracy()));
}

float min_damage = 100.f;
bool accept_damage(float damage, C_CSPlayerPawn* enemy)
{
	return damage >= min_damage || damage >= enemy->m_iHealth();
}

// move
void Attack(C_CSPlayerPawn* hitted, vector_t angle, int tick, int attack)
{
	auto& protoCmd = g_cmd->csgoUserCmd;
	protoCmd.pBaseCmd->nClientTick = tick; // for backtrack

	timestamp_t interpolation_timing0 = timestamp_t(hitted->GetSomeTiming(0, 1));
	timestamp_t interpolation_timing1 = timestamp_t(hitted->GetSomeTiming(1, 1));

	InterpInfo input_message = {};

	input_message.viewAngles = angle;

	input_message.playerTimeStamp = timestamp_t(tick, 0);
	input_message.renderTimeStamp = timestamp_t(TIME_TO_TICKS(hitted->m_flSimulationTime()) + interpolation_timing0.m_tick, 0);

	for (int i = 0; i < protoCmd.inputHistoryField.nCurrentSize; i++) {

		auto entry = protoCmd.GetInputHistoryEntry(i);
		if (!entry)
			continue;
		input_message.FillInputHistoryEntry(entry, true, interpolation_timing0, interpolation_timing1, hitted);
	}

	protoCmd.SetAttackHistory(attack, 0);
	auto button = (attack == 1) ? IN_ATTACK : IN_SECOND_ATTACK;
	g_cmd->nButtons.nValue |= button;
	g_cmd->nButtons.nValueChanged |= button;

	auto click = protoCmd.pBaseCmd->add_subtick_move();
	click->bPressed = true;
	click->nButton |= button;
	click->flWhen = g_input->GetSubtickFraction();
	protoCmd.pBaseCmd->pInButtonState->nValue = g_cmd->nButtons.nValue;
	protoCmd.pBaseCmd->pInButtonState->nValueChanged = g_cmd->nButtons.nValueChanged;
}

vector_t GetSpreadAng(uint32_t tick, int mode, vector_t angle)
{
	using GetSeedFn = __int64(__fastcall*)(void* a1, vector_t* a2, int a3);
	static auto GetSeed = (GetSeedFn)MEM::pGetSeed;
	using CalculateSpreadAngleFn = void(__fastcall*)(int16_t a, int b, int mode, unsigned int seed, float inaccuracy, float spread, float recoil_index, float* spread_x, float* spread_y);
	static auto CalculateSpreadAngle = (CalculateSpreadAngleFn)MEM::pCalculateSpreadAngle;

	vector_t spreadAngles{};
	auto weaponIndex = g_weapon->m_AttributeManager()->m_Item()->m_iItemDefinitionIndex();

	if (g_weapon_data->m_WeaponType() == WEAPONTYPE_SHOTGUN) return { 0, 0, 0 };

	CalculateSpreadAngle(
		weaponIndex,
		g_weapon_data->m_nNumBullets(),
		1,
		GetSeed(nullptr, &angle, tick) + 1,
		g_weapon->GetInaccuracy(),
		g_weapon->GetSpread(),
		g_weapon->m_flRecoilIndex(),
		&spreadAngles.x, &spreadAngles.y);
	vector_t forward, right, up;
	AngleVectors(angle, &forward, &right, &up);
	// расскоментить если добавлять чек сидед
	//vector_t direction = (C_GET(bool, Vars.bTrigger)) ? forward + (right * spreadAngles.x) + (up * spreadAngles.y) : forward + right + up;
	vector_t direction = forward + (right * spreadAngles.x) + (up * spreadAngles.y);
	return direction;
}

// возвращает на данный момент отдачу, так скажем
vector_t GetRecoil()
{
	using sub_7D8910Fn = __int64(__fastcall*)(void* a1, vector_t* a2);
	static sub_7D8910Fn sub_7D8910 = (sub_7D8910Fn)(MEM::pGetAimPunch);
	vector_t res = { 0, 0, 0 };
	sub_7D8910(g_local_pawn->m_pAimPunchServices(), &res);
	return res;
}

// with attack?
void Trigger()
{
	uint32_t tick = g_local_player->m_nTickBase();
	vector_t spreadAngles{};
	int mode = 1;
	min_damage = 100; // хардкод. убрать.
	auto weaponIndex = g_weapon->m_AttributeManager()->m_Item()->m_iItemDefinitionIndex();
	if (weaponIndex == WEAPON_R8_REVOLVER || weaponIndex == WEAPON_SCAR_20 || weaponIndex == WEAPON_G3SG1)
	{
		min_damage = 50; // хардкод. убрать.
	}
	if (weaponIndex == WEAPON_R8_REVOLVER) mode = 0;
	vector_t direction = GetSpreadAng(tick, mode, g_view + GetRecoil());

	auto eyePos = g_local_pawn->GetEyePosition();
	vector_t dst = eyePos + direction;
	C_CSPlayerPawn* hitted{};
	float damage = TRACE::Trace(dst, g_local_pawn, g_weapon_data, nullptr, &hitted);
	if (!hitted || !accept_damage(damage, hitted)) return;
	if (hitted->m_bGunGameImmunity()) return;
	if (!g_local_pawn->IsOtherEnemy(hitted)) return;
	Attack(hitted, g_view, tick, (mode == 1) ? 1 : 2);
}

bool SelectTarget()
{
	for (int i = 1; i <= 64; i++)
	{
		auto controller = I::GameResourceService->pGameEntitySystem->Get<CCSPlayerController>(i);
		if (controller == g_local_player) continue;
		if (!controller) continue;
		auto pawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(controller->m_hPawn());
		if (!pawn) continue;

		if (!controller->m_bPawnIsAlive()) continue;
		if (pawn->m_bGunGameImmunity()) continue;
		if (!pawn->IsOtherEnemy(g_local_pawn)) continue;

		auto skeleton = (CSkeletonInstance*)pawn->m_pGameSceneNode();

		// пикает либо противник либо я
		vector_t velocity = pawn->m_vecAbsVelocity().normalize();
		if (!velocity.length())
			velocity = g_local_pawn->m_vecAbsVelocity().normalize();

		for (auto hitboxID : all_hitboxes)
		{
			auto hitbox = skeleton->m_modelState().m_hModel()->GetHitbox(hitboxID);
			if (!hitbox) break;
			assert(hitbox->GetBone() == hitbox->GetBone(hitboxID));
			//auto origin = pawn->GetBone(hitbox->GetBone(hitboxID));
			auto origin = pawn->GetBone(hitbox->GetBone()); // хардкод чтобы можно было обойтись без айдишнка, потом поможет в хитгруппах

			float fov = get_fov(calculate_angle(g_local_pawn->GetEyePosition(), origin.Location), g_view);
			if (fov > Settings::aimbot_fov) // по сути не больше 45
				continue;

			auto matrix = reinterpret_cast<Matrix2x4_t*>(&origin)->TranslateToMatrix3x4();
			auto start = transform(hitbox->m_vec_maxs, matrix);
			auto end = transform(hitbox->m_vec_min, matrix);
			auto offset = velocity * hitbox->m_shape_radius;
			vector_t edges[] = {
				start + offset,
				end + offset,
				start,
				end,
				start - offset,
				end - offset,
				(start + end) / 2
			};
			for (auto edge : edges)
			{
				if (auto traceDamage = TRACE::Trace(edge, g_local_pawn, g_weapon_data, pawn, nullptr))
				{
					if (accept_damage(traceDamage, pawn))
					{
						auto hitchance = HitChance(hitbox, g_local_pawn->GetEyePosition(), edge, g_weapon);
						if (hitchance < Settings::aimbot_hitchance) continue;

						auto spreadRadius = SpreadRadius(hitbox, g_local_pawn->GetEyePosition(), edge, g_weapon);
						vector_t point = edge;
						// потом какнибудь расскоменчу, для мультипоинтов
						
						//if (spreadRadius <= hitbox->m_shape_radius)
						//	point = edge - velocity * (spreadRadius + 1e-9);
						//else point = edge - velocity * (hitbox->m_shape_radius - 1e-9);
						traceDamage = TRACE::Trace(point, g_local_pawn, g_weapon_data, pawn, nullptr); // перепроверить
						if (!accept_damage(traceDamage, pawn)) continue;
						g_aim_point = point;
						g_target = pawn;
						return true;
					}
				}
			}
		}
	}
	return false;
}

float hermite_interpolate(float t) {
	// Формула: 3t^2 - 2t^3
	return t * t * (3.0f - 2.0f * t);
}

void AimAssist(bool wanna_update = false)
{
	static int i = 0;
	const int max = 100;
	if (i > max || wanna_update) i = 0;

	if (true)
	{
		vector_t new_angle = calculate_angle(g_local_pawn->GetEyePosition(), g_aim_point);
		const float flSmoothing = 5;
		// гермитова интерполяция и есть пока хуманайзед мой, тоесть тут можно вставить чек на хуманайзед,
		// а иначе просто делать как обычно(просто деление сппащенное, которое я закомментил)
		g_view += (new_angle - g_view) * hermite_interpolate((float)i++ / (float)max);
		//g_view += (new_angle - g_view) / flSmoothing;
		//g_view = new_angle;
	}
}

// алгоритм вроде правильный. исправить: перебор начинать с середины. например: 1, 2, 3, 4, 5.
// в таком ряде начинать перебор: 3, 2, 4, 1, 5. и так далее. желательно еще добавить отсечение, ведь иногда проще просто начать в новом цимкле просчитывать, вдруг там проще.
// сам разберусь с ним.
void SpreadCompensation()
{
	vector_t wanna_ang = calculate_angle(g_local_pawn->GetEyePosition(), g_aim_point);
	uint32_t tick = g_local_player->m_nTickBase();
	int mode = 1;
	auto weaponIndex = g_weapon->m_AttributeManager()->m_Item()->m_iItemDefinitionIndex();
	if (weaponIndex == WEAPON_R8_REVOLVER)
		mode = 0;

	//for (int i = 0; i <= 180; ++i) {
	//	float pitch = -45.0f + (i * 0.5f);
	//	for (int j = 0; j <= 180; ++j) {
	//		float yaw = -45.0f + (j * 0.5f);
	// вспомнить чо я здесь натворил, еще раз пореверсить сприд в server.dll
	for (int i = 0; i <= 100; ++i) {
		float pitch = -25.0f + (i * 0.5f);
		for (int j = 0; j <= 100; ++j) {
			float yaw = -25.0f + (j * 0.5f);

			vector_t angles(pitch, yaw, 0.0f);
			if (pitch == 0.f && yaw == 0.f)
			{
				int a = 1;
			}
			vector_t direction = to_angle(GetSpreadAng(tick, mode, g_view + angles));

			auto some = get_fov(direction, wanna_ang);
			if (some < 0.1f) // умный чек "я все еще в хитбоксе"
			{
				g_view += angles;
				Attack(g_target, g_view, g_local_player->m_nTickBase(), (mode == 1) ? 1 : 2);
			}
		}
	}
}

// думаю вовсе убрать, пока оставить
void RCS()
{
	static vector_t oPunch{};
	using sub_7D8910Fn = __int64(__fastcall*)(void* a1, vector_t* a2);
	static sub_7D8910Fn sub_7D8910 = (sub_7D8910Fn)(MEM::pGetAimPunch);

	if (true)
	{
		vector_t aimPunchAngle{};
		sub_7D8910(g_local_pawn->m_pAimPunchServices(), &aimPunchAngle);

		int numShots = g_local_pawn->m_iShotsFired();
		if (numShots > 1)
		{
			g_view -= (aimPunchAngle - oPunch);
			//gView.Clamp();
			oPunch = aimPunchAngle;
		}
		else
		{
			oPunch = {};
		}
	}
}

void __fastcall AIM::PreCreateMoveHook(CCSGOInput* input, int slot, char active, CCSPlayerController* local_player, CUserCmd* cmd)
{
	if (!Settings::aimbot_enabled) return;

	g_cmd = cmd;
	g_input = input;

	g_local_player = local_player;
	g_local_pawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(g_local_player->m_hPawn());
	if (!g_local_player || !g_local_pawn || !g_local_pawn->m_iHealth()) return;
	g_view = input->GetViewAngles();

	auto h = g_local_pawn->m_pWeaponServices()->m_hActiveWeapon();
	auto w = I::GameResourceService->pGameEntitySystem->Get<C_BasePlayerWeapon>(h);
	g_weapon = (C_CSWeaponBase*)w;
	if (!g_weapon) return;
	g_weapon_data = (CCSWeaponBaseVData*)g_weapon->v_data();
	if (!g_weapon_data) return;

	if (g_weapon->m_bInReload()) return;
	auto type = g_weapon_data->m_WeaponType();
	if (type == WEAPONTYPE_KNIFE ||
		type == WEAPONTYPE_TASER) return;

	//if (g_local_player->m_nTickBase() < g_weapon->m_nNextPrimaryAttackTick()) return;
	static C_CSPlayerPawn* prev_target = nullptr;
	//SelectTarget();
	if (Settings::aimbot_humanized && SelectTarget())
	{
		AimAssist(prev_target != g_target);
		prev_target = g_target;
	}
	else AimAssist(true);
	if (Settings::trigger_enabled)
	{
		Trigger();
	}
	input->SetViewAngle(&g_view);
}