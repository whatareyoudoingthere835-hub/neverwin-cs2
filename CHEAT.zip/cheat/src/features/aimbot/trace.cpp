#include "trace.hpp"
#include "../../core/sdk/cgametracemanager.hpp"

void ScaleDamage(int hitgroup, C_CSPlayerPawn* entity, CCSWeaponBaseVData* weapon_data, float* damage)
{
	//auto mp_damage_scale_ct_head = I::Cvar->Find(FNV1A::HashConst("mp_damage_scale_ct_head"));
	//auto mp_damage_scale_t_head = I::Cvar->Find(FNV1A::HashConst("mp_damage_scale_t_head"));
	//auto mp_damage_scale_ct_body = I::Cvar->Find(FNV1A::HashConst("mp_damage_scale_ct_body"));
	//auto mp_damage_scale_t_body = I::Cvar->Find(FNV1A::HashConst("mp_damage_scale_t_body"));

	//float damage_scale_ct_head = mp_damage_scale_ct_head->value.fl;
	//float damage_scale_t_head = mp_damage_scale_t_head->value.fl;
	//float damage_scale_ct_body = mp_damage_scale_ct_body->value.fl;
	//float damage_scale_t_body = mp_damage_scale_t_body->value.fl;
	float damage_scale_ct_head = 1.f;
	float damage_scale_t_head = 1.f;
	float damage_scale_ct_body = 1.f;
	float damage_scale_t_body = 1.f;

	const bool is_ct = entity->m_iTeamNum() == 3, is_t = entity->m_iTeamNum() == 2;

	float head_damage_scale = is_ct ? damage_scale_ct_head : is_t ? damage_scale_t_head : 1.f;
	const float body_damage_scale = is_ct ? damage_scale_ct_body : is_t ? damage_scale_t_body : 1.f;

	switch (hitgroup)
	{
	case hitgroup_head:
		*damage *= weapon_data->m_flHeadshotMultiplier() * head_damage_scale;
		break;
	case hitgroup_chest:
	case hitgroup_left_hand:
	case hitgroup_right_hand:
	case hitgroup_neck:
		*damage *= body_damage_scale;
		break;
	case hitgroup_stomach:
		*damage *= 1.25f * body_damage_scale;
		break;
	case hitgroup_left_leg:
	case hitgroup_right_leg:
		*damage *= .75f * body_damage_scale;
		break;
	default:
		break;
	}

	if (!entity->HasArmor(hitgroup))
		return;

	float heavy_armor_bonus = 1.f, armor_bonus = .5f, armor_ratio = weapon_data->m_flArmorRatio() * .5f;

	float damage_to_health = *damage * armor_ratio;
	const float damage_to_armor = (*damage - damage_to_health) * (heavy_armor_bonus * armor_bonus);

	if (damage_to_armor > static_cast<float>(entity->m_ArmorValue()))
		damage_to_health = *damage - static_cast<float>(entity->m_ArmorValue()) / armor_bonus;

	*damage = damage_to_health;
}

float TRACE::Trace(vector_t to, C_CSPlayerPawn* localPawn, CCSWeaponBaseVData* weapon_data, C_CSPlayerPawn* target = nullptr, C_CSPlayerPawn** hitted = nullptr)
{
	static GameTrace_t* trace = new GameTrace_t();
	static TraceFilter_t* filter = new TraceFilter_t();
	static trace_data_t* traceData = new trace_data_t();
	static Ray_t ray{};

	*traceData = trace_data_t();
	traceData->arr_pointer = &traceData->arr;

	filter->Init(localPawn, 0x1C300BLL, 3, 0xF);
	filter->m_v1[0] |= 0x4000000000uLL;
	filter->m_v6 |= 2u;

	auto eye_pos = localPawn->GetEyePosition();
	vector_t direction = eye_pos.get_normal(to);
	vector_t end_pos = direction * weapon_data->m_flRange();

	// auto wall
	traceData->CreateTrace(&eye_pos, &end_pos, filter, 4);
	handle_bulllet_penetration_data_t handle_bullet_data = handle_bulllet_penetration_data_t(
		static_cast<float>(weapon_data->m_nDamage()),
		weapon_data->m_flPenetration(),
		weapon_data->m_flRange(),
		weapon_data->m_flRangeModifier(),
		4,
		false
	);
	float damage = static_cast<float>(weapon_data->m_nDamage());
	for (int i = 0; i < traceData->num_update; i++)
	{
		update_value_t* modulate_values = reinterpret_cast<update_value_t* const>(reinterpret_cast<std::uintptr_t>(traceData->pointer_update_value) + i * sizeof(update_value_t));
		if (!modulate_values) continue;
		trace->Init();
		traceData->GetInfo(trace, 0.0f, reinterpret_cast<void*>(reinterpret_cast<std::uintptr_t>(traceData->arr.data()) + sizeof(trace_array_element_t) * (modulate_values->m_handle_index & ENT_ENTRY_MASK)));

		if (trace->m_pHitEntity && *(uint32_t*)(trace->m_pHitboxData->m_bone_name) != 0x61766E69U && (!target || trace->m_pHitEntity == target))
		{
			//if (!C_GET(bool, Vars.bAutoWall)) if (i != 0)
			if (!true) if (i != 0)
				continue;
			if (!CheckHitgroup(trace->GetHitgroup()))
				continue;
			ScaleDamage(trace->GetHitgroup(), trace->m_pHitEntity, weapon_data, &damage);
			if (hitted) *hitted = trace->m_pHitEntity;
			return damage;
		}

		if (traceData->HandleBulletPenetration(&handle_bullet_data, modulate_values, localPawn->m_iTeamNum()))
			break;
		damage = handle_bullet_data.m_damage;
	}
	return 0.f;
}
