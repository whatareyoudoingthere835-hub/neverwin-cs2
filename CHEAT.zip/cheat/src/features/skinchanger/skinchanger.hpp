#pragma once
#include "../../core/sdk/entity.hpp"

namespace Skinchanger
{
    void OnPreCreateMove();
    void OnFrameStageNotify(int stage);
}
