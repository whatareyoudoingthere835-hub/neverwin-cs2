#include "skinchanger.hpp"
#include "../../core/settings.hpp"
#include "../skins/skins.hpp"
#include "../../core/interfaces/interfaces.hpp"
#include "../../core/sdk/IGameResourceSystem.hpp"

namespace Skinchanger
{
    void UpdateWeapons(C_CSPlayerPawn* local_pawn)
    {
        if (!I::GameResourceService || !I::GameResourceService->pGameEntitySystem)
            return;

        auto weaponServices = local_pawn->m_pWeaponServices();
        if (!weaponServices) return;
        if (!weaponServices) return;

        auto weapons = weaponServices->m_hMyWeapons();
        for (int i = 0; i < weapons.nSize; i++)
        {
            auto weapon = I::GameResourceService->pGameEntitySystem->Get<C_BasePlayerWeapon>(weapons.pElements[i]);
            if (!weapon) continue;

            auto attrManager = weapon->m_AttributeManager();
            if (!attrManager) continue;

            auto item = attrManager->m_Item();
            if (!item) continue;

            auto defIndex = item->m_iItemDefinitionIndex();

            bool isKnife = (defIndex >= 500 || defIndex == 42 || defIndex == 59);

            if (isKnife && Settings::skinchanger_knife_enabled)
            {
                item->m_iItemIDHigh() = -1;
                weapon->m_nFallbackPaintKit() = (int32_t)Settings::skinchanger_knife_paint_kit;
                weapon->m_flFallbackWear() = Settings::skinchanger_knife_wear;
            }
            else if (!isKnife && defIndex < SKINS::skins_size && SKINS::skins_cfg[defIndex].FallbackPaintKit != -1)
            {
                auto& cfg = SKINS::skins_cfg[defIndex];
                if (cfg.FallbackPaintKit > 0)
                {
                    item->m_iItemIDHigh() = -1;
                    weapon->m_nFallbackPaintKit() = cfg.FallbackPaintKit;
                    weapon->m_flFallbackWear() = cfg.FallbackWear;
                    weapon->m_nFallbackSeed() = cfg.FallbackSeed;
                }
            }
        }
        
        if (Settings::skinchanger_glove_enabled)
        {
            auto& econGloves = local_pawn->m_EconGloves();
            if (econGloves.m_iItemDefinitionIndex() != 0)
            {
                econGloves.m_iItemIDHigh() = -1;
                // Currently setting basic glove paint
                // Need to map definitions later
            }
        }
    }

    void OnPreCreateMove()
    {
        if (!Settings::skinchanger_enabled && !Settings::skinchanger_knife_enabled && !Settings::skinchanger_glove_enabled)
            return;
            
        static int throttle = 0;
        if (throttle++ % 32 != 0) return;
            
        auto controller = GetLocalPlayerController();
        if (!controller) return;
        
        if (!I::GameResourceService || !I::GameResourceService->pGameEntitySystem) return;
        
        auto pawn = I::GameResourceService->pGameEntitySystem->Get<C_CSPlayerPawn>(controller->m_hPawn());
        if (!pawn || pawn->m_iHealth() <= 0) return;

        UpdateWeapons(pawn);
    }
    
    void OnFrameStageNotify(int stage)
    {
        if (!Settings::skinchanger_enabled && !Settings::skinchanger_knife_enabled && !Settings::skinchanger_glove_enabled)
            return;
    }
}
