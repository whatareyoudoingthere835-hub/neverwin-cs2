#include "skindb_local.hpp"
#include <winhttp.h>
#include <thread>
#include <iostream>

#include "../../../ext/json/json.hpp"
#include "../../zhironium/src/core.hpp"
#include "../../zhironium/src/graphics/graphics.hpp"

#pragma comment(lib, "winhttp.lib")

std::unique_ptr<CSkinDB> g_SkinDB = std::make_unique<CSkinDB>();

CSkinDB::CSkinDB() {}
CSkinDB::~CSkinDB() {}

WeaponsEnum CSkinDB::GetDefPerString(const std::string& name)
{
    static const std::unordered_map<std::string, WeaponsEnum> weaponMap = {
        {"AK-47", WeaponsEnum::Ak47}, {"AUG", WeaponsEnum::Aug}, {"AWP", WeaponsEnum::Awp},
        {"PP-Bizon", WeaponsEnum::Bizon}, {"PP-CZ75-Auto", WeaponsEnum::Cz65A},
        {"Desert Eagle", WeaponsEnum::Deagle}, {"Dual Berettas", WeaponsEnum::Elite},
        {"FAMAS", WeaponsEnum::Famas}, {"Five-SeveN", WeaponsEnum::FiveSeven},
        {"G3SG1", WeaponsEnum::G3Sg1}, {"Galil AR", WeaponsEnum::Galil},
        {"Glock-18", WeaponsEnum::Glock}, {"P2000", WeaponsEnum::p2000},
        {"M249", WeaponsEnum::M249}, {"M4A1-S", WeaponsEnum::M4A1Silencer},
        {"M4A4", WeaponsEnum::M4A4}, {"MAC-10", WeaponsEnum::Mac10},
        {"MAG-7", WeaponsEnum::Mag7}, {"MP5-SD", WeaponsEnum::Ump45},
        {"MP7", WeaponsEnum::Mp7}, {"MP9", WeaponsEnum::Mp9},
        {"Negev", WeaponsEnum::Negev}, {"Nova", WeaponsEnum::Nova},
        {"XM1014", WeaponsEnum::Xm1014}, {"USP-S", WeaponsEnum::UspS},
        {"Tec-9", WeaponsEnum::Tec9}, {"Zeus x27", WeaponsEnum::Zeus},
        {"SSG 08", WeaponsEnum::Ssg08}, {"SG 553", WeaponsEnum::Sg556},
        {"SCAR-20", WeaponsEnum::Scar20}, {"Sawed-Off", WeaponsEnum::Sawedoof},
        {"R8 Revolver", WeaponsEnum::Revolver}, {"P90", WeaponsEnum::P90},
        {"P250", WeaponsEnum::p250}
    };

    for (const auto& [key, value] : weaponMap) {
        if (name.find(key) != std::string::npos)
            return value;
    }
    return WeaponsEnum::none;
}

static std::vector<uint8_t> DownloadDataWinHTTP(const std::wstring& urlW) {
    std::vector<uint8_t> result;
    URL_COMPONENTS urlComp = { 0 };
    urlComp.dwStructSize = sizeof(urlComp);
    wchar_t host[256]; urlComp.lpszHostName = host; urlComp.dwHostNameLength = 256;
    wchar_t path[1024]; urlComp.lpszUrlPath = path; urlComp.dwUrlPathLength = 1024;
    urlComp.dwSchemeLength = (DWORD)-1;

    if (!WinHttpCrackUrl(urlW.c_str(), 0, 0, &urlComp)) return result;

    HINTERNET hSession = WinHttpOpen(L"Interlope/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return result;

    HINTERNET hConnect = WinHttpConnect(hSession, host, INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (hConnect) {
        HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", path, NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
        if (hRequest) {
            if (WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0)) {
                if (WinHttpReceiveResponse(hRequest, NULL)) {
                    DWORD size = 0;
                    DWORD downloaded = 0;
                    do {
                        size = 0;
                        if (!WinHttpQueryDataAvailable(hRequest, &size)) break;
                        if (!size) break;
                        std::vector<uint8_t> buffer(size);
                        if (WinHttpReadData(hRequest, buffer.data(), size, &downloaded)) {
                            result.insert(result.end(), buffer.begin(), buffer.begin() + downloaded);
                        }
                    } while (size > 0);
                }
            }
            WinHttpCloseHandle(hRequest);
        }
        WinHttpCloseHandle(hConnect);
    }
    WinHttpCloseHandle(hSession);
    return result;
}

void CSkinDB::Initialize() {
    if (initialized) return;

    std::thread([this]() {
        std::wstring url = L"https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/skins.json";
        std::vector<uint8_t> data = DownloadDataWinHTTP(url);
        if (data.empty()) return;

        try {
            std::string jsonStr(data.begin(), data.end());
            auto jsonData = nlohmann::json::parse(jsonStr);

            std::vector<std::string> knifeTypes = {
                "Bayonet", "Classic Knife", "Flip Knife", "Gut Knife",
                "Karambit", "M9 Bayonet", "Huntsman Knife", "Falchion Knife",
                "Bowie Knife", "Butterfly Knife", "Shadow Daggers", "Paracord Knife",
                "Survival Knife", "Ursus Knife", "Navaja Knife", "Nomad Knife",
                "Stiletto Knife", "Talon Knife", "Skeleton Knife", "Kukri Knife"
            };

            std::vector<std::string> gloveTypes = {
                "Bloodhound Gloves", "Broken Fang Gloves", 
                "Driver Gloves", "Hand Wraps", 
                "Hydra Gloves", "Moto Gloves", 
                "Specialist Gloves", "Sport Gloves"
            };

            std::wstring weaponsUrl = L"https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/base_weapons.json";
            std::vector<uint8_t> weaponsData = DownloadDataWinHTTP(weaponsUrl);
            if (!weaponsData.empty()) {
                try {
                    std::string jsonStr(weaponsData.begin(), weaponsData.end());
                    auto wData = nlohmann::json::parse(jsonStr);
                    for (auto& w : wData) {
                        SkinInfo_t info;
                        info.Paint = 0;
                        if (w.contains("name")) info.name = w["name"].get<std::string>();
                        if (w.contains("image")) info.image_url = w["image"].get<std::string>();
                        info.weaponType = GetDefPerString(info.name);
                        info.rarity = 1;

                        bool isKnife = false, isGlove = false;
                        for (auto& k : knifeTypes) {
                            if (info.name.find(k) != std::string::npos) { isKnife = true; break; }
                        }
                        for (auto& g : gloveTypes) {
                            if (info.name.find(g) != std::string::npos) { isGlove = true; break; }
                        }

                        if (info.weaponType != WeaponsEnum::none || isKnife || isGlove) {
                            if (isKnife) knifeSkins.push_back(info);
                            else if (isGlove) gloveSkins.push_back(info);
                            else weaponSkins.push_back(info);
                        }
                    }
                } catch(...) {}
            }

            for (auto& skin : jsonData) {
                SkinInfo_t info;
                if (skin.contains("paint_index") && skin["paint_index"].is_number_integer()) {
                    info.Paint = skin["paint_index"].get<int>();
                } else if (skin.contains("paint_index") && skin["paint_index"].is_string()) {
                    try { info.Paint = std::stoi(skin["paint_index"].get<std::string>()); } catch (...) {}
                }

                if (skin.contains("name")) info.name = skin["name"].get<std::string>();
                if (skin.contains("image")) info.image_url = skin["image"].get<std::string>();
                if (skin.contains("legacy_model") && skin["legacy_model"].is_boolean())
                    info.legacy_model = skin["legacy_model"].get<bool>();

                info.weaponType = GetDefPerString(info.name);

                if (skin.contains("rarity") && skin["rarity"].is_object() && skin["rarity"].contains("id")) {
                    auto& rid = skin["rarity"]["id"];
                    if (rid.is_string()) {
                        std::string idStr = rid.get<std::string>();
                        if (idStr.find("contraband") != std::string::npos) info.rarity = 7;
                        else if (idStr.find("ancient") != std::string::npos) info.rarity = 6;
                        else if (idStr.find("legendary") != std::string::npos) info.rarity = 5;
                        else if (idStr.find("mythical") != std::string::npos) info.rarity = 4;
                        else if (idStr.find("rare") != std::string::npos) info.rarity = 3;
                        else if (idStr.find("uncommon") != std::string::npos) info.rarity = 2;
                        else info.rarity = 1;
                    }
                }

                bool isKnife = false, isGlove = false;
                for (auto& k : knifeTypes) {
                    if (info.name.find(k) != std::string::npos) { isKnife = true; break; }
                }
                for (auto& g : gloveTypes) {
                    if (info.name.find(g) != std::string::npos) { isGlove = true; break; }
                }

                if (isKnife) knifeSkins.push_back(info);
                else if (isGlove) gloveSkins.push_back(info);
                else weaponSkins.push_back(info);
            }

            initialized = true;

            // Start texture downloader worker thread
            std::thread([this]() {
                while (true) {
                    DownloadTask task;
                    {
                        std::lock_guard<std::mutex> lock(textureMutex);
                        if (!pendingDownloads.empty()) {
                            task = pendingDownloads.back();
                            pendingDownloads.pop_back();
                        } else {
                            std::this_thread::sleep_for(std::chrono::milliseconds(50));
                            continue;
                        }
                    }

                    if (task.skin && !task.url.empty()) {
                        std::wstring wUrl(task.url.begin(), task.url.end());
                        std::vector<uint8_t> imgData = DownloadDataWinHTTP(wUrl);
                        if (!imgData.empty()) {
                            std::lock_guard<std::mutex> lock(processMutex);
                            pendingProcess.push_back({ task.skin, imgData });
                        }
                    }
                }
            }).detach();

        } catch (...) {}
    }).detach();
}

void CSkinDB::ProcessTextures() {
    std::lock_guard<std::mutex> lock(processMutex);
    for (auto& task : pendingProcess) {
        if (!task.skin->cachedTexture && !task.data.empty() && zhironium::ctx && zhironium::ctx->graphics) {
            ID3D11ShaderResourceView* srv = nullptr;
            int w, h;
            if (zhironium::ctx->graphics->loadTextureFromMemory(task.data.data(), task.data.size(), &srv, &w, &h)) {
                task.skin->cachedTexture = (void*)srv;
            }
        }
    }
    pendingProcess.clear();
}

void CSkinDB::RequestTexture(SkinInfo_t* skin) {
    if (!skin || skin->cachedTexture || skin->downloadRequested || skin->image_url.empty()) return;
    
    std::lock_guard<std::mutex> lock(textureMutex);
    skin->downloadRequested = true;
    pendingDownloads.push_back({ skin->image_url, skin });
}


