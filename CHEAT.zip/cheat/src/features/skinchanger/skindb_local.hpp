#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <mutex>
#include <memory>
#include <cstdint>
#include <d3d11.h>

#include "../../../ext/imgui/imgui.h"

// Hardcoded Weapon Enums for reference
enum class WeaponsEnum : uint16_t {
    none = 0,
    Deagle = 1, Elite = 2, FiveSeven = 3, Glock = 4, Ak47 = 7, Aug = 8,
    Awp = 9, Famas = 10, G3Sg1 = 11, Galil = 13, M249 = 14, M4A4 = 16,
    Mac10 = 17, P90 = 19, Ump45 = 24, Xm1014 = 25, Bizon = 26, Mag7 = 27,
    Negev = 28, Sawedoof = 29, Tec9 = 30, Zeus = 31, p2000 = 32, Mp7 = 33,
    Mp9 = 34, Nova = 35, p250 = 36, Scar20 = 38, Sg556 = 39, Ssg08 = 40,
    M4A1Silencer = 60, UspS = 61, Cz65A = 63, Revolver = 64, Knife = 500,
    Glove = 5027
};

struct SkinInfo_t {
    int Paint = 0;
    std::string name;
    WeaponsEnum weaponType = WeaponsEnum::none;
    int rarity = 0;
    std::string image_url;
    void* cachedTexture = nullptr;
    bool downloadRequested = false;
    bool legacy_model = false;
};

class CSkinDB {
private:
    std::vector<SkinInfo_t> weaponSkins;
    std::vector<SkinInfo_t> knifeSkins;
    std::vector<SkinInfo_t> gloveSkins;

    std::mutex textureMutex;
    struct DownloadTask {
        std::string url;
        SkinInfo_t* skin;
    };
    std::vector<DownloadTask> pendingDownloads;
    
    struct ProcessingTask {
        SkinInfo_t* skin;
        std::vector<uint8_t> data;
    };
    std::mutex processMutex;
    std::vector<ProcessingTask> pendingProcess;

    bool initialized = false;

    WeaponsEnum GetDefPerString(const std::string& name);

public:
    CSkinDB();
    ~CSkinDB();

    void Initialize();
    void ProcessTextures(); // Must be called from main render thread!

    std::vector<SkinInfo_t>& GetWeaponSkins() { return weaponSkins; }
    std::vector<SkinInfo_t>& GetKnifeSkins() { return knifeSkins; }
    std::vector<SkinInfo_t>& GetGloveSkins() { return gloveSkins; }

    void RequestTexture(SkinInfo_t* skin);
    
    bool IsInitialized() const { return initialized; }
};

extern std::unique_ptr<CSkinDB> g_SkinDB;
