//
// Created by rei on 1/22/2026.
//

#include "core.hpp"

#include "assets/assets.hpp"
#include "fonts/fonts.hpp"
#include "graphics/graphics.hpp"
#include "ui/ui.hpp"
#include "ui/alerts/alerts.hpp"
#include "ui/binder/binder.hpp"
#include "ui/themes/themes.hpp"
#include "ui/widgets/widgets.hpp"

using zhironium::KallcodeKit;

using zhironium::CCore;

KallcodeKit::~KallcodeKit( ) = default;

KallcodeKit::KallcodeKit( )
{
    ui = std::make_unique< kallcode::CUserInterface >( );
    fonts = std::make_unique< kallcode::CFonts >( );
    alerts = std::make_unique< kallcode::CAlerts >( );
    binder = std::make_unique< kallcode::CBinder >( );
    themes = std::make_unique< kallcode::CThemes >( );
    widgets = std::make_unique< kallcode::CWidgets >( );
    assets = std::make_unique< kallcode::CAssets >( );
}

std::unique_ptr< CCore > zhironium::ctx;

CCore::~CCore( ) = default;

CCore::CCore( )
{
    kallcode = std::make_unique< KallcodeKit >( );
    graphics = std::make_unique< CGraphics >( );
}
