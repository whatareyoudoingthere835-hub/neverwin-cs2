#pragma once

namespace dream_mode {
    void handleToggle(bool* enabled);
}
