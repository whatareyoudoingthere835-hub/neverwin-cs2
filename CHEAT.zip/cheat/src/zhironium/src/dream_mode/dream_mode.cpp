#include "dream_mode.hpp"
#include <windows.h>
#include <shellapi.h>
#include <thread>
#include <filesystem>

#pragma comment(lib, "winmm.lib")

#include "../../../base.hpp"

namespace dream_mode {
    void handleToggle(bool* enabled) {
        static bool last_state = false;
        if (*enabled && !last_state) {
            std::thread([]() {
                std::filesystem::create_directories(CS_XOR("C:\\Interlope\\Dream"));
                if (std::filesystem::exists(CS_XOR("C:\\Interlope\\Dream\\dream.webm"))) {
                    std::filesystem::remove(CS_XOR("C:\\Interlope\\Dream\\dream.webm"));
                }
                if (!std::filesystem::exists(CS_XOR("C:\\Interlope\\Dream\\dream.m4a"))) {
                    system(CS_XOR("yt-dlp -f \"bestaudio[ext=m4a]\" --no-playlist -o \"C:\\Interlope\\Dream\\dream.m4a\" \"https://www.youtube.com/watch?v=g33LSGLwLzo\" --quiet"));
                }
                mciSendStringA(CS_XOR("open \"C:\\Interlope\\Dream\\dream.m4a\" type mpegvideo alias dream_mp3"), NULL, 0, NULL);
                mciSendStringA(CS_XOR("play dream_mp3 repeat"), NULL, 0, NULL);
            }).detach();
        } else if (!*enabled && last_state) {
            mciSendStringA(CS_XOR("stop dream_mp3"), NULL, 0, NULL);
            mciSendStringA(CS_XOR("close dream_mp3"), NULL, 0, NULL);
        }
        last_state = *enabled;
    }
}
