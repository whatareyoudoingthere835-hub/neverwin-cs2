//
// Created by rei on 1/29/2026.
//

#ifndef SCATTEREDABYSS_DESKTOP_INCLUDE_HPP
#define SCATTEREDABYSS_DESKTOP_INCLUDE_HPP

#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

typedef HRESULT( __stdcall* Present )( IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags );
typedef LRESULT( CALLBACK* WNDPROC )( HWND, UINT, WPARAM, LPARAM );
typedef uintptr_t PTR;

#endif // SCATTEREDABYSS_DESKTOP_INCLUDE_HPP
