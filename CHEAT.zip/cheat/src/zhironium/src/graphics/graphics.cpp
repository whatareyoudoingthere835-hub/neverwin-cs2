//
// Created by rei on 1/28/2026.
//

#define _CRT_SECURE_NO_WARNINGS

#include "graphics.hpp"
#define STB_IMAGE_IMPLEMENTATION
#include "../thirdparty/stb_image.hpp"
#pragma comment(lib, "d3d11.lib")

#include "core.hpp"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"
#include "ui/ui.hpp"

#include <dwmapi.h>
#include <uxtheme.h>

using zhironium::CGraphics;

ID3D11Device* CGraphics::m_device = nullptr;
ID3D11DeviceContext* CGraphics::m_deviceContext = nullptr;
IDXGISwapChain* CGraphics::m_swapChain = nullptr;
bool CGraphics::m_swapChainOccluded = false;
ID3D11RenderTargetView* CGraphics::m_mainRenderTargetView = nullptr;

bool CGraphics::loadTextureFromMemory( const void* data, size_t data_size, ID3D11ShaderResourceView** out_srv, int* out_width, int* out_height )
{
    int image_width = 0;
    int image_height = 0;

    unsigned char* image_data = stbi_load_from_memory(
        ( const unsigned char* ) data, ( int ) data_size,
        &image_width, &image_height, NULL, 4 );

    if ( !image_data )
        return false;

    D3D11_TEXTURE2D_DESC desc;
    ZeroMemory( &desc, sizeof( desc ) );
    desc.Width = ( UINT ) image_width;
    desc.Height = ( UINT ) image_height;
    desc.MipLevels = 0;
    desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    desc.CPUAccessFlags = 0;
    desc.MiscFlags = D3D11_RESOURCE_MISC_GENERATE_MIPS;

    ID3D11Texture2D* tex = NULL;
    HRESULT hr = m_device->CreateTexture2D( &desc, NULL, &tex );
    if ( FAILED( hr ) || !tex )
    {
        stbi_image_free( image_data );
        return false;
    }

    const UINT rowPitch = ( UINT ) image_width * 4;
    m_deviceContext->UpdateSubresource( tex, 0, NULL, image_data, rowPitch, 0 );

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc;
    ZeroMemory( &srvDesc, sizeof( srvDesc ) );
    srvDesc.Format = desc.Format;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MostDetailedMip = 0;
    srvDesc.Texture2D.MipLevels = ( UINT ) -1;

    ID3D11ShaderResourceView* srv = NULL;
    hr = m_device->CreateShaderResourceView( tex, &srvDesc, &srv );
    if ( FAILED( hr ) || !srv )
    {
        tex->Release( );
        stbi_image_free( image_data );
        return false;
    }

    m_deviceContext->GenerateMips( srv );

    tex->Release( );
    stbi_image_free( image_data );

    *out_srv = srv;
    *out_width = image_width;
    *out_height = image_height;
    return true;
}

ImTextureID CGraphics::loadTextureFromFile( const char* file_name )
{
    FILE* f = fopen( file_name, "rb" );
    if ( f == NULL )
        return 0;
    fseek( f, 0, SEEK_END );
    size_t file_size = ( size_t ) ftell( f );
    if ( file_size == -1 )
        return 0;
    fseek( f, 0, SEEK_SET );
    void* file_data = IM_ALLOC( file_size );
    fread( file_data, 1, file_size, f );
    fclose( f );
    ID3D11ShaderResourceView* result { };
    int a, b = 0;
    loadTextureFromMemory( file_data, file_size, &result, &a, &b );
    IM_FREE( file_data );
    return ( ImTextureID ) result;
}

void FitToPrimaryMonitor( HWND hwnd )
{
    RECT rc;
    GetWindowRect( GetDesktopWindow( ), &rc );
    SetWindowPos( hwnd, HWND_TOPMOST,
                  rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top,
                  SWP_NOACTIVATE | SWP_SHOWWINDOW );
}

void SetClickThrough( HWND hwnd, bool clickThrough )
{
    LONG ex = GetWindowLongW( hwnd, GWL_EXSTYLE );
    if ( clickThrough )
        ex |= WS_EX_TRANSPARENT;
    else
        ex &= ~WS_EX_TRANSPARENT;
    SetWindowLongW( hwnd, GWL_EXSTYLE, ex );
}

void HandleKey( UINT vk, bool down )
{
    ImGuiIO& io = ImGui::GetIO( );
    ImGuiKey key = ImGuiKey_None;

    if ( vk >= 'A' && vk <= 'Z' )
        key = ( ImGuiKey ) ( ImGuiKey_A + ( vk - 'A' ) );

    if ( vk >= VK_F1 && vk <= VK_F12 )
        key = ( ImGuiKey ) ( ImGuiKey_F1 + ( vk - VK_F1 ) );

    if ( vk == VK_SHIFT )
        key = ImGuiMod_Shift;
    if ( vk == VK_CONTROL )
        key = ImGuiMod_Ctrl;
    if ( vk == VK_MENU )
        key = ImGuiMod_Alt;
    if ( vk == VK_ESCAPE )
        key = ImGuiKey_Escape;
    if ( vk == VK_TAB )
        key = ImGuiKey_Tab;
    if ( vk == VK_RETURN )
        key = ImGuiKey_Enter;

    if ( key != ImGuiKey_None )
        io.AddKeyEvent( key, down );
}

void HandleMouse( int button, bool down )
{
    ImGuiIO& io = ImGui::GetIO( );
    io.AddMouseButtonEvent( button, down );
}

void HandleScroll( short delta )
{
    ImGuiIO& io = ImGui::GetIO( );
    io.AddMouseWheelEvent( 0.0f, delta / 120.0f );
}

void FeedMousePos( HWND hwnd )
{
    POINT p;
    GetCursorPos( &p );
    ScreenToClient( hwnd, &p );
    ImGui::GetIO( ).AddMousePosEvent( ( float ) p.x, ( float ) p.y );
}

void RegisterRawInput( HWND hwnd )
{
    RAWINPUTDEVICE rid[ 2 ] { };

    rid[ 0 ].usUsagePage = 0x01;
    rid[ 0 ].usUsage = 0x06; // Keyboard
    rid[ 0 ].dwFlags = RIDEV_INPUTSINK;
    rid[ 0 ].hwndTarget = hwnd;

    rid[ 1 ].usUsagePage = 0x01;
    rid[ 1 ].usUsage = 0x02; // Mouse
    rid[ 1 ].dwFlags = RIDEV_INPUTSINK;
    rid[ 1 ].hwndTarget = hwnd;

    RegisterRawInputDevices( rid, 2, sizeof( RAWINPUTDEVICE ) );
}

void CGraphics::execute( const std::function< void( ) >& init_callback, const std::function< void( ) >& render_callback )
{
    ImGui_ImplWin32_EnableDpiAwareness( );
    float main_scale = ImGui_ImplWin32_GetDpiScaleForMonitor( ::MonitorFromPoint( POINT { 0, 0 }, MONITOR_DEFAULTTOPRIMARY ) );

    WNDCLASSEXW wc = { sizeof( wc ), CS_CLASSDC, wndProc, 0L, 0L, GetModuleHandle( nullptr ), nullptr, nullptr, nullptr, nullptr, L"ImGui Example", nullptr };
    ::RegisterClassExW( &wc );

    DWORD style = WS_POPUP;
    DWORD exStyle = WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW;

    RECT rc;
    GetWindowRect( GetDesktopWindow( ), &rc );

    HWND hwnd = ::CreateWindowExW(
        exStyle,
        wc.lpszClassName,
        L"Overlay",
        style,
        rc.left, rc.top,
        rc.right - rc.left,
        rc.bottom - rc.top,
        nullptr, nullptr,
        wc.hInstance,
        nullptr );

    MARGINS margins = { -1 };
    DwmExtendFrameIntoClientArea( hwnd, &margins );

    SetLayeredWindowAttributes( hwnd, 0, 255, LWA_ALPHA );

    SetWindowPos( hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                  SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW );

    if ( !createDeviceD3D( hwnd ) )
    {
        cleanupDeviceD3D( );
        ::UnregisterClassW( wc.lpszClassName, wc.hInstance );
        return;
    }

    ::ShowWindow( hwnd, SW_SHOWDEFAULT );
    ::UpdateWindow( hwnd );

    RegisterRawInput( hwnd );

    IMGUI_CHECKVERSION( );
    ImGui::CreateContext( );
    ImGuiIO& io = ImGui::GetIO( );
    ( void ) io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad; // Enable Gamepad Controls

    ImGui::StyleColorsDark( );
    // ImGui::StyleColorsLight();

    ImGui_ImplWin32_Init( hwnd );
    ImGui_ImplDX11_Init( m_device, m_deviceContext );

    if ( init_callback )
        init_callback( );

    while ( threadActive )
    {
        MSG msg;
        while ( ::PeekMessage( &msg, nullptr, 0U, 0U, PM_REMOVE ) )
        {
            ::TranslateMessage( &msg );
            ::DispatchMessage( &msg );
            if ( msg.message == WM_QUIT )
                threadActive = false;
        }
        if ( !threadActive )
            break;

        bool& presented = ctx->kallcode->ui->isPresented( );
        SetClickThrough( hwnd, !presented );
        if ( GetAsyncKeyState( VK_INSERT ) & 1 )
            presented = !presented;

        if ( m_swapChainOccluded && m_swapChain->Present( 0, DXGI_PRESENT_TEST ) == DXGI_STATUS_OCCLUDED )
        {
            ::Sleep( 10 );
            continue;
        }
        m_swapChainOccluded = false;

        if ( ctx->kallcode->resizeWidth != 0 && ctx->kallcode->resizeHeight != 0 )
        {
            cleanupRenderTarget( );
            m_swapChain->ResizeBuffers( 0, ctx->kallcode->resizeWidth, ctx->kallcode->resizeHeight, DXGI_FORMAT_UNKNOWN, 0 );
            ctx->kallcode->resizeWidth = ctx->kallcode->resizeHeight = 0;
            createRenderTarget( );

            FitToPrimaryMonitor( hwnd );
        }

        m_deviceContext->OMSetRenderTargets(
            1,
            &m_mainRenderTargetView,
            nullptr );

        const float clear_color_with_alpha[ 4 ] = { 0.f, 0.f, 0.f, 0.f };
        m_deviceContext->ClearRenderTargetView( m_mainRenderTargetView, clear_color_with_alpha );

        ImGui_ImplDX11_NewFrame( );
        ImGui_ImplWin32_NewFrame( );
        FeedMousePos( hwnd );
        ImGui::NewFrame( );

        if ( render_callback )
            render_callback( );

        if ( GetAsyncKeyState( VK_ESCAPE ) & 1 && presented )
            threadActive = false;

        ImGui::Render( );
        ImGui_ImplDX11_RenderDrawData( ImGui::GetDrawData( ) );

        HRESULT hr = m_swapChain->Present( 1, 0 ); // Present with vsync
        // HRESULT hr = g_pSwapChain->Present(0, 0); // Present without vsync
        m_swapChainOccluded = ( hr == DXGI_STATUS_OCCLUDED );
    }

    ImGui_ImplDX11_Shutdown( );
    ImGui_ImplWin32_Shutdown( );
    ImGui::DestroyContext( );

    cleanupDeviceD3D( );
    ::DestroyWindow( hwnd );
    ::UnregisterClassW( wc.lpszClassName, wc.hInstance );

    exit( 1 );
}

bool CGraphics::createDeviceD3D( HWND hWnd )
{
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory( &sd, sizeof( sd ) );
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    // createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[ 2 ] = {
        D3D_FEATURE_LEVEL_11_0,
        D3D_FEATURE_LEVEL_10_0,
    };
    HRESULT res = D3D11CreateDeviceAndSwapChain( nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &m_swapChain, &m_device, &featureLevel, &m_deviceContext );
    if ( res == DXGI_ERROR_UNSUPPORTED )
        res = D3D11CreateDeviceAndSwapChain( nullptr, D3D_DRIVER_TYPE_WARP, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &m_swapChain, &m_device, &featureLevel, &m_deviceContext );
    if ( res != S_OK )
        return false;

    createRenderTarget( );
    return true;
}

void CGraphics::cleanupDeviceD3D( )
{
    cleanupRenderTarget( );
    if ( m_swapChain )
    {
        m_swapChain->Release( );
        m_swapChain = nullptr;
    }
    if ( m_deviceContext )
    {
        m_deviceContext->Release( );
        m_deviceContext = nullptr;
    }
    if ( m_device )
    {
        m_device->Release( );
        m_device = nullptr;
    }
}

void CGraphics::createRenderTarget( )
{
    ID3D11Texture2D* pBackBuffer;
    m_swapChain->GetBuffer( 0, IID_PPV_ARGS( &pBackBuffer ) );
    m_device->CreateRenderTargetView( pBackBuffer, nullptr, &m_mainRenderTargetView );
    pBackBuffer->Release( );
}

void CGraphics::cleanupRenderTarget( )
{
    if ( m_mainRenderTargetView )
    {
        m_mainRenderTargetView->Release( );
        m_mainRenderTargetView = nullptr;
    }
}



extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );

LRESULT WINAPI CGraphics::wndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    // if ( gUI.isPresented( ) )
    {
        if ( ImGui_ImplWin32_WndProcHandler( hWnd, msg, wParam, lParam ) )
            return true;
    }

    switch ( msg )
    {
    case WM_NCHITTEST:
    {
        if ( !ctx->kallcode->ui->isPresented( ) )
            return HTTRANSPARENT;

        ImGuiContext* ctx = ImGui::GetCurrentContext( );
        if ( !ctx )
            return HTTRANSPARENT;

        ImGuiIO& io = ImGui::GetIO( );
        bool imguiWantsMouse = io.WantCaptureMouse || ImGui::IsWindowHovered( ImGuiHoveredFlags_AnyWindow ) || ImGui::IsAnyItemHovered( );

        return imguiWantsMouse ? HTCLIENT : HTTRANSPARENT;
    }
    case WM_SIZE:
        if ( wParam == SIZE_MINIMIZED )
            return 0;
        ctx->kallcode->resizeWidth = ( UINT ) LOWORD( lParam ); // Queue resize
        ctx->kallcode->resizeHeight = ( UINT ) HIWORD( lParam );
        return 0;
    case WM_SYSCOMMAND:
        if ( ( wParam & 0xfff0 ) == SC_KEYMENU ) // Disable ALT application menu
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage( 0 );
        return 0;
    case WM_INPUT:
    {
        UINT size = 0;
        GetRawInputData( ( HRAWINPUT ) lParam, RID_INPUT, nullptr, &size, sizeof( RAWINPUTHEADER ) );

        static BYTE buffer[ sizeof( RAWINPUT ) ];
        if ( GetRawInputData( ( HRAWINPUT ) lParam, RID_INPUT, buffer, &size, sizeof( RAWINPUTHEADER ) ) != size )
            break;

        RAWINPUT* raw = ( RAWINPUT* ) buffer;

        if ( raw->header.dwType == RIM_TYPEKEYBOARD )
        {
            const RAWKEYBOARD& k = raw->data.keyboard;

            bool down = !( k.Flags & RI_KEY_BREAK );
            UINT vk = k.VKey;

            HandleKey( vk, down );
        } else if ( raw->header.dwType == RIM_TYPEMOUSE )
        {
            const RAWMOUSE& m = raw->data.mouse;

            if ( m.usButtonFlags & RI_MOUSE_LEFT_BUTTON_DOWN )
                HandleMouse( 0, true );
            if ( m.usButtonFlags & RI_MOUSE_LEFT_BUTTON_UP )
                HandleMouse( 0, false );

            if ( m.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_DOWN )
                HandleMouse( 1, true );
            if ( m.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_UP )
                HandleMouse( 1, false );

            if ( m.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_DOWN )
                HandleMouse( 2, true );
            if ( m.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_UP )
                HandleMouse( 2, false );

            if ( m.usButtonFlags & RI_MOUSE_WHEEL )
            {
                SHORT delta = ( SHORT ) m.usButtonData;
                HandleScroll( delta );
            }
        }

        return 0;
    }
    }
    return ::DefWindowProcW( hWnd, msg, wParam, lParam );
}

