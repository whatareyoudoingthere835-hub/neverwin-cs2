//
// Created by rei on 1/28/2026.
//

#ifndef SCATTEREDABYSS_DESKTOP_GRAPHICS_HPP
#define SCATTEREDABYSS_DESKTOP_GRAPHICS_HPP

#include <d3d11.h>
#include <functional>

#include "imgui.h"
#include "imgui_internal.h"

namespace zhironium
{
    class CGraphics
    {
        bool createDeviceD3D( HWND hWnd );
        void cleanupDeviceD3D( );
        void createRenderTarget( );
        void cleanupRenderTarget( );

        static LRESULT WINAPI wndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );

    public:
        bool loadTextureFromMemory( const void* data, size_t data_size, ID3D11ShaderResourceView** out_srv, int* out_width, int* out_height );
        static ID3D11Device* m_device;
        static ID3D11DeviceContext* m_deviceContext;
        static IDXGISwapChain* m_swapChain;
        static bool m_swapChainOccluded;
        static ID3D11RenderTargetView* m_mainRenderTargetView;

        bool threadActive = true;
        
        void execute( const std::function< void( ) >& init_callback, const std::function< void( ) >& render_callback );

        ImTextureID loadTextureFromFile( const char* file_name );
    };
} // namespace zhironium

#endif // SCATTEREDABYSS_DESKTOP_GRAPHICS_HPP
