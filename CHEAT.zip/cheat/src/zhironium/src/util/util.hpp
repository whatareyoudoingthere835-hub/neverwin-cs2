//
// Created by rei on 1/28/2026.
//

#ifndef SCATTEREDABYSS_DESKTOP_UTIL_HPP
#define SCATTEREDABYSS_DESKTOP_UTIL_HPP

#include <string>

namespace zhironium
{
    namespace win_api
    {
        bool isProcessRunning( const std::string& name );
    }
} // namespace zhironium

#endif // SCATTEREDABYSS_DESKTOP_UTIL_HPP
