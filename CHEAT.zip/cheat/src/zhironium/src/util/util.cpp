//
// Created by rei on 1/28/2026.
//

#include "util.hpp"

#include <windows.h>
#include <tlhelp32.h>

bool zhironium::win_api::isProcessRunning( const std::string& name )
{
    HANDLE const snapshot = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
    if ( snapshot == INVALID_HANDLE_VALUE )
        return false;

    PROCESSENTRY32W entry { };
    entry.dwSize = sizeof( entry );

    if ( Process32FirstW( snapshot, &entry ) )
    {
        do
        {
            std::wstring wExe( entry.szExeFile );
            std::string exeA( wExe.begin(), wExe.end() );
            if ( exeA == name )
            {
                CloseHandle( snapshot );
                return true;
            }
        }
        while ( Process32NextW( snapshot, &entry ) );
    }

    CloseHandle( snapshot );
    return false;
}