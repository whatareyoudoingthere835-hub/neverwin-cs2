#pragma once

#include "data_management.hpp"

#include "imgui.h"
#include "ui/binder/binder.hpp"
#include <unordered_map>

namespace zhironium
{
    struct Config
    {
        declare_variable( bool, espRect, false );

        declare_variable( bool, uiEnableGlowLogo, true );
        declare_variable( bool, uiEnableGlowMain, true );
        declare_variable( bool, dreamMode, false );

        std::unordered_map< std::string, std::vector< kallcode::BindBool > > globalBinds { };
        std::unordered_map< std::string, std::vector< kallcode::BindInt > > globalIntBinds { };
        std::unordered_map< std::string, std::vector< kallcode::BindFloat > > globalBindsFloat { };
        std::unordered_map< std::string, std::vector< kallcode::BindInt > > globalBindsInt { };
        std::vector< kallcode::BindBool > espRectBinds { };
        std::vector< kallcode::BindBool > teleportBinds { };
        std::vector< kallcode::BindBool > stopBinds { };
        std::vector< kallcode::BindBool > aimbotBinds { };
        std::vector< kallcode::BindBool > triggerbotBinds { };
        std::vector< kallcode::BindBool > autofireBinds { };
    };
} // namespace zhironium
