//
// Created by rei on 12/2/2025.
//

#ifndef ZHIRONIUM_UI_FONTS_HPP
#define ZHIRONIUM_UI_FONTS_HPP

#include <unordered_map>
#include <string>

#include "imgui.h"

namespace kallcode
{
    struct Font
    {
        ImFont* ptr;
        int size;

        static constexpr int kMaxFontScale = 4;
    };

    class CFonts
    {
        std::unordered_map< std::string, Font > m_list;

    public:
        ~CFonts( ) = default;
        CFonts( ) = default;

        void init( );

        Font& get( const std::string& key );
    };
} // namespace kallcode

#endif // ZHIRONIUM_UI_FONTS_HPP
