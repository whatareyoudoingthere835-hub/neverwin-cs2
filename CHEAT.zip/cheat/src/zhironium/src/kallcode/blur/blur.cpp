#include "blur.hpp"
#include <d3dcompiler.h>

#pragma comment(lib, "d3dcompiler.lib")

CBlur g_blur;

static const char* szBlurShader = R"(
cbuffer BlurParams : register(b0)
{
    float texel_width;
    float texel_height;
    float dir_x;
    float dir_y;
};

Texture2D tex : register(t0);
SamplerState samp : register(s0);

struct VS_Input {
    uint id : SV_VertexID;
};

struct PS_Input {
    float4 pos : SV_POSITION;
    float2 uv : TEXCOORD0;
};

PS_Input VS(VS_Input input) {
    PS_Input output;
    float2 uv = float2((input.id << 1) & 2, input.id & 2);
    output.uv = uv;
    output.pos = float4(uv.x * 2.0f - 1.0f, 1.0f - uv.y * 2.0f, 0.0f, 1.0f);
    return output;
}

float4 PS(PS_Input input) : SV_TARGET {
    float4 color = float4(0.0f, 0.0f, 0.0f, 0.0f);
    float2 dir = float2(dir_x * texel_width * 2.0f, dir_y * texel_height * 2.0f);
    
    float weight[5] = {0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216};
    
    color += tex.Sample(samp, input.uv) * weight[0];
    for (int i = 1; i < 5; i++) {
        color += tex.Sample(samp, input.uv + dir * float(i)) * weight[i];
        color += tex.Sample(samp, input.uv - dir * float(i)) * weight[i];
    }
    
    return color;
}
)";

bool CBlur::Initialize(ID3D11Device* device, ID3D11DeviceContext* context) {
    if (m_initialized) return true;
    m_device = device;
    m_context = context;

    ID3DBlob* vsBlob = nullptr;
    ID3DBlob* psBlob = nullptr;
    ID3DBlob* errorBlob = nullptr;

    HRESULT hr = D3DCompile(szBlurShader, strlen(szBlurShader), "BlurShader", nullptr, nullptr, "VS", "vs_5_0", 0, 0, &vsBlob, &errorBlob);
    if (FAILED(hr)) {
        if (errorBlob) errorBlob->Release();
        return false;
    }
    m_device->CreateVertexShader(vsBlob->GetBufferPointer(), vsBlob->GetBufferSize(), nullptr, &m_vertexShader);
    vsBlob->Release();

    hr = D3DCompile(szBlurShader, strlen(szBlurShader), "BlurShader", nullptr, nullptr, "PS", "ps_5_0", 0, 0, &psBlob, &errorBlob);
    if (FAILED(hr)) {
        if (errorBlob) errorBlob->Release();
        return false;
    }
    m_device->CreatePixelShader(psBlob->GetBufferPointer(), psBlob->GetBufferSize(), nullptr, &m_pixelShader);
    psBlob->Release();

    D3D11_BUFFER_DESC cbDesc = {};
    cbDesc.Usage = D3D11_USAGE_DYNAMIC;
    cbDesc.ByteWidth = sizeof(BlurParams);
    if (cbDesc.ByteWidth % 16 != 0) cbDesc.ByteWidth += 16 - (cbDesc.ByteWidth % 16);
    cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    cbDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    m_device->CreateBuffer(&cbDesc, nullptr, &m_constantBuffer);

    D3D11_SAMPLER_DESC sampDesc = {};
    sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
    sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
    sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
    sampDesc.MinLOD = 0;
    sampDesc.MaxLOD = D3D11_FLOAT32_MAX;
    m_device->CreateSamplerState(&sampDesc, &m_samplerState);

    D3D11_BLEND_DESC blendDesc = {};
    blendDesc.RenderTarget[0].BlendEnable = FALSE;
    blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    m_device->CreateBlendState(&blendDesc, &m_blendState);

    D3D11_RASTERIZER_DESC rasterDesc = {};
    rasterDesc.FillMode = D3D11_FILL_SOLID;
    rasterDesc.CullMode = D3D11_CULL_NONE;
    rasterDesc.DepthClipEnable = FALSE;
    m_device->CreateRasterizerState(&rasterDesc, &m_rasterizerState);

    D3D11_DEPTH_STENCIL_DESC depthDesc = {};
    depthDesc.DepthEnable = FALSE;
    depthDesc.StencilEnable = FALSE;
    m_device->CreateDepthStencilState(&depthDesc, &m_depthStencilState);

    m_initialized = true;
    return true;
}

void CBlur::SetupRenderTargets(int width, int height) {
    if (m_width == width && m_height == height && m_renderTargetTexture != nullptr)
        return;

    if (m_renderTargetTexture) m_renderTargetTexture->Release();
    if (m_renderTargetView) m_renderTargetView->Release();
    if (m_shaderResourceView) m_shaderResourceView->Release();

    if (m_tempTexture) m_tempTexture->Release();
    if (m_tempRenderTargetView) m_tempRenderTargetView->Release();
    if (m_tempShaderResourceView) m_tempShaderResourceView->Release();

    m_width = width;
    m_height = height;

    D3D11_TEXTURE2D_DESC texDesc = {};
    texDesc.Width = width;
    texDesc.Height = height;
    texDesc.MipLevels = 1;
    texDesc.ArraySize = 1;
    texDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    texDesc.SampleDesc.Count = 1;
    texDesc.Usage = D3D11_USAGE_DEFAULT;
    texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;

    m_device->CreateTexture2D(&texDesc, nullptr, &m_renderTargetTexture);
    m_device->CreateRenderTargetView(m_renderTargetTexture, nullptr, &m_renderTargetView);
    m_device->CreateShaderResourceView(m_renderTargetTexture, nullptr, &m_shaderResourceView);

    m_device->CreateTexture2D(&texDesc, nullptr, &m_tempTexture);
    m_device->CreateRenderTargetView(m_tempTexture, nullptr, &m_tempRenderTargetView);
    m_device->CreateShaderResourceView(m_tempTexture, nullptr, &m_tempShaderResourceView);
}

void CBlur::Shutdown() {
    if (!m_initialized) return;
    
    if (m_renderTargetTexture) { m_renderTargetTexture->Release(); m_renderTargetTexture = nullptr; }
    if (m_renderTargetView) { m_renderTargetView->Release(); m_renderTargetView = nullptr; }
    if (m_shaderResourceView) { m_shaderResourceView->Release(); m_shaderResourceView = nullptr; }

    if (m_tempTexture) { m_tempTexture->Release(); m_tempTexture = nullptr; }
    if (m_tempRenderTargetView) { m_tempRenderTargetView->Release(); m_tempRenderTargetView = nullptr; }
    if (m_tempShaderResourceView) { m_tempShaderResourceView->Release(); m_tempShaderResourceView = nullptr; }

    if (m_vertexShader) { m_vertexShader->Release(); m_vertexShader = nullptr; }
    if (m_pixelShader) { m_pixelShader->Release(); m_pixelShader = nullptr; }
    if (m_constantBuffer) { m_constantBuffer->Release(); m_constantBuffer = nullptr; }
    if (m_samplerState) { m_samplerState->Release(); m_samplerState = nullptr; }
    if (m_blendState) { m_blendState->Release(); m_blendState = nullptr; }
    if (m_rasterizerState) { m_rasterizerState->Release(); m_rasterizerState = nullptr; }
    if (m_depthStencilState) { m_depthStencilState->Release(); m_depthStencilState = nullptr; }

    m_initialized = false;
}

void CBlur::OnPresent(IDXGISwapChain* swapChain) {
    if (!m_initialized) return;

    ID3D11Texture2D* backBuffer = nullptr;
    if (FAILED(swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&backBuffer))) return;

    D3D11_TEXTURE2D_DESC bbDesc;
    backBuffer->GetDesc(&bbDesc);

    // Downsample for stronger blur and better performance
    int blurWidth = bbDesc.Width / 2;
    int blurHeight = bbDesc.Height / 2;

    SetupRenderTargets(blurWidth, blurHeight);

    ID3D11RenderTargetView* oldRTV = nullptr;
    ID3D11DepthStencilView* oldDSV = nullptr;
    m_context->OMGetRenderTargets(1, &oldRTV, &oldDSV);
    D3D11_VIEWPORT oldVP;
    UINT numVPs = 1;
    m_context->RSGetViewports(&numVPs, &oldVP);

    D3D11_VIEWPORT vp = {};
    vp.Width = (float)blurWidth;
    vp.Height = (float)blurHeight;
    vp.MaxDepth = 1.0f;
    m_context->RSSetViewports(1, &vp);

    ID3D11ShaderResourceView* bbSRV = nullptr;
    m_device->CreateShaderResourceView(backBuffer, nullptr, &bbSRV);
    
    if (bbSRV) {
        m_context->IASetInputLayout(nullptr);
        m_context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        m_context->VSSetShader(m_vertexShader, nullptr, 0);
        m_context->PSSetShader(m_pixelShader, nullptr, 0);
        m_context->PSSetSamplers(0, 1, &m_samplerState);

        const float blendFactor[4] = { 0.f, 0.f, 0.f, 0.f };
        m_context->OMSetBlendState(m_blendState, blendFactor, 0xffffffff);
        m_context->RSSetState(m_rasterizerState);
        m_context->OMSetDepthStencilState(m_depthStencilState, 0);

        BlurParams params;
        params.texel_width = 1.0f / blurWidth;
        params.texel_height = 1.0f / blurHeight;

        // Pass 1: Horizontal Blur (from backbuffer to temp)
        m_context->OMSetRenderTargets(1, &m_tempRenderTargetView, nullptr);
        params.dir_x = 1.0f; params.dir_y = 0.0f;
        D3D11_MAPPED_SUBRESOURCE mapped;
        m_context->Map(m_constantBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
        memcpy(mapped.pData, &params, sizeof(BlurParams));
        m_context->Unmap(m_constantBuffer, 0);
        m_context->PSSetConstantBuffers(0, 1, &m_constantBuffer);
        m_context->PSSetShaderResources(0, 1, &bbSRV);
        m_context->Draw(3, 0);

        // Pass 2: Vertical Blur (from temp to final)
        m_context->OMSetRenderTargets(1, &m_renderTargetView, nullptr);
        params.dir_x = 0.0f; params.dir_y = 1.0f;
        m_context->Map(m_constantBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
        memcpy(mapped.pData, &params, sizeof(BlurParams));
        m_context->Unmap(m_constantBuffer, 0);
        
        ID3D11ShaderResourceView* nullSRV[1] = { nullptr };
        m_context->PSSetShaderResources(0, 1, nullSRV); // Unbind before reading
        m_context->PSSetShaderResources(0, 1, &m_tempShaderResourceView);
        m_context->Draw(3, 0);

        m_context->PSSetShaderResources(0, 1, nullSRV);
        bbSRV->Release();
    }

    m_context->OMSetRenderTargets(1, &oldRTV, oldDSV);
    m_context->RSSetViewports(numVPs, &oldVP);

    if (oldRTV) oldRTV->Release();
    if (oldDSV) oldDSV->Release();
    backBuffer->Release();
}

void CBlur::applyBlur(const ImRect& rect, ImDrawList* draw_list, float rounding, float strength, float alpha, bool fill) {
    if (!m_initialized || !m_shaderResourceView) return;

    ImGuiIO& io = ImGui::GetIO();
    float w = io.DisplaySize.x;
    float h = io.DisplaySize.y;

    ImVec2 uvMin(rect.Min.x / w, rect.Min.y / h);
    ImVec2 uvMax(rect.Max.x / w, rect.Max.y / h);

    int a = (int)(alpha * 255.0f);
    draw_list->AddImageRounded((ImTextureID)m_shaderResourceView, rect.Min, rect.Max, uvMin, uvMax, IM_COL32(255, 255, 255, a), rounding);
}
