#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <d3d11.h>
#include "../../../../../ext/imgui/imgui.h"
#include "../../../../../ext/imgui/imgui_internal.h"

class CBlur {
public:
    bool Initialize(ID3D11Device* device, ID3D11DeviceContext* context);
    void Shutdown();

    // Call this before ImGui::Render() or during Present to update the blurred background
    void OnPresent(IDXGISwapChain* swapChain);

    // Call this from UI code to draw the blurred texture
    void applyBlur(const ImRect& rect, ImDrawList* draw_list, float rounding, float strength, float alpha, bool fill = false);

private:
    void SetupRenderTargets(int width, int height);

    ID3D11Device* m_device = nullptr;
    ID3D11DeviceContext* m_context = nullptr;

    ID3D11VertexShader* m_vertexShader = nullptr;
    ID3D11PixelShader* m_pixelShader = nullptr;
    ID3D11Buffer* m_constantBuffer = nullptr;
    ID3D11SamplerState* m_samplerState = nullptr;

    // We use a downsampled target for better performance and blur radius
    ID3D11Texture2D* m_renderTargetTexture = nullptr;
    ID3D11RenderTargetView* m_renderTargetView = nullptr;
    ID3D11ShaderResourceView* m_shaderResourceView = nullptr;

    ID3D11Texture2D* m_tempTexture = nullptr;
    ID3D11RenderTargetView* m_tempRenderTargetView = nullptr;
    ID3D11ShaderResourceView* m_tempShaderResourceView = nullptr;

    ID3D11BlendState* m_blendState = nullptr;
    ID3D11RasterizerState* m_rasterizerState = nullptr;
    ID3D11DepthStencilState* m_depthStencilState = nullptr;

    int m_width = 0;
    int m_height = 0;
    bool m_initialized = false;

    struct BlurParams {
        float texel_width;
        float texel_height;
        float dir_x;
        float dir_y;
    };
};

extern CBlur g_blur;
