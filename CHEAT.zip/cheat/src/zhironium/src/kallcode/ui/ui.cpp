#define IMGUI_DEFINE_MATH_OPERATORS
#undef min
#undef max
//
// Created by kallcode on 16/06/2026.
//

#include "ui.hpp"
#include "../../../../base.hpp"

#include "animator/animator.hpp"
#include "../blur/blur.hpp"
#include "core.hpp"
#include "../graphics/graphics.hpp"
#include "../fonts/fonts.hpp"
#include "../fonts/include/font_awesome/font_awesome.hpp"
#include "alerts/alerts.hpp"
#include "assets/assets.hpp"
#include "popups/popups.hpp"
#include "binder/binder.hpp"
#include "tabs/tabs.hpp"
#include "themes/themes.hpp"
// removed hitlogs
#include "widgets/keybinds/keybinds.hpp"
#include "widgets/watermark/watermark.hpp"
#include "../../../../core/settings.hpp"
#include "../../../../features/spotify/spotify.hpp"
#include "../../../../../src/base.hpp"
#include "../../../../render/configs.h"
#include "../../../../features/skinchanger/skindb_local.hpp"
#include <activation.h>
#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <map>
#include <ostream>
#include <random>
#include <thread>
#undef min
#undef max

using kallcode::CUIElements;
using kallcode::CUserInterface;

using namespace ImGui;

// prefs should load here
CUserInterface::CUserInterface( ) = default;
CUserInterface::~CUserInterface( ) = default;

std::string CUserInterface::getTabName(int index) const {
    if (index >= 0 && index < m_tabs.size()) {
        return m_tabs[index].name;
    }
    return "";
}

ImTextureID CUserInterface::logo { };
ImTextureID CUserInterface::profile_picture { };

void CUserInterface::renderCategory( Tab* tab ) const
{
    ItemSize( { 0, 0 } );
    SetCursorPosX( 20 );
    TextColored( CThemes::current.colors.tabs.textCategory, "%s", tab->name.c_str( ) );
}

bool CUserInterface::renderTab( Tab* tab, bool active, int width )
{
    auto const cur = GetCursorScreenPos( );
    ImVec2 const btn_sz = { static_cast< float >( width ), 32 };

    bool const ret = InvisibleButton( tab->name.c_str( ), btn_sz );

    auto const hovered = IsItemHovered( );

    ImRect const rect = {
        cur,
        cur + btn_sz };

    tab->background.update( active ? CThemes::current.colors.tabs.backgroundActive : ( hovered ? CThemes::current.colors.tabs.backgroundHovered : CThemes::current.colors.tabs.background ) );

    tab->_icon.update( active ? ImColor( CThemes::current.colors.accent ).Value : ( hovered ? ImColor( CThemes::current.colors.text ).Value : ImColor( CThemes::current.colors.textDim ).Value ) );
    tab->_name.update( active ? ImColor( CThemes::current.colors.text ).Value : ( hovered ? ImColor( CThemes::current.colors.textHover ).Value : ImColor( CThemes::current.colors.textDim ).Value ) );

    auto* draw = GetWindowDrawList( );
    draw->AddRectFilled( rect.Min + ImVec2( 10, 0 ), rect.Max - ImVec2( 10, 0 ), Color( tab->background.get< ImVec4 >( ) ).modulate( ), 6 );
    draw->AddRect( rect.Min + ImVec2( 10, 0 ), rect.Max - ImVec2( 10, 0 ), Color( tab->background.get< ImVec4 >( ) ).modulate( ), 6 );

    auto const icon_size = CalcTextSize( tab->icon.value_or( "0" ).c_str( ) );
    auto const text_size = CalcTextSize( tab->name.c_str( ) );

    if ( tab->icon.has_value( ) )
        draw->AddText( { rect.Min.x + 10 + 10 + GetFontSize( ) / 2 - ( CalcTextSize( tab->icon.value( ).c_str( ) ).x - 1 ) / 2, rect.GetCenter( ).y - icon_size.y / 2 }, Color( tab->_icon.get< ImVec4 >( ) ).modulate( ), tab->icon->c_str( ) );

    draw->AddText( { rect.Min.x + 10 + 10 + 10 + GetFontSize( ), rect.GetCenter( ).y - text_size.y / 2 }, Color( tab->_name.get< ImVec4 >( ) ).modulate( ), tab->name.c_str( ) );

    return ret;
}

bool CUserInterface::renderSubTab( SubTab* subtab, bool active, int idx )
{
    auto const cur = GetCursorScreenPos( );
    auto const text_size = CalcTextSize( subtab->name.c_str( ) );
    auto const width = text_size.x + 14 * 2;
    ImVec2 const btn_sz = { static_cast< float >( width ), GetContentRegionAvail( ).y };

    auto const ret = InvisibleButton( subtab->name.c_str( ), btn_sz );

    auto const hovered = IsItemHovered( );

    ImRect const rect = {
        cur,
        cur + btn_sz };

    subtab->background.update( active ? ImColor( CThemes::current.colors.tabs.backgroundActive ).Value : ( hovered ? ImColor( CThemes::current.colors.tabs.backgroundHovered ).Value : ImColor( CThemes::current.colors.tabs.background ).Value ) );
    subtab->_name.update( active ? ImColor( CThemes::current.colors.text ).Value : ( hovered ? ImColor( CThemes::current.colors.textHover ).Value : ImColor( CThemes::current.colors.textDim ).Value ) );

    auto* draw = GetWindowDrawList( );

    draw->AddRectFilled( rect.Min, rect.Max, Color( CThemes::current.colors.tabs.backgroundHovered ).modulate( ), 6, ( idx == 0 ) ? ImDrawFlags_RoundCornersLeft : ImDrawFlags_RoundCornersRight );
    draw->AddRectFilled( rect.Min, rect.Max, Color( subtab->background.get< ImVec4 >( ) ).modulate( ), 6, ( idx == 0 ) ? ImDrawFlags_RoundCornersLeft : ImDrawFlags_RoundCornersRight );

    draw->AddText( rect.GetCenter( ) - text_size / 2, Color( subtab->_name.get< ImVec4 >( ) ).modulate( ), subtab->name.c_str( ) );

    return ret;
}

void CUserInterface::saveButton( const ImVec2& size, const std::function< void( ) >& save_fn )
{
    auto const cur = GetCursorScreenPos( );

    static CAnimator background { ImVec4( 0, 0, 0, 0 ) };
    static CAnimator text_color { ImVec4( 0, 0, 0, 0 ) };

    if ( InvisibleButton( "Save", size ) )
    {
        save_fn( );
        background.set< ImVec4 >( ImColor( CThemes::current.colors.tabs.backgroundClicked ).Value );
        text_color.set< ImVec4 >( ImColor( CThemes::current.colors.text ).Value );
    }

    ImRect const rect = {
        cur,
        cur + size };

    auto const hovered = IsItemHovered( );

    background.update< ImVec4 >( hovered ? ImColor( CThemes::current.colors.tabs.backgroundHovered ).Value : ImColor( CThemes::current.colors.tabs.background ).Value );
    text_color.update< ImVec4 >( ImColor( CThemes::current.colors.textDim ).Value );

    auto* draw = GetWindowDrawList( );
    draw->AddRectFilled( rect.Min, rect.Max, Color( background.get< ImVec4 >( ) ).modulate( ), 6 );
    draw->AddRect( rect.Min, rect.Max, Color( CThemes::current.colors.border ).modulate( ), 6 );

    const char* text = ICON_FA_FLOPPY_DISK "  Save";
    auto const text_size = CalcTextSize( text );
    draw->AddText( rect.GetCenter( ) - text_size / 2, Color( text_color.get< ImVec4 >( ) ).modulate( ), text );
}

void CUserInterface::applyBlurOverlay( ImGuiWindow* window ) const
{
    if ( !window )
        return;

    if ( m_overlayBlurIntensity.get< float >( ) < 0.01f || m_menuOpacity.get< float >( ) < 0.01f )
        return;

    SetCursorPos( { 0, 0 } );
    BeginChild( "##blur", GetWindowSize( ), 0, ImGuiWindowFlags_NoInputs );
    if ( CThemes::current.name == "Liquid Glass" )
        g_blur.applyBlur( window->Rect( ), GetWindowDrawList( ), window->WindowRounding, m_overlayBlurIntensity.get< float >( ) * 4, m_menuOpacity.get< float >( ), false );
    EndChild( );
}

void CUserInterface::MenuSettings::render( const std::function< void( ) >& back_task )
{
    auto* window = GetCurrentWindow( );
    auto const rect = window->Rect( );

    main.update< float >( presented ? 1.f : 0.f );

    if ( main.get< float >( ) < 0.001f )
        return;

    auto const alpha = main.get< float >( ) * GetStyle( ).Alpha;

    {
        SetCursorPos( { 180, 0 } );
        BeginChild( "##settings_blur", GetWindowSize( ), 0 );

        if ( CThemes::current.name == "Liquid Glass" )
            g_blur.applyBlur( { rect.Min + ImVec2( 180, 0 ), rect.Max }, GetWindowDrawList( ), window->WindowRounding, 3.f, alpha, false );

        GetWindowDrawList( )->AddRectFilled( rect.Min + ImVec2( 180, 0 ), rect.Max, Color( CThemes::current.colors.window.settingsOverlay ).modulate( alpha ), window->WindowRounding );
        EndChild( );
    }

    PushStyleVar( ImGuiStyleVar_Alpha, alpha );

    SetCursorPos( { 360, 0 } );

    BeginChild( "##settings", { GetContentRegionAvail( ).x, window->Size.y }, 0 );
    {
        SetCursorPos( { GetWindowSize( ).x - 28 - 10, 10 } );

        {
            static CAnimator gear { ImVec4( 0, 0, 0, 0 ) };

            auto const cur = GetCursorScreenPos( );
            auto const size = ImVec2( 28, 28 );
            if ( InvisibleButton( "##BACK", size ) )
                back_task( );

            auto const hovered = IsItemHovered( );

            ImRect const rect = {
                cur, cur + size };

            gear.update< ImVec4 >( hovered ? ImColor( CThemes::current.colors.text ) : ImColor( CThemes::current.colors.textDim ) );

            ImGui::SetWindowFontScale( 1.3f );
            GetWindowDrawList( )->AddText( rect.GetCenter( ) - CalcTextSize( ICON_FA_ANGLE_LEFT ) / 2 - ImVec2(0, 2), Color( gear.get< ImVec4 >( ) ).modulate( ), ICON_FA_ANGLE_LEFT );
            ImGui::SetWindowFontScale( 1.0f );
        }

        SetCursorPos( { 0, 48 } );

        PushStyleVar( ImGuiStyleVar_WindowPadding, { 10, 10 } );

        BeginChild( "##settings_area", GetContentRegionAvail( ), ImGuiChildFlags_AlwaysAutoResize | ImGuiChildFlags_AutoResizeY, 0 );
        {
            CUIElements::text( "UI" );

            {
                auto& themes = zhironium::ctx->kallcode->themes->getAllThemes( );

                static std::vector< std::string > themeNames;
                static std::vector< Theme* > themePtrs;

                themeNames.clear( );
                themePtrs.clear( );

                for ( auto& [ name, theme ] : themes )
                {
                    themeNames.push_back( name );
                    themePtrs.push_back( &theme );
                }

                static int currentThemeIndex = 0;

                for ( int i = 0; i < themePtrs.size( ); ++i )
                {
                    if ( themePtrs[ i ] == &CThemes::current )
                    {
                        currentThemeIndex = i;
                        break;
                    }
                }

                if ( CUIElements::combo( ElemType::Begin, "Theme", &currentThemeIndex, themeNames ) )
                {
                    CThemes::current = *themePtrs[ currentThemeIndex ];
                }
            }

            CUIElements::toggle( ElemType::Middle, "Main glow", &zhironium::c::get< bool >( zhironium::ctx->config.uiEnableGlowMain ) );
            CUIElements::toggle( ElemType::Middle, "Logo glow", &zhironium::c::get< bool >( zhironium::ctx->config.uiEnableGlowLogo ) );

            CUIElements::color( ElemType::Middle, "Accent color", { &CThemes::current.colors.accent } );

            static CPopup wg( 150, "Widgets", std::nullopt );
            if ( CUIElements::button( ElemType::End, "Widgets" ) && wg.allowOpen( ) )
            {
                wg.setPosition( { GetItemRectMax( ).x - 160, GetItemRectMin( ).y - 40 } );
                wg.opened = true;
            }

            if ( wg.begin( ) )
            {
                PopupEntries::toggle( std::nullopt, "Watermark", &zhironium::ctx->kallcode->widgets->watermark->enabled );
                
                PopupEntries::separator( );
                
                PopupEntries::toggle( std::nullopt, "Keybinds", &zhironium::ctx->kallcode->widgets->keybinds->enabled );
                // PopupEntries::toggle( std::nullopt, "Hit logs", &zhironium::ctx->kallcode->widgets->hitLogs->enabled );

                wg.end( );
            }


            CUIElements::text( CS_XOR("SPOTIFY") );
            
            if ( CUIElements::button( ElemType::Single, CS_XOR("Log In with Spotify") ) )
            {
                zhironium::ctx->kallcode->alerts->create( CS_XOR("Spotify Setup"), { 260 * 1.0f, 230 * 1.0f }, []( kallcode::Alert& alert ) {
                    using namespace ImGui;

                    PushStyleVar(ImGuiStyleVar_FrameRounding, 6.0f * 1.0f);
                    PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8 * 1.0f, 6 * 1.0f));
                    PushStyleColor(ImGuiCol_FrameBg, ImColor(CThemes::current.colors.elem.backgroundOverlay).Value);
                    PushStyleColor(ImGuiCol_Text, ImColor(CThemes::current.colors.text).Value);
                    PushStyleColor(ImGuiCol_TextDisabled, ImColor(CThemes::current.colors.textDim).Value);

                    ImGui::SetNextItemWidth(GetContentRegionAvail().x);
                    ImGui::InputTextWithHint(CS_XOR("##client_id"), CS_XOR("Client ID..."), Settings::spotify_client_id, sizeof(Settings::spotify_client_id));
                    ImGui::Dummy(ImVec2(0, 5.0f));
                    ImGui::SetNextItemWidth(GetContentRegionAvail().x);
                    ImGui::InputTextWithHint(CS_XOR("##client_secret"), CS_XOR("Client Secret..."), Settings::spotify_client_secret, sizeof(Settings::spotify_client_secret));

                    PopStyleColor(3);
                    PopStyleVar(2);
                    
                    ImGui::Dummy(ImVec2(0, 10.0f));
                    std::string statusStr = SPOTIFY::IsAuthorized() ? CS_XOR("Status: Authorized") : CS_XOR("Status: Not Authorized");
                    ImColor statusColor = SPOTIFY::IsAuthorized() ? ImColor(30, 215, 96) : ImColor(CThemes::current.colors.textDim);
                    statusColor.Value.w *= alert.alpha.get<float>();
                    GetWindowDrawList()->AddText(GetCursorScreenPos() + ImVec2(10, 0), statusColor, statusStr.c_str());
                    
                    SetCursorPosY( GetWindowSize( ).y - 44 * 1.0f );
                    
                    float halfWidth = (GetContentRegionAvail().x - 10.0f) / 2.0f;
                    if ( CAlerts::button( CS_XOR("Authenticate"), { halfWidth, 35.0f }, true ) )
                    {
                        SPOTIFY::Authenticate();
                    }
                    ImGui::SameLine( 0, 10.0f );
                    if ( CAlerts::button( CS_XOR("Close"), { halfWidth, 35.0f }, false ) )
                    {
                        alert.close();
                    }
                } );
            }

            EndChild( );
        }

        PopStyleVar( );

        EndChild( );
    }

    PopStyleVar( );
}

void CUserInterface::init( )
{
    g_SkinDB->Initialize();

    auto& style = GetStyle( );

    // style.Scale = 1;
    style.WindowRounding = 12;
    style.WindowBorderSize = 0;
    style.ScrollbarRounding = 12;
    style.ScrollbarSize = 3;

    m_tabs.clear();

    Tab combat_tab;
    combat_tab.name = CS_XOR("COMBAT");
    combat_tab.type = TabType::Category;
    m_tabs.push_back(combat_tab);

    Tab legitbot_tab;
    legitbot_tab.name = CS_XOR("Legitbot");
    legitbot_tab.icon = ICON_FA_CROSSHAIRS;
    legitbot_tab.type = TabType::Tab;
    legitbot_tab.callback = tabs::callLegitbot;
    SubTab aimbot_sub;
    aimbot_sub.name = CS_XOR("Aimbot");
    aimbot_sub.callback = tabs::callLegitbot;
    aimbot_sub.keywords = {"aimbot", "enable aimbot", "hitbox", "seed trigger", "fov"};
    legitbot_tab.subTabs = std::vector<SubTab>{ aimbot_sub };
    m_tabs.push_back(legitbot_tab);

    Tab visual_tab;
    visual_tab.name = CS_XOR("VISUAL");
    visual_tab.type = TabType::Category;
    m_tabs.push_back(visual_tab);

    Tab entities_tab;
    entities_tab.name = CS_XOR("Visuals");
    entities_tab.icon = ICON_FA_USER;
    entities_tab.type = TabType::Tab;
    entities_tab.callback = tabs::callVisual;
    entities_tab.keywords = {"esp", "enable esp", "bounding box", "player name", "health bar", "chams", "enable chams"};
    
    SubTab esp_sub;
    esp_sub.name = CS_XOR("Entities");
    esp_sub.callback = tabs::callVisual;
    esp_sub.keywords = {"esp", "enable esp", "bounding box", "player name", "health bar", "chams", "enable chams"};

    SubTab world_sub;
    world_sub.name = CS_XOR("World");
    world_sub.callback = tabs::callWorld;
    world_sub.keywords = {"world", "visual", "colors", "fog", "skybox", "grenade warning"};
    entities_tab.subTabs = std::vector<SubTab>{ esp_sub, world_sub };

    m_tabs.push_back(entities_tab);

    Tab inventory_tab;
    inventory_tab.name = CS_XOR("INVENTORY");
    inventory_tab.type = TabType::Category;
    m_tabs.push_back(inventory_tab);

    Tab skins_tab;
    skins_tab.name = CS_XOR("Skins");
    skins_tab.icon = ICON_FA_PALETTE;
    skins_tab.type = TabType::Tab;
    skins_tab.callback = tabs::callSkins;
    skins_tab.keywords = {"skins", "paint", "glove", "knife", "skinchanger"};
    m_tabs.push_back(skins_tab);

    Tab movement_tab;
    movement_tab.name = CS_XOR("MOVEMENT");
    movement_tab.type = TabType::Category;
    m_tabs.push_back(movement_tab);

    Tab misc_tab;
    misc_tab.name = CS_XOR("Misc");
    misc_tab.icon = ICON_FA_PERSON_RUNNING;
    misc_tab.type = TabType::Tab;
    misc_tab.callback = tabs::callWorldMisc;
    SubTab misc_sub;
    misc_sub.name = CS_XOR("Movement");
    misc_sub.callback = tabs::callWorldMisc;
    misc_sub.keywords = {"bhop", "movement"};
    misc_tab.subTabs = std::vector<SubTab>{ misc_sub };
    m_tabs.push_back(misc_tab);

    Tab local_tab;
    local_tab.name = CS_XOR("LOCAL");
    local_tab.type = TabType::Category;
    m_tabs.push_back(local_tab);


    Tab configs_tab;
    configs_tab.name = CS_XOR("Configs");
    configs_tab.icon = ICON_FA_FOLDER;
    configs_tab.type = TabType::Tab;
    configs_tab.callback = tabs::callConfig;
    configs_tab.keywords = {"configs", "load", "save", "delete", "create"};
    m_tabs.push_back(configs_tab);

    m_selectedTab = 1;
    m_pendingTab = 1;
    m_callback = m_tabs[ m_selectedTab ].callback;

    zhironium::ctx->kallcode->themes->addDefaults( );
}

void CUserInterface::render( )
{
    static bool fetched = false;
    if (!fetched) {
        fetched = true;
        std::thread([]() {
            configs::fetch_user_info();
        }).detach();
    }

    g_SkinDB->ProcessTextures();

    if ( !m_presented ) {
        return;
    }
    static bool search_presented = false;

    PushStyle padding( ImGuiStyleVar_WindowPadding, ImVec2 { 0, 0 } );

    auto& io = GetIO( );
    auto& style = GetStyle( );

    style.Colors[ ImGuiCol_WindowBg ] = CThemes::current.colors.window.background;
    style.Colors[ ImGuiCol_ScrollbarGrab ] = CThemes::current.colors.scrollbar.grab;
    style.Colors[ ImGuiCol_ScrollbarGrabHovered ] = CThemes::current.colors.scrollbar.grab;
    style.Colors[ ImGuiCol_ScrollbarGrabActive ] = CThemes::current.colors.scrollbar.grab;
    style.Colors[ ImGuiCol_ScrollbarBg ] = CThemes::current.colors.scrollbar.background;
    style.Colors[ ImGuiCol_Text ] = CThemes::current.colors.text;

    m_overlayBlurIntensity.update< float >( m_presented ? 0.f : 1.f, 0.25f );

    if ( m_transition.active )
    {
        if ( m_transition.target == TransitionTarget::Tab )
        {
            m_subTabsAreaOpacity.set< float >( m_transition.alpha.get< float >( ) );
            m_mainAreaOpacity.set< float >( m_transition.alpha.get< float >( ) );
            m_mainAreaInnerBlur.set< float >( m_transition.alpha.get< float >( ) );
        } else if ( m_transition.target == TransitionTarget::SubTab )
        {
            m_mainAreaOpacity.set< float >( m_transition.alpha.get< float >( ) );
            m_mainAreaInnerBlur.set< float >( m_transition.alpha.get< float >( ) );
        }
    } else
    {
        m_subTabsAreaOpacity.update< float >( 1.f );
        m_mainAreaOpacity.update< float >( 1.f );
        m_mainAreaInnerBlur.update< float >( 1.f, 0.5f );
    }

    m_menuOpacity.update< float >( ( m_presented || m_overlayBlurIntensity.get< float >( ) < 0.4f ) ? 1.f : 0.f );
    auto const menu_opacity = m_menuOpacity.get< float >( );

    if ( menu_opacity < 0.001f )
        return;

    SetNextWindowSize( m_windowSize );
    SetNextWindowPos( io.DisplaySize / 2 - m_windowSize / 2, ImGuiCond_Once );

    PushStyle opacity( ImGuiStyleVar_Alpha, menu_opacity );

    Begin( CS_XOR("interlope"), nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBringToFrontOnFocus );
    m_window = GetCurrentWindow( );

    m_allowEdits = !IsWindowHovered( ) && !m_window->Rect( ).Contains( GetMousePos( ) );

    BeginChild( "##blur_bg", GetWindowSize( ), 0, ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBackground );
    if ( CThemes::current.name == "Liquid Glass" )
        g_blur.applyBlur( m_window->Rect( ), m_window->DrawList, m_window->WindowRounding, 4.0f, menu_opacity, false );
    EndChild( );

    // const //

    int const sidebar_width = 180;

    // transitions //

    m_transition.alpha.update( m_transition.active ? 0.f : 1.f );

    if ( m_transition.active && m_transition.alpha.get< float >( ) < 0.01f )
    {
        if ( m_transition.apply )
            m_transition.apply( );

        m_transition.active = false;
        m_transition.target = TransitionTarget::None;
    }

    // start //
    {
        m_window->DrawList->PushClipRectFullScreen( );
        ImVec2 shadow_offset = ImVec2( ImCos( IM_PI * 0.25f ), ImSin( IM_PI * 0.25f ) ) * 0;
        // m_window->DrawList->AddShadowRect( m_window->Pos + ImVec2( sidebar_width, 0 ), m_window->Pos + m_windowSize, Color( CThemes::current.colors.window.overlayShadow ).modulate( ), 48, shadow_offset, 0, 64 );
        m_window->DrawList->PopClipRect( );
    }

    // m_window->DrawList->AddRectFilled( m_window->Pos + ImVec2( sidebar_width, 0 ), m_window->Pos + m_windowSize, Color( 20, 20, 20, 100 ).modulate( ), style.WindowRounding );
    m_window->DrawList->AddRect( m_window->Pos + ImVec2( sidebar_width, 0 ), m_window->Pos + m_windowSize, Color( CThemes::current.colors.window.overlayOutline ).modulate( ), style.WindowRounding );

    // m_window->DrawList->AddLine( m_window->Pos + ImVec2( sidebar_width, 0 ), m_window->Pos + ImVec2( sidebar_width, m_windowSize.y ), Color( 30, 30, 30 ).modulate( ), 1 );

    // CUIElements::applyLiquidGlass( [ & ]( ImDrawList* draw ) -> void {
    //     draw->AddRect( m_window->Rect( ).Min, m_window->Rect( ).Max, Color( CThemes::current.colors.border ).modulate( menu_opacity ), style.WindowRounding );
    // },
    //                   m_window->DrawList, m_window->Rect( ), Color( CThemes::current.colors.window.background ).u32( ), Color( CThemes::current.colors.border ).u32( ) );

    // sidebar //

    SetCursorPos( { 0, 0 } );
    BeginChild( "##title", { sidebar_width, 80 }, 0 );
    {
        ImRect const area = GetCurrentWindow( )->Rect( );
        ImVec2 const image_size = { 80, 80 };

        if ( zhironium::c::get< bool >( zhironium::ctx->config.uiEnableGlowLogo ) )
        {
            GetWindowDrawList( )->PushClipRect( m_window->Rect( ).Min, m_window->Rect( ).Max, false );
            // GetWindowDrawList( )->AddShadowCircle( area.GetCenter( ), 4, Color( CThemes::current.colors.accent ).modulate( 200.f / 255.f * GetStyle( ).Alpha ), 240, { 0, 0 }, 0, 100 );
            GetWindowDrawList( )->PopClipRect( );
        }

        PushFont( zhironium::ctx->kallcode->fonts->get( "monospace" ).ptr );
        SetWindowFontScale( 1.5f );
        ImVec2 text_sz = CalcTextSize( CS_XOR("Interlope") );

        int vert_start_idx = GetWindowDrawList( )->VtxBuffer.Size;
        GetWindowDrawList( )->AddText( area.GetCenter( ) - text_sz / 2 + ImVec2( 0, 5 ), Color( CThemes::current.colors.text ).modulate( ), CS_XOR("Interlope") );
        int vert_end_idx = GetWindowDrawList( )->VtxBuffer.Size;

        SetWindowFontScale( 1.0f );
        PopFont( );

        ShadeVertsLinearColorGradientKeepAlpha(
            GetWindowDrawList( ),
            vert_start_idx,
            vert_end_idx,
            area.GetCenter( ) - ImVec2( text_sz.x / 2, 0 ),
            area.GetCenter( ) + ImVec2( text_sz.x / 2, 0 ),
            ImColor( CThemes::current.colors.text ),
            Color( CThemes::current.colors.accent ).u32( ) );

        EndChild( );
    }

    // tabs //

    SetCursorPos( { 0, 80 } );
    BeginChild( "##tabs", { sidebar_width, m_windowSize.y - 160 }, 0 );
    {
        PushStyleVar( ImGuiStyleVar_ItemSpacing, ImVec2 { 0, 5 } );

        for ( int it { 0 }; it < m_tabs.size( ); ++it )
        {
            auto& tab = m_tabs[ it ];

            switch ( tab.type )
            {
            case TabType::Category:
                if ( it != 0 ) // skip separator before first group
                {
                    Dummy( { 0, 3 } );
                    auto* dl = GetWindowDrawList( );
                    auto  p  = GetCursorScreenPos( );
                    dl->AddLine(
                        { p.x + 16, p.y },
                        { p.x + sidebar_width - 16, p.y },
                        IM_COL32( 60, 60, 65, 180 ), 1.0f );
                    Dummy( { 0, 4 } );
                }
                break;
            case TabType::Tab:
                if ( renderTab( &tab, it == m_pendingTab, sidebar_width ) )
                {
                    m_transition = {
                        .alpha = 1.f,
                        .active = true,
                        .target = TransitionTarget::Tab,
                        .apply = [ this, it, tab ]( ) {
                            m_selectedTab = it;
                            m_callback = tab.callback;
                        } };

                    m_settings.presented = false;
                    m_pendingTab = it;
                    m_selectedSubTab = 0;
                }
                break;
            default:
                break;
            }
        }

        PopStyleVar( );

        EndChild( );
    }

    // user profile
    SetCursorPos( { 0, m_windowSize.y - 80 } );
    BeginChild( "##user_profile", { sidebar_width, 80 }, 0 );
    {
        ImRect const area = GetCurrentWindow( )->Rect( );
        ImVec2 const padding = { 10 * 1.0f, 10 * 1.0f };
        ImRect const box = { area.Min + padding, area.Max - padding };
        GetWindowDrawList( )->AddRectFilled( box.Min, box.Max, Color( CThemes::current.colors.elem.backgroundOverlay ).modulate( ), 8 * 1.0f );
        
        ImVec2 avatar_center = { box.Min.x + 24 * 1.0f, box.GetCenter().y };
        
        if (configs::g_userAvatarReady && !configs::g_userAvatarTexture) {
            int w, h;
            zhironium::ctx->graphics->loadTextureFromMemory(configs::g_userAvatarBuffer.data(), configs::g_userAvatarBuffer.size(), (ID3D11ShaderResourceView**)&configs::g_userAvatarTexture, &w, &h);
            configs::g_userAvatarReady = false; // Prevent reloading
        }

        if (configs::g_userAvatarTexture) {
            GetWindowDrawList()->AddImageRounded((ImTextureID)configs::g_userAvatarTexture, avatar_center - ImVec2(16 * 1.0f, 16 * 1.0f), avatar_center + ImVec2(16 * 1.0f, 16 * 1.0f), ImVec2(0,0), ImVec2(1,1), ImColor(255,255,255,255), 16 * 1.0f);
        } else {
            GetWindowDrawList( )->AddCircleFilled( avatar_center, 16 * 1.0f, Color( CThemes::current.colors.accent ).modulate( ) );
            std::string avatar_letter = configs::g_userName.empty() ? "?" : std::string(1, toupper(configs::g_userName[0]));
            ImVec2 letter_size = CalcTextSize(avatar_letter.c_str());
            GetWindowDrawList( )->AddText( avatar_center - ImVec2( letter_size.x / 2.0f, letter_size.y / 2.0f ), Color( CThemes::current.colors.text ).modulate( ), avatar_letter.c_str() );
        }
        
        ImVec2 text_pos = { box.Min.x + 48 * 1.0f, box.Min.y + 12 * 1.0f };
        GetWindowDrawList( )->AddText( text_pos, Color( CThemes::current.colors.text ).modulate( ), configs::g_userName.c_str(), NULL );
        GetWindowDrawList( )->AddText( text_pos + ImVec2( 0, 16 * 1.0f ), Color( CThemes::current.colors.textDim ).modulate( ), configs::g_userSub.c_str(), NULL );
        
        // Handle click to open feature settings or profile settings
        bool hovered, held;
        bool pressed = ButtonBehavior( box, GetID("##profile_btn"), &hovered, &held );
        if ( pressed ) {
            // Can open a specific tab or popup here
        }
    }
    EndChild( );

    // top area //

    PushStyleVar( ImGuiStyleVar_WindowPadding, { 10, 10 } );

    SetCursorPos( { sidebar_width + 1.0f, 1.0f } );
    BeginChild( "##top_area", { GetContentRegionAvail( ).x, 48 }, 0, 0 );
    {
        saveButton( { 70, GetContentRegionAvail( ).y }, [] {
            std::string cur_cfg = kallcode::tabs::get_selected_config();
            if (!cur_cfg.empty()) {
                if (!configs::save_config(cur_cfg.c_str())) {
                    zhironium::ctx->kallcode->alerts->create( "Error", { 260 * 1.0f, 200 * 1.0f }, []( Alert& alert ) {
                        using namespace ImGui;
                        PushStyleColor( ImGuiCol_Text, ImColor( CThemes::current.colors.textDim ).Value );
                        CAlerts::renderContents( GetCursorScreenPos( ) + ImVec2( 5 * 1.0f, 0 ), configs::last_error(), nullptr, GetWindowSize( ).x - 10 * 1.0f );
                        PopStyleColor( );
                        SetCursorPosY( GetWindowSize( ).y - 44 * 1.0f );
                        if ( CAlerts::button( "OK", { 240 * 1.0f, 44 * 1.0f }, true ) )
                            alert.close( );
                    } );
                }
            } else {
                zhironium::ctx->kallcode->alerts->create( "Error", { 260 * 1.0f, 200 * 1.0f }, []( Alert& alert ) {
                    using namespace ImGui;
                    PushStyleColor( ImGuiCol_Text, ImColor( CThemes::current.colors.textDim ).Value );
                    CAlerts::renderContents( GetCursorScreenPos( ) + ImVec2( 5 * 1.0f, 0 ), "Please select a config to save.", nullptr, GetWindowSize( ).x - 10 * 1.0f );
                    PopStyleColor( );
                    SetCursorPosY( GetWindowSize( ).y - 44 * 1.0f );
                    if ( CAlerts::button( "OK", { 240 * 1.0f, 44 * 1.0f }, true ) )
                        alert.close( );
                } );
            }
        } );

        SameLine( 0, 10 );

        PushStyleVar( ImGuiStyleVar_Alpha, m_subTabsAreaOpacity.get< float >( ) * menu_opacity );

        for ( int it { 0 }; it < m_tabs[ m_selectedTab ].subTabs.value_or( std::vector< SubTab > { } ).size( ); it++ )
        {
            auto& subtab = m_tabs[ m_selectedTab ].subTabs.value( )[ it ];

            if ( renderSubTab( &subtab, it == m_pendingSubTab, it ) )
            {
                m_transition = {
                    .alpha = 1.f,
                    .active = true,
                    .target = TransitionTarget::SubTab,
                    .apply = [ this, it, subtab ]( ) {
                        m_selectedSubTab = it;
                        m_callback = subtab.callback;
                    } };

                m_pendingSubTab = it;
            }

            SameLine( 0, 0 );
        }

        PopStyleVar( );

        SetCursorPos( { GetWindowSize( ).x - 28 - 10 - 28 - 10, 10 } );

        {
            static CAnimator search_btn { ImVec4( 0, 0, 0, 0 ) };
            auto const cur = GetCursorScreenPos( );
            auto const size = ImVec2( 28, 28 );
            if ( InvisibleButton( "##SEARCH_BTN", size ) )
                search_presented = true;

            auto const hovered = IsItemHovered( );
            ImRect const rect = { cur, cur + size };
            search_btn.update< ImVec4 >( hovered ? ImColor( CThemes::current.colors.text ) : ImColor( CThemes::current.colors.textDim ) );
            ImGui::SetWindowFontScale( 1.3f );
            GetWindowDrawList( )->AddText( rect.GetCenter( ) - CalcTextSize( ICON_FA_MAGNIFYING_GLASS ) / 2 - ImVec2(0, 2), Color( search_btn.get< ImVec4 >( ) ).modulate( ), ICON_FA_MAGNIFYING_GLASS );
            ImGui::SetWindowFontScale( 1.0f );
        }

        SetCursorPos( { GetWindowSize( ).x - 28 - 10, 10 } );

        {
            static CAnimator gear { ImVec4( 0, 0, 0, 0 ) };

            auto const cur = GetCursorScreenPos( );
            auto const size = ImVec2( 28, 28 );
            if ( InvisibleButton( "##SETTINGS", size ) )
                m_settings.presented = true;

            auto const hovered = IsItemHovered( );

            ImRect const rect = {
                cur, cur + size };

            gear.update< ImVec4 >( hovered ? ImColor( CThemes::current.colors.text ) : ImColor( CThemes::current.colors.textDim ) );

            ImGui::SetWindowFontScale( 1.3f );
            GetWindowDrawList( )->AddText( rect.GetCenter( ) - CalcTextSize( ICON_FA_GEAR ) / 2 - ImVec2(0, 2), Color( gear.get< ImVec4 >( ) ).modulate( ), ICON_FA_GEAR );
            ImGui::SetWindowFontScale( 1.0f );
        }

        EndChild( );
    }

    m_window->DrawList->AddLine( { m_window->Pos.x + sidebar_width, m_window->Pos.y + 50.0f }, { m_window->Pos.x + m_window->Size.x, m_window->Pos.y + 50.0f }, Color( CThemes::current.colors.border ).modulate( ) );

    PopStyleVar( );

    // main area //

    SetCursorPos( { sidebar_width + 1.0f, 51.0f + 30 * ( 1.0f - m_mainAreaOpacity.get< float >( ) ) } );

    PushStyleVar( ImGuiStyleVar_Alpha, m_mainAreaOpacity.get< float >( ) * menu_opacity );

    if ( zhironium::c::get< bool >( zhironium::ctx->config.uiEnableGlowMain ) )
    {
        GetWindowDrawList( )->PushClipRect( m_window->Rect( ).Min, m_window->Rect( ).Max, false );
        // GetWindowDrawList( )->AddShadowCircle( { m_window->Pos.x + m_windowSize.x / 2 + 80, m_window->Pos.y + 10 }, 4, Color( CThemes::current.colors.accent ).modulate( 80.f / 255.f * GetStyle( ).Alpha ), 666, { 0, 0 }, 0, 100 );
        GetWindowDrawList( )->PopClipRect( );
    }

    BeginChild( "##main_area", GetContentRegionAvail( ), 0 );
    {
        PushStyleVar( ImGuiStyleVar_WindowPadding, { 0, 0 } );

        if ( m_selectedTab == kConfigsTab || m_selectedTab == kSkinsTab )
        {
            SetCursorPos( { 10, 10 } );
            
            int childFlags = ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_AlwaysAutoResize;
            float childHeight = 0;
            if (m_selectedTab == kSkinsTab) {
                childFlags = 0;
                childHeight = GetContentRegionAvail().y - 10;
            }

            BeginChild( "##center", { GetContentRegionAvail( ).x - 10, childHeight }, childFlags, ImGuiWindowFlags_NoScrollbar | 0 );
            {
                if ( m_callback )
                    m_callback( 0 );

                EndChild( );
            }
        }
        else
        {
            SetCursorPos( { 10, 10 } );

            BeginChild( "##left", { GetContentRegionAvail( ).x / 2 - 10, 0 }, ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_AlwaysAutoResize, ImGuiWindowFlags_NoScrollbar | 0 );
            {
                if ( m_callback )
                    m_callback( 1 );
                EndChild( );
            }

            SameLine( 0, 10 );

            BeginChild( "##right", { GetContentRegionAvail( ).x - 10, 0 }, ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_AlwaysAutoResize, ImGuiWindowFlags_NoScrollbar | 0 );
            {
                if ( m_callback )
                    m_callback( 2 );
                EndChild( );
            }
        }

        PopStyleVar( );

        ItemSize( { 0, 10 } );

        if ( auto const blur_value = 1.f - m_mainAreaInnerBlur.get< float >( ); blur_value > 0.01f )
        {
            SetCursorPos( { 0, 0 } );
            BeginChild( "##inner_blur_overlay", GetWindowSize( ), 0, ImGuiWindowFlags_NoInputs );
            {
                PushStyleVar( ImGuiStyleVar_Alpha, 1 );

                if ( CThemes::current.name == "Liquid Glass" )
                    g_blur.applyBlur( GetCurrentWindow( )->Rect( ), GetWindowDrawList( ), style.WindowRounding, 1.f, blur_value, false );

                PopStyleVar( );

                EndChild( );
            }
        }

        EndChild( );
    }

    PopStyleVar( );

 
    /*
    ImVec2 banner_size = ImVec2(m_windowSize.x, 30.0f);
    ImVec2 banner_pos = m_window->Pos + ImVec2(0.0f, -banner_size.y - 10.0f);

    m_window->DrawList->PushClipRectFullScreen();
    m_window->DrawList->AddRectFilled(banner_pos, banner_pos + banner_size, Color(230, 60, 65, 255).modulate(menu_opacity), 6.0f);

    const char* warning_text = "Our cheat is safe. However, we recommend being more careful when playing, as we cannot predict how VAC will work.";
    
    ImFont* font = ImGui::GetFont();
    float font_size = ImGui::GetFontSize();
    ImVec2 text_sz = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, warning_text);
    ImVec2 text_pos = banner_pos + ImVec2((banner_size.x - text_sz.x) / 2.0f, (banner_size.y - text_sz.y) / 2.0f);
    
    m_window->DrawList->AddText(font, font_size, text_pos, Color(255, 255, 255, 255).modulate(menu_opacity), warning_text, NULL, 0.0f);
    m_window->DrawList->PopClipRect();
    */

    // end //

    m_settings.render( [ this ] {
        m_settings.presented = false;
    } );

    // search overlay //
    static CAnimator search_anim { 0.f };
    
    search_anim.update< float >( search_presented ? 1.f : 0.f );

    if ( search_anim.get< float >( ) > 0.001f )
    {
        auto const alpha = search_anim.get< float >( ) * GetStyle( ).Alpha;

        {
            SetCursorPos( { 180, 0 } );
            BeginChild( "##search_blur", GetWindowSize( ), 0 );

            GetWindowDrawList( )->AddRectFilled( m_window->Rect().Min + ImVec2( 180, 0 ), m_window->Rect().Max, Color( CThemes::current.colors.window.settingsOverlay ).modulate( alpha ), m_window->WindowRounding );
            EndChild( );
        }

        PushStyleVar( ImGuiStyleVar_Alpha, alpha );

        SetCursorPos( { 180, 0 } );

        BeginChild( "##search", { GetContentRegionAvail( ).x, m_window->Size.y }, 0 );
        {
            SetCursorPos( { GetWindowSize( ).x - 28 - 10, 10 } );

            {
                static CAnimator back_btn { ImVec4( 0, 0, 0, 0 ) };

                auto const cur = GetCursorScreenPos( );
                auto const size = ImVec2( 28, 28 );
                if ( InvisibleButton( "##BACK_SEARCH", size ) )
                    search_presented = false;

                auto const hovered = IsItemHovered( );

                ImRect const rect = { cur, cur + size };

                back_btn.update< ImVec4 >( hovered ? ImColor( CThemes::current.colors.text ) : ImColor( CThemes::current.colors.textDim ) );

                ImGui::SetWindowFontScale( 1.3f );
                GetWindowDrawList( )->AddText( rect.GetCenter( ) - CalcTextSize( ICON_FA_ANGLE_LEFT ) / 2 - ImVec2(0, 2), Color( back_btn.get< ImVec4 >( ) ).modulate( ), ICON_FA_ANGLE_LEFT );
                ImGui::SetWindowFontScale( 1.0f );
            }

            SetCursorPos( { 0, 48 } );

            PushStyleVar( ImGuiStyleVar_WindowPadding, { 10, 10 } );

            BeginChild( "##search_area", GetContentRegionAvail( ), 0, 0 );
            {
                float panel_w = GetWindowSize( ).x;
                ImVec2 ts = CalcTextSize("SEARCH");
                SetCursorPosX((panel_w - ts.x) / 2.0f);
                CUIElements::text( "SEARCH" );

                static char tabFilter[64] = "";
                float input_w = 350.0f;
                SetCursorPosX((panel_w - input_w) / 2.0f);
                ImGui::SetNextItemWidth(input_w);
                
                ImGui::PushStyleColor(ImGuiCol_FrameBg, ImColor(15, 15, 15, 100).Value);
                ImGui::PushStyleColor(ImGuiCol_Border, ImColor(30, 30, 30, 255).Value);
                ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
                
                ImGui::InputTextWithHint("##tab_filter_overlay", "Type to search...", tabFilter, sizeof(tabFilter));
                
                ImGui::PopStyleVar(2);
                ImGui::PopStyleColor(2);
                ImGui::Dummy(ImVec2(0, 5));

                std::string filterStr = tabFilter;
                std::transform(filterStr.begin(), filterStr.end(), filterStr.begin(), [](unsigned char c){ return std::tolower(c); });

                if (!filterStr.empty()) {
                    for ( int it { 0 }; it < m_tabs.size( ); ++it )
                    {
                        auto& tab = m_tabs[ it ];
                        if (tab.type == TabType::Category) continue;

                        std::string tName = tab.name;
                        std::transform(tName.begin(), tName.end(), tName.begin(), [](unsigned char c){ return std::tolower(c); });

                        std::string matched_keyword = "";
                        bool matches = tName.find(filterStr) != std::string::npos;
                        if (!matches) {
                            for (const auto& kw : tab.keywords) {
                                if (kw.find(filterStr) != std::string::npos) {
                                    matches = true;
                                    matched_keyword = kw;
                                    break;
                                }
                            }
                        }
                        
                        int matching_subtab = -1;
                        if (!matches && tab.subTabs.has_value()) {
                            for (int sit = 0; sit < tab.subTabs.value().size(); ++sit) {
                                auto& st = tab.subTabs.value()[sit];
                                std::string stName = st.name;
                                std::transform(stName.begin(), stName.end(), stName.begin(), [](unsigned char c){ return std::tolower(c); });
                                if (stName.find(filterStr) != std::string::npos) {
                                    matches = true;
                                    matching_subtab = sit;
                                    break;
                                }
                                for (const auto& kw : st.keywords) {
                                    if (kw.find(filterStr) != std::string::npos) {
                                        matches = true;
                                        matching_subtab = sit;
                                        matched_keyword = kw;
                                        break;
                                    }
                                }
                                if (matches) break;
                            }
                        }

                        if (matches) {
                            std::string btnLabel = tab.icon.value_or("") + " " + tab.name;
                            if (matching_subtab != -1) {
                                btnLabel += " -> " + tab.subTabs.value()[matching_subtab].name;
                            }
                            if (!matched_keyword.empty()) {
                                std::string display_kw = matched_keyword;
                                bool cap = true;
                                for (char& c : display_kw) {
                                    if (std::isalpha(c) && cap) { c = std::toupper(c); cap = false; }
                                    else if (std::isspace(c)) { cap = true; }
                                }
                                btnLabel += " -> " + display_kw;
                            }
                            
                            if (CUIElements::button(ElemType::Single, btnLabel.c_str())) {
                                m_transition = {
                                    .alpha = 1.f,
                                    .active = true,
                                    .target = TransitionTarget::Tab,
                                    .apply = [ this, it, matching_subtab ]( ) {
                                        m_selectedTab = it;
                                        if (matching_subtab != -1) {
                                            m_callback = m_tabs[it].subTabs.value()[matching_subtab].callback;
                                        } else {
                                            m_callback = m_tabs[it].callback;
                                        }
                                    } };

                                m_pendingTab = it;
                                m_pendingSubTab = matching_subtab == -1 ? 0 : matching_subtab;
                                search_presented = false;
                                tabFilter[0] = '\0';
                            }
                        }
                    }
                }

                EndChild( );
            }
            PopStyleVar( );
            EndChild( );
        }
        PopStyleVar( );
    }

    applyBlurOverlay( m_window );

    End( );
}

bool& CUserInterface::isPresented( )
{
    return m_presented;
}

