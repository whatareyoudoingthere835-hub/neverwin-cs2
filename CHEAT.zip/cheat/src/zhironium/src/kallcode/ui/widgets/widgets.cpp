#define IMGUI_DEFINE_MATH_OPERATORS
//
// Created by kallcode on 16/06/2026.
//

#include "widgets.hpp"

#include "core.hpp"
#include "animator/animator.hpp"
#include "ui/ui.hpp"

#include "watermark/watermark.hpp"
#include "keybinds/keybinds.hpp"
// removed hit_logs

using kallcode::CBaseWidget;
using kallcode::CWidgets;

void CBaseWidget::renderSelectionOutline( const ImRect& rect, float alpha, float rounding )
{
    auto* draw = ImGui::GetBackgroundDrawList( );

    draw->AddRect( rect.Min - ImVec2( 3, 3 ), rect.Max + ImVec2( 3, 3 ), Color( 255, 255, 255 ).modulate( alpha ), rounding );
}

CWidgets::CWidgets( )
{
    watermark = std::make_unique< CWatermark >( );
    // hitLogs = std::make_unique< CHitLogs >( );
    keybinds = std::make_unique< CKeybinds >( );
}

CWidgets::~CWidgets( ) = default;

void CWidgets::render( )
{
    auto const presented = zhironium::ctx->kallcode->ui->isPresented( );
    auto const authenticated = zhironium::ctx->kallcode->ui->isAuthenticated( );

    // Hitlogs should ALWAYS be visible, so we don't tie them to the menu presented state.
    // However, we only show demo logs if the menu is open AND the user is logged in.
    // hitLogs->render( true, presented && authenticated );
    watermark->render( presented );

    auto cleanup = []( auto& vec ) {
        std::erase_if( vec, []( auto& bind ) { return bind.removed && bind.alpha.template get< float >( ) < 0.001f; } );
    };
    cleanup( zhironium::ctx->config.espRectBinds );
    cleanup( zhironium::ctx->config.teleportBinds );
    cleanup( zhironium::ctx->config.stopBinds );
    cleanup( zhironium::ctx->config.aimbotBinds );
    cleanup( zhironium::ctx->config.triggerbotBinds );
    cleanup( zhironium::ctx->config.autofireBinds );
    for (auto& [key, vec] : zhironium::ctx->config.globalBinds) {
        cleanup(vec);
    }
    for (auto& [key, vec] : zhironium::ctx->config.globalIntBinds) {
        cleanup(vec);
    }
    for (auto& [key, vec] : zhironium::ctx->config.globalBindsFloat) {
        cleanup(vec);
    }
    for (auto& [key, vec] : zhironium::ctx->config.globalBindsInt) {
        cleanup(vec);
    }

    keybinds->render( presented, []( ) -> std::vector< KeyBindEntry > {
        std::vector< KeyBindEntry > result { };

        auto process = [ &result ]( auto& vec ) {
            for ( auto& b : vec )
            {
                std::string display_name = (b.customName[0] != '\0') ? std::string(b.customName) : b.name;
                result.push_back( KeyBindEntry { display_name, std::nullopt, b.target && ( *b.target ) && b.visible, b.removed } );
                zhironium::ctx->kallcode->binder->handleBool( b );
            }
        };

        process( zhironium::ctx->config.espRectBinds );
        process( zhironium::ctx->config.teleportBinds );
        process( zhironium::ctx->config.stopBinds );
        process( zhironium::ctx->config.aimbotBinds );
        process( zhironium::ctx->config.triggerbotBinds );
        process( zhironium::ctx->config.autofireBinds );
        for (auto& [key, vec] : zhironium::ctx->config.globalBinds) {
            process(vec);
        }

        auto processInt = [ &result ]( auto& vec ) {
            for ( auto& b : vec )
            {
                std::string display_name = (b.customName[0] != '\0') ? std::string(b.customName) : b.name;
                result.push_back( KeyBindEntry { display_name, std::make_optional( std::make_pair( *b.target, b.target ) ), b.target && ( *b.target == b.value ) && b.active && b.visible, b.removed } );
                zhironium::ctx->kallcode->binder->handleInt( b );
            }
        };
        for (auto& [key, vec] : zhironium::ctx->config.globalIntBinds) {
            processInt(vec);
        }

        auto process_float = [ &result ]( auto& vec ) {
            for ( auto& b : vec )
            {
                std::string display_name = (b.customName[0] != '\0') ? std::string(b.customName) : b.name;
                result.push_back( KeyBindEntry { display_name, std::nullopt, b.target && b.active && b.visible, b.removed } );
                zhironium::ctx->kallcode->binder->handleFloat( b );
            }
        };

        auto process_int = [ &result ]( auto& vec ) {
            for ( auto& b : vec )
            {
                std::string display_name = (b.customName[0] != '\0') ? std::string(b.customName) : b.name;
                result.push_back( KeyBindEntry { display_name, std::make_pair(b.backup, b.target), b.target && b.active && b.visible, b.removed } );
                zhironium::ctx->kallcode->binder->handleInt( b );
            }
        };

        for (auto& [key, vec] : zhironium::ctx->config.globalBindsFloat) {
            process_float(vec);
        }
        for (auto& [key, vec] : zhironium::ctx->config.globalBindsInt) {
            process_int(vec);
        }

        return result;
    }( ) );
}