#define IMGUI_DEFINE_MATH_OPERATORS
//
// Created by kallcode on 15/06/2026.
//

#include "watermark.hpp"

#include "core.hpp"
#include "../../../../../../core/settings.hpp"
#include "../../../../../../render/configs.h"
#include "../../../../../../features/spotify/spotify.hpp"
#include "../../../../../../core/hooks/hooks.hpp"
#include "../../../../../../../src/base.hpp"

#include "../../../fonts/fonts.hpp"
#include "../../../fonts/include/font_awesome/font_awesome.hpp"

#include "../../../animator/animator.hpp"
#include "../../../blur/blur.hpp"

#include "../../../ui/ui.hpp"
#include "../../../ui/themes/themes.hpp"

#include <algorithm>
#include "../../../ui/popups/popups.hpp"

#include <vector>
#include <chrono>
#include <ctime>
#include <cstdio>
#include <windows.h>
#include <iphlpapi.h>
#pragma comment(lib, "iphlpapi.lib")
#include <fstream>
#include <random>
#include "../../../../../thirdparty/json/json.hpp"
#include "default_quotes.hpp"
using json = nlohmann::json;

using kallcode::CWatermark;

using namespace ImGui;

void CWatermark::render( bool allow )
{
    static CAnimator alpha { 0.f };
    static CAnimator drag_alpha { 0.f };
    static bool is_centered = false;

    alpha.update< float >( enabled ? 1.f : 0.f );
    auto const opacity = alpha.get< float >( );
    if ( opacity < 0.001f )
        return;

    PushStyleVar( ImGuiStyleVar_Alpha, opacity );

    auto const scale = 1.0f;

    PushFont( zhironium::ctx->kallcode->fonts->get( "monospace" ).ptr );

    auto const height = GetFontSize( ) * scale + 20 * scale;
    ImVec2 const logo_size = { height, height };

    struct WatermarkDataItem
    {
        std::string icon;
        std::string info;
        ImColor color;
        float advance { 0 };
        std::function< void( ImDrawList*, const ImVec2& ) > advanceFunc { };
    };

    char time_buf[16] { };
    {
        const std::time_t tt = std::chrono::system_clock::to_time_t( std::chrono::system_clock::now( ) );
        std::tm local_tm { };
#if defined( _WIN32 )
        localtime_s( &local_tm, &tt );
#else
        localtime_r( &tt, &local_tm );
#endif
        std::snprintf( time_buf, sizeof( time_buf ), CS_XOR("%02d:%02d:%02d"), local_tm.tm_hour, local_tm.tm_min, local_tm.tm_sec );
    }

    char fps_buf[16] { };
    std::snprintf( fps_buf, sizeof( fps_buf ), CS_XOR("%.0f FPS"), ImGui::GetIO().Framerate );

    MEMORYSTATUSEX memInfo;
    memInfo.dwLength = sizeof(MEMORYSTATUSEX);
    GlobalMemoryStatusEx(&memInfo);
    DWORDLONG physMemUsed = memInfo.ullTotalPhys - memInfo.ullAvailPhys;
    char ram_buf[32] { };
    std::snprintf( ram_buf, sizeof( ram_buf ), CS_XOR("%llu MB / %llu MB"), physMemUsed / 1024 / 1024, memInfo.ullTotalPhys / 1024 / 1024 );

    std::string wm_name = configs::g_userName.empty() ? std::string(CS_XOR("Interlope")) : configs::g_userName;
    std::vector< WatermarkDataItem > data = {
            { ICON_FA_USER, wm_name, ImColor(CThemes::current.colors.accent) } };

    if ( Settings::watermark_time )
        data.push_back( { ICON_FA_CLOCK, time_buf, ImColor(250, 231, 125) } );
    if ( Settings::watermark_fps ) {
        float fps = ImGui::GetIO().Framerate;
        ImColor fps_color;
        if (fps < 50.0f) fps_color = ImColor(250, 80, 80);
        else if (fps < 100.0f) fps_color = ImColor(250, 200, 80);
        else fps_color = ImColor(150, 250, 150);
        data.push_back( { ICON_FA_DESKTOP, fps_buf, fps_color } );
    }
    
    if ( Settings::watermark_ram ) {
        DWORDLONG physMemMB = physMemUsed / 1024 / 1024;
        ImColor ram_color;
        if (physMemMB < 15500) ram_color = ImColor(150, 250, 150);
        else if (physMemMB < 20000) ram_color = ImColor(250, 200, 80);
        else ram_color = ImColor(250, 80, 80);
        data.push_back( { ICON_FA_MEMORY, ram_buf, ram_color } );
    }

    if ( Settings::watermark_spotify && SPOTIFY::IsPlaying() )
    {
        std::string spotify_text = SPOTIFY::GetCurrentAuthor() + std::string(CS_XOR(" - ")) + SPOTIFY::GetCurrentTrack();
        data.push_back( { ICON_FA_MUSIC, spotify_text, ImColor(30, 215, 96) } );
    }

    if ( Settings::watermark_keypress )
    {
        char kp_buf[32] { };
        std::snprintf( kp_buf, sizeof( kp_buf ), CS_XOR("%d Strokes"), g_KeypressCount );
        data.push_back( { ICON_FA_KEYBOARD, kp_buf, ImColor(200, 150, 250) } );
    }
    if ( Settings::watermark_netspd )
    {
        static DWORD lastTime = 0;
        static DWORDLONG lastIn = 0;
        static DWORDLONG lastOut = 0;
        static float speedIn = 0.0f;
        static float speedOut = 0.0f;

        DWORD currentTime = GetTickCount();
        if (currentTime - lastTime > 1000)
        {
            MIB_IFTABLE* pIfTable = (MIB_IFTABLE*)malloc(sizeof(MIB_IFTABLE));
            ULONG dwSize = sizeof(MIB_IFTABLE);
            if (GetIfTable(pIfTable, &dwSize, FALSE) == ERROR_INSUFFICIENT_BUFFER) {
                free(pIfTable);
                pIfTable = (MIB_IFTABLE*)malloc(dwSize);
            }
            if (GetIfTable(pIfTable, &dwSize, FALSE) == NO_ERROR) {
                DWORDLONG totalIn = 0;
                DWORDLONG totalOut = 0;
                for (DWORD i = 0; i < pIfTable->dwNumEntries; i++) {
                    totalIn += pIfTable->table[i].dwInOctets;
                    totalOut += pIfTable->table[i].dwOutOctets;
                }
                if (lastTime != 0) {
                    speedIn = (totalIn - lastIn) / 1024.0f; // KB/s
                    speedOut = (totalOut - lastOut) / 1024.0f;
                }
                lastIn = totalIn;
                lastOut = totalOut;
            }
            free(pIfTable);
            lastTime = currentTime;
        }

        auto format_speed = [](float speed_kbs) -> std::string {
            char buf[32];
            if (speed_kbs >= 1000.0f) {
                std::snprintf(buf, sizeof(buf), CS_XOR("%.1f MB/s"), speed_kbs / 1024.0f);
            } else {
                std::snprintf(buf, sizeof(buf), CS_XOR("%.1f KB/s"), speed_kbs);
            }
            return std::string(buf);
        };

        char net_buf[64] { };
        std::snprintf( net_buf, sizeof( net_buf ), CS_XOR("D: %s | U: %s"), format_speed(speedIn).c_str(), format_speed(speedOut).c_str() );
        data.push_back( { ICON_FA_WIFI, net_buf, ImColor(100, 200, 250) } );
    }
    if ( Settings::watermark_mood )
    {
        static int currentMoodIdx = -1;
        static time_t lastMoodChange = 0;
        const char* moods[] = { CS_XOR("Happy"), CS_XOR("Chill"), CS_XOR("Focused"), CS_XOR("Tilted"), CS_XOR("Sleepy") };
        
        time_t now = time(NULL);
        if (currentMoodIdx == -1 || difftime(now, lastMoodChange) >= 3600) {
            currentMoodIdx = rand() % 5;
            lastMoodChange = now;
        }
        data.push_back( { ICON_FA_HEART, moods[currentMoodIdx], ImColor(250, 150, 200) } );
    }

    if ( Settings::watermark_quote )
    {
        static std::vector<std::string> allQuotes;
        static std::string fullQuote = CS_XOR("No quotes found");
        static std::string displayQuote = "";
        static bool quoteLoaded = false;
        static DWORD lastQuoteChangeTime = GetTickCount();
        static DWORD lastTypingTime = GetTickCount();
        static int charIndex = 0;
        static bool isDeleting = false;

        // Proper RNG seeded once -> truly random each run (rand() alone repeats the same sequence every launch)
        static std::mt19937 quoteRng{ std::random_device{}() };
        static int lastQuoteIdx = -1;

        // Pick a random quote that is different from the current one (when possible)
        auto pickRandomQuote = [&]() {
            if (allQuotes.empty()) return;
            if (allQuotes.size() == 1) {
                lastQuoteIdx = 0;
                fullQuote = allQuotes[0];
                return;
            }
            std::uniform_int_distribution<int> dist(0, (int)allQuotes.size() - 1);
            int idx;
            do {
                idx = dist(quoteRng);
            } while (idx == lastQuoteIdx);
            lastQuoteIdx = idx;
            fullQuote = allQuotes[idx];
        };

        if (!quoteLoaded) {
            quoteLoaded = true;

            // Ensure directory and file exist
            CreateDirectoryA(CS_XOR("C:\\Interlope"), NULL);
            std::ifstream f(CS_XOR("C:\\Interlope\\quotes.json"));
            if (!f.is_open()) {
                std::ofstream out(CS_XOR("C:\\Interlope\\quotes.json"));
                if (out.is_open()) {
                    out << DEFAULT_QUOTES_JSON;
                    out.close();
                }
                f.open(CS_XOR("C:\\Interlope\\quotes.json")); // re-open for reading
            }

            if (f.is_open()) {
                json j = json::parse(f, nullptr, false);
                if (!j.is_discarded() && j.is_array() && j.size() > 0) {
                    for (auto& item : j) {
                        if (item.is_object() && item.contains("text") && item["text"].is_string()) {
                            allQuotes.push_back(item["text"].get<std::string>());
                        } else if (item.is_string()) {
                            allQuotes.push_back(item.get<std::string>());
                        }
                    }
                    if (!allQuotes.empty()) {
                        pickRandomQuote();
                    }
                }
            }
        }

        DWORD currentTime = GetTickCount();

        // 2 minutes (120000 ms) passed since quote was fully typed? Start deleting.
        if (!isDeleting && charIndex >= fullQuote.length() && (currentTime - lastQuoteChangeTime > 120000)) {
            isDeleting = true;
            lastTypingTime = currentTime;
        }

        // Typing / Deleting animation (~50ms per character)
        if (currentTime - lastTypingTime > 50) {
            lastTypingTime = currentTime;

            if (isDeleting) {
                // Delete one UTF-8 char
                if (!displayQuote.empty()) {
                    while (!displayQuote.empty()) {
                        char c = displayQuote.back();
                        displayQuote.pop_back();
                        if ((c & 0xC0) != 0x80) break; // Reached start of a UTF-8 character
                    }
                } else {
                    // Fully deleted -> pick new random quote and start typing again
                    isDeleting = false;
                    if (!allQuotes.empty()) {
                        pickRandomQuote();
                    }
                    charIndex = 0;
                }
            } else {
                // Type one UTF-8 char
                if (charIndex < fullQuote.length()) {
                    int charLen = 1;
                    char c = fullQuote[charIndex];
                    if ((c & 0xE0) == 0xC0) charLen = 2;
                    else if ((c & 0xF0) == 0xE0) charLen = 3;
                    else if ((c & 0xF8) == 0xF0) charLen = 4;

                    if (charIndex + charLen <= fullQuote.length()) {
                        displayQuote += fullQuote.substr(charIndex, charLen);
                        charIndex += charLen;
                    } else {
                        displayQuote += fullQuote[charIndex];
                        charIndex++;
                    }
                    
                    // Reset the 3-minute timer right after we finish typing the whole quote
                    if (charIndex >= fullQuote.length()) {
                        lastQuoteChangeTime = currentTime;
                    }
                }
            }
        }

        // Add a blinking cursor effect while typing/deleting
        std::string finalDisplay = displayQuote;
        if ((charIndex < fullQuote.length() || isDeleting) && ((currentTime / 500) % 2 == 0)) {
            finalDisplay += "_";
        }

        data.push_back( { ICON_FA_COMMENT, finalDisplay, ImColor(250, 250, 150) } );
    }

    if (data.size() > 5) {
        data.resize(5);
    }

    float full_width { };
    for ( int it = 0; it < data.size( ); it++ )
    {
        auto const& d = data[ it ];
        full_width += CalcTextSize( d.icon.c_str( ) ).x * scale + CalcTextSize( d.info.c_str( ) ).x * scale + 15 * scale + d.advance;
    }

    PushStyleVar( ImGuiStyleVar_WindowPadding, { 0, 0 } );

    SetNextWindowSize( ImVec2( full_width + 10 * scale, height ) );

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground;
    if ( !allow )
        flags |= ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoInputs;

    Begin( "##watermark", nullptr, flags );
    {
        ImRect const rect = {
            GetWindowPos( ),
            GetWindowPos( ) + GetWindowSize( ) };

        auto* draw = GetBackgroundDrawList( );

        bool const hovering = IsWindowHovered( );
        bool const dragging = IsMouseDragging( 0 );

        drag_alpha.update< float >( allow ? ( ( dragging && hovering ) ? 1.0f : ( hovering ? 0.5f : 0.f ) ) : 0.f );

        if ( allow ) {
            if ( IsMouseDragging(0) && IsWindowHovered() ) {
                is_centered = false;
            } else if ( !IsMouseDragging(0) ) {
                ImVec2 pos = GetWindowPos();
                ImVec2 size = GetWindowSize();
                float screen_w = ImGui::GetIO().DisplaySize.x;
                float center_x = screen_w / 2.0f;
                float window_center_x = pos.x + size.x / 2.0f;
                
                if ( std::abs(window_center_x - center_x) < 50.0f ) {
                    is_centered = true;
                }
                
                if ( is_centered ) {
                    SetWindowPos( "##watermark", ImVec2(center_x - size.x / 2.0f, pos.y) );
                }
            }
        }

        renderSelectionOutline( rect, drag_alpha.get< float >( ), 12 * scale );

        if ( CThemes::current.name == "Liquid Glass" )
            g_blur.applyBlur( rect, draw, 10 * scale, 1.f, opacity );

        draw->AddRectFilled( rect.Min, rect.Max, Color( CThemes::current.colors.window.background ).modulate( opacity * 0.9f ), 10 * scale );

        CUIElements::applyLiquidGlass( [ & ]( ImDrawList* draw ) -> void {
            draw->AddRect( rect.Min, rect.Max, Color( CThemes::current.colors.border ).modulate( opacity ), 10 * scale, 0, scale );
        },
                                       draw, { rect.Min, rect.Max }, Color( CThemes::current.colors.window.background ).u32( ), Color( CThemes::current.colors.border ).u32( ) );

        float offset { };
        for ( int it { 0 }; it < data.size( ); it++ )
        {
            auto& cur = data[ it ];

            draw->AddText( { rect.Min.x + 10 * scale + offset, rect.Min.y + 10 * scale }, Color( cur.color.Value ).modulate( opacity ), cur.icon.c_str( ) );

            if ( cur.advanceFunc )
                cur.advanceFunc( draw, { rect.Min.x + 10 * scale + offset + 5 * scale + CalcTextSize( cur.icon.c_str( ) ).x, rect.Min.y + 5 * scale } );

            ImColor text_color = (cur.icon == ICON_FA_DESKTOP || cur.icon == ICON_FA_MEMORY) ? cur.color : ImColor(CThemes::current.colors.text);
            draw->AddText( { rect.Min.x + 10 * scale + offset + 5 * scale + CalcTextSize( cur.icon.c_str( ) ).x + cur.advance, rect.Min.y + 10 * scale }, Color( text_color.Value ).modulate( opacity ), cur.info.c_str( ) );

            offset += CalcTextSize( cur.icon.c_str( ) ).x + CalcTextSize( cur.info.c_str( ) ).x + 15 * scale + cur.advance;
        }
    }
    
    ImVec2 saved_wm_pos = GetWindowPos();
    ImVec2 saved_wm_size = GetWindowSize();
    bool is_wm_hovered = IsWindowHovered();
    End( );

    static kallcode::CPopup wm_wg( 230, "Watermark", std::nullopt );
    if ( IsMouseClicked(ImGuiMouseButton_Right) && is_wm_hovered && wm_wg.allowOpen( ) )
    {
        ImVec2 expected_size = ImVec2(230, 330);
        ImVec2 pos = GetMousePos();
        
        pos.y -= expected_size.y;
        if (pos.y < 0) pos.y = GetMousePos().y;
        
        wm_wg.setPosition( pos );
        wm_wg.opened = true;
    }

    if ( wm_wg.begin( ) )
    {
        int active_widgets = 0;
        if (Settings::watermark_time) active_widgets++;
        if (Settings::watermark_fps) active_widgets++;
        if (Settings::watermark_ram) active_widgets++;
        if (Settings::watermark_spotify) active_widgets++;
        if (Settings::watermark_netspd) active_widgets++;
        if (Settings::watermark_quote) active_widgets++;
        if (Settings::watermark_mood) active_widgets++;
        if (Settings::watermark_keypress) active_widgets++;

        bool can_enable = active_widgets < 4;

        auto toggle_widget = [&](const char* label, bool* v) {
            if (!*v && !can_enable) {
                ImGui::BeginDisabled();
                kallcode::PopupEntries::toggle( std::nullopt, label, v );
                ImGui::EndDisabled();
            } else {
                kallcode::PopupEntries::toggle( std::nullopt, label, v );
            }
        };

        toggle_widget("Show Time", &Settings::watermark_time);
        toggle_widget("Show FPS", &Settings::watermark_fps);
        toggle_widget("Show RAM", &Settings::watermark_ram);
        toggle_widget("Show Spotify", &Settings::watermark_spotify);
        toggle_widget("Show Network Speed", &Settings::watermark_netspd);
        toggle_widget("Show Quote", &Settings::watermark_quote);
        toggle_widget("Show Mood", &Settings::watermark_mood);
        toggle_widget("Show Keypress", &Settings::watermark_keypress);
        
        kallcode::PopupEntries::separator( );
            
            static int wm_pos = 0;
            if ( CUIElements::combo( ElemType::Single, "Position", &wm_pos, { "Top Left", "Top Center", "Top Right", "Bottom Left", "Bottom Center", "Bottom Right" } ) )
            {
                float sx = ImGui::GetIO().DisplaySize.x;
                float sy = ImGui::GetIO().DisplaySize.y;
                float wx = full_width + 10 * scale;
                float wy = height;
                
                if ( wm_pos == 0 ) { is_centered = false; SetWindowPos( "##watermark", ImVec2( 10, 10 ) ); }
                else if ( wm_pos == 1 ) { is_centered = true; SetWindowPos( "##watermark", ImVec2( sx / 2.f - wx / 2.f, 10 ) ); }
                else if ( wm_pos == 2 ) { is_centered = false; SetWindowPos( "##watermark", ImVec2( sx - wx - 10, 10 ) ); }
                else if ( wm_pos == 3 ) { is_centered = false; SetWindowPos( "##watermark", ImVec2( 10, sy - wy - 10 ) ); }
                else if ( wm_pos == 4 ) { is_centered = true; SetWindowPos( "##watermark", ImVec2( sx / 2.f - wx / 2.f, sy - wy - 10 ) ); }
                else if ( wm_pos == 5 ) { is_centered = false; SetWindowPos( "##watermark", ImVec2( sx - wx - 10, sy - wy - 10 ) ); }
            }
            
            wm_wg.end( );
    }

    PopStyleVar( );

    PopFont( );

    PopStyleVar( );
}