//
// Created by Kai Tears on 23/01/2026.
//

#ifndef ENLIGHTENED_WATERMARK_HPP
#define ENLIGHTENED_WATERMARK_HPP

#include "imgui.h"
#include "imgui_internal.h"
#include "../widgets.hpp"

namespace kallcode
{
    class CWatermark : public CBaseWidget
    {
    public:
        bool enabled = true;

        void render( bool allow );
    };
} // namespace kallcode

#endif // ENLIGHTENED_WATERMARK_HPP
