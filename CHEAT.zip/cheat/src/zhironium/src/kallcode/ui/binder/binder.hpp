//
// Created by Kai Tears on 26/01/2026.
//

#ifndef ENLIGHTENED_BINDER_HPP
#define ENLIGHTENED_BINDER_HPP

#include "imgui.h"
#include "animator/animator.hpp"

namespace kallcode
{
    enum class BindType
    {
        Toggle,
        Hold
    };

    struct BindBool
    {
        BindType type;
        bool* target;
        std::string name;
        char customName[64] = "";

        ImGuiKey key = ImGuiKey_None;

        bool ownsTarget = false;

        bool listening = false;
        bool active = false;
        bool visible = false;

        // ui things
        CAnimator alpha { 0.f };
        bool removed { false };
    };

    struct BindFloat
    {
        BindType type;
        float* target = nullptr;
        std::string name;
        char customName[64] = "";

        float value = 0.f;
        float backup = 0.f;

        ImGuiKey key = ImGuiKey_None;

        bool ownsTarget = false;

        bool listening = false;
        bool active = false;
        bool visible = false;

        float min;
        float max;

        // ui
        CAnimator alpha { 0.f };
        bool removed = false;
    };

    struct BindInt
    {
        BindType type;
        int* target = nullptr;
        std::string name;
        char customName[64] = "";

        int value = 0;
        int backup = 0;

        ImGuiKey key = ImGuiKey_None;

        bool ownsTarget = false;

        bool listening = false;
        bool active = false;
        bool visible = false;

        int min;
        int max;

        // ui
        CAnimator alpha { 0.f };
        bool removed = false;
    };

    class CPopup;

    class CBinder
    {
    public:
        CBinder( );
        ~CBinder( );

        std::unique_ptr<CPopup> bindPopup;
        std::unique_ptr<CPopup> bindSettingsPopup;

        std::string currentBindLabel;
        void* currentBindTarget = nullptr;
        int currentBindType = 0; // 0 = bool, 1 = float, 2 = int
        float currentBindMinF = 0.f, currentBindMaxF = 0.f;
        int currentBindMinI = 0, currentBindMaxI = 0;

        BindBool* activeBoolBind = nullptr;
        BindFloat* activeFloatBind = nullptr;
        BindInt* activeIntBind = nullptr;

        void handleBool( BindBool& bind );
        void handleFloat( BindFloat& b );
        void handleInt( BindInt& b );

        void updateAllBinds();
        void renderActiveBindMenu();
        void openBindMenuBool(const std::string& label, bool* target);
        void openBindMenuFloat(const std::string& label, float* target, float min_val, float max_val);
        void openBindMenuInt(const std::string& label, int* target, int min_val, int max_val);

        void renderFloat( CPopup* binder, CPopup* bind_settings, const std::string& name, BindFloat** active_bind, std::vector< BindFloat >& list, float* value, float min_value, float max_value );
        void renderInt( CPopup* binder, CPopup* bind_settings, const std::string& name, BindInt** active_bind, std::vector< BindInt >& list, int* value, int min_value, int max_value );
        void renderBool( CPopup* binder, CPopup* bind_settings, const std::string& name, BindBool** active_bind, std::vector< BindBool >& list, bool* value );
    };
} // namespace kallcode

#endif // ENLIGHTENED_BINDER_HPP
