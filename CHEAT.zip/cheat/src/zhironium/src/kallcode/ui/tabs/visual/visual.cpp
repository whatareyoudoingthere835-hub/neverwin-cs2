#define IMGUI_DEFINE_MATH_OPERATORS
#include "../tabs.hpp"
#include "../../elem/elem.hpp"
#include "../../popups/popups.hpp"
#include "../../themes/themes.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include "ui/binder/binder.hpp"
#include "fonts/include/font_awesome/font_awesome.hpp"
#include <filesystem>

#include "../../../../../../core/settings.hpp"
#include "../../../../../../base.hpp"
#include "core.hpp"

using namespace ImGui;
using namespace kallcode;


void kallcode::tabs::callVisual( int child )
{
    if ( child == 1 )
    {
        CUIElements::text(CS_XOR("Player ESP"));
        CUIElements::toggle( ElemType::Single, CS_XOR("Enable ESP"), &Settings::esp_enabled );
        
        if (Settings::esp_enabled) {
            CUIElements::toggle( ElemType::Begin, CS_XOR("Bounding Box"), &Settings::esp_box, { &Settings::esp_enemy_col } );
            if (Settings::esp_box) {
                CUIElements::combo( ElemType::Middle, CS_XOR("Box Style"), &Settings::esp_box_style, std::vector<std::string>{ CS_XOR("Corner"), CS_XOR("Outline"), CS_XOR("Coal"), CS_XOR("Filled") } );
            }
            CUIElements::toggle( ElemType::Middle, CS_XOR("Player Name"), &Settings::esp_name );
            CUIElements::toggle( ElemType::Middle, CS_XOR("Health Bar"), &Settings::esp_health );
            if ( Settings::esp_health ) {
                CUIElements::combo( ElemType::Middle, CS_XOR("Health Style"), &Settings::esp_health_style, std::vector<std::string>{ CS_XOR("Gradient"), CS_XOR("Solid Green"), CS_XOR("Box Color") } );
                CUIElements::combo( ElemType::Middle, CS_XOR("Health Pos"), &Settings::esp_health_pos, std::vector<std::string>{ CS_XOR("Left"), CS_XOR("Top"), CS_XOR("Right") } );
            }
            CUIElements::toggle( ElemType::End, CS_XOR("Snaplines"), &Settings::esp_lines, { &Settings::esp_enemy_col } );
            if (Settings::esp_lines) {
                CUIElements::combo( ElemType::Middle, CS_XOR("Line Anchor"), &Settings::esp_line_anchor, std::vector<std::string>{ CS_XOR("Top"), CS_XOR("Center"), CS_XOR("Bottom") } );
            }
        }
    }
    else if ( child == 2 )
    {
        if (Settings::esp_enabled) {
            CUIElements::text(CS_XOR("Player Extra"));
            CUIElements::toggle( ElemType::Begin, CS_XOR("Weapon Text"), &Settings::esp_weapon );
            CUIElements::toggle( ElemType::Middle, CS_XOR("Weapon Icon"), &Settings::esp_weapon_icon );
            CUIElements::toggle( ElemType::Middle, CS_XOR("Ammo Bar"), &Settings::esp_ammo, { &Settings::esp_ammo_col1 } );
            CUIElements::toggle( ElemType::Middle, CS_XOR("Player Flags"), &Settings::esp_flags );
            
            CUIElements::toggle( ElemType::End, CS_XOR("Hitmarker"), &Settings::hitmarker_enabled );
            if (Settings::hitmarker_enabled) {
                PopupEntries::sliderFloat( std::nullopt, CS_XOR("Duration"), &Settings::hitmarker_duration, 0.1f, 2.0f );
                CUIElements::toggle( ElemType::Middle, CS_XOR("Hit Sound"), &Settings::hitsound_enabled );
                if (Settings::hitsound_enabled) {
                    static bool scanned_sounds = false;
                    if (!scanned_sounds) {
                        Settings::hitsound_list.push_back(CS_XOR("SystemAsterisk"));
                        std::string path = CS_XOR("C:\\Interlope\\hitsounds\\");
                        if (std::filesystem::exists(path)) {
                            for (const auto& entry : std::filesystem::directory_iterator(path)) {
                                if (entry.path().extension() == ".wav") {
                                    Settings::hitsound_list.push_back(entry.path().filename().string());
                                }
                            }
                        }
                        scanned_sounds = true;
                    }
                    CUIElements::combo( ElemType::Middle, CS_XOR("Sound File"), &Settings::hitsound_idx, Settings::hitsound_list );
                }
            }
            ImGui::Dummy(ImVec2(0.0f, 10.0f));
        }
        
        CUIElements::text(CS_XOR("Chams"));
        CUIElements::toggle( ElemType::Begin, CS_XOR("Enable Chams"), &Settings::chams_enabled, { &Settings::chams_color } );
        CUIElements::toggle( ElemType::End, CS_XOR("Invisible"), &Settings::chams_invisible, { &Settings::chams_invisible_color } );
    }
}

void kallcode::tabs::callWorld( int child )
{
    if (child == 1)
    {
        CUIElements::text(CS_XOR("World Particles"));
        CUIElements::combo( ElemType::Begin, CS_XOR("Effect"), &Settings::particles_type,
            std::vector<std::string>{ CS_XOR("None"), CS_XOR("Ashes"), CS_XOR("Snow"), CS_XOR("Stars"), CS_XOR("Rain") } );
        if (Settings::particles_type != 0) {
            PopupEntries::sliderFloat( std::nullopt, CS_XOR("Density"), &Settings::particles_density, 0.1f, 5.0f );
        }
    }
}

void kallcode::tabs::callWorldMisc( int child )
{
    if (child == 1)
    {
        CUIElements::text(CS_XOR("Movement"));
        CUIElements::toggle( ElemType::Single, CS_XOR("Bunny Hop"), &Settings::movement_bhop );
    }
}

void kallcode::tabs::callLegitbot( int child )
{
    if ( child == 1 )
    {
        CUIElements::text(CS_XOR("Aim Assist"));
        CUIElements::toggle( ElemType::Begin, CS_XOR("Enable Aimbot"), &Settings::aimbot_enabled );
        PopupEntries::sliderFloat( std::nullopt, CS_XOR("FOV"), &Settings::aimbot_fov, 0.0f, 180.0f );
        PopupEntries::sliderFloat( std::nullopt, CS_XOR("Smooth"), &Settings::aimbot_smooth, 1.0f, 50.0f );
        CUIElements::toggle( ElemType::Middle, CS_XOR("Humanized"), &Settings::aimbot_humanized );
        PopupEntries::sliderFloat( std::nullopt, CS_XOR("Hitchance"), &Settings::aimbot_hitchance, 0.0f, 100.0f );
    }
    else if ( child == 2 )
    {
        CUIElements::text(CS_XOR("Trigger"));
        CUIElements::toggle( ElemType::Begin, CS_XOR("Enable Trigger"), &Settings::trigger_enabled );
        PopupEntries::sliderFloat( std::nullopt, CS_XOR("Trigger FOV"), &Settings::trigger_fov, 0.0f, 10.0f );
        PopupEntries::sliderFloat( std::nullopt, CS_XOR("Hitchance"), &Settings::trigger_hitchance, 0.0f, 100.0f );
        CUIElements::toggle( ElemType::End, CS_XOR("Seeded"), &Settings::trigger_seeded );
    }
}

void kallcode::tabs::callLegitbotTrigger( int child )
{
}

