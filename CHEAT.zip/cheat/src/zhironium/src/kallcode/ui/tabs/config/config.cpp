//
// Created by rei on 1/28/2026.
// Rewritten to use local Interlope config system.
//

#define IMGUI_DEFINE_MATH_OPERATORS

#include "../tabs.hpp"
#include "../../elem/elem.hpp"
#include "animator/animator.hpp"
#include "configs.h"
#include "../../../../core.hpp"

#include <map>
#include <unordered_map>
#include <algorithm>

#undef min
#undef max
#include <random>
#include <cstring>

#include "imgui.h"
#include "imgui_internal.h"
#include "fonts/include/font_awesome/font_awesome.hpp"
#include "ui/themes/themes.hpp"

namespace kallcode::tabs {
    static std::map< int, std::string > cfgList;
    static int selectedConfig = -1;

    std::string get_selected_config() {
        if (selectedConfig >= 0 && cfgList.find(selectedConfig) != cfgList.end()) {
            return cfgList[selectedConfig];
        }
        return "";
    }
}

using namespace ImGui;

void kallcode::tabs::callConfig( int child )
{
    if ( child != 0 )
        return;

    static bool needRefresh = true;
    static char newNameBuf[ 64 ] = {};

    PushStyleVar( ImGuiStyleVar_ItemSpacing, { 0, 10 * 1.0f } );

    struct cfg_anim_t
    {
        CAnimator main { float( 0.f ) };
        bool closing = false;
        bool seen = false;
        bool removed_called = false;
    };

    static std::unordered_map< ImGuiID, cfg_anim_t > cfg_anim;

    if ( needRefresh )
    {
        cfgList.clear( );
        cfg_anim.clear( );
        auto list = configs::list_configs( );
        for ( int i = 0; i < ( int ) list.size( ); ++i )
            cfgList[ i ] = list[ i ];
        if ( !cfgList.empty( ) && ( selectedConfig < 0 || selectedConfig >= ( int ) cfgList.size( ) ) )
            selectedConfig = 0;
        else if ( cfgList.empty( ) )
            selectedConfig = -1;
        needRefresh = false;
    }

    // config manager bar
    [ & ]( ) -> void {
        ImGuiWindow* window = GetCurrentWindow( );
        if ( window->SkipItems )
            return;

        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID label_id = window->GetID( "Config manager" );
        const ImVec2 label_size = CalcTextSize( "Config manager", NULL, true );

        ImVec2 pos = window->DC.CursorPos;
        ImVec2 size = CalcItemSize( { 0, 0 }, GetContentRegionAvail( ).x, 50 * 1.0f );

        const ImRect bb( pos, pos + size );
        ItemSize( size, style.FramePadding.y );
        if ( !ItemAdd( bb, label_id ) )
            return;

        GetWindowDrawList( )->AddRectFilled( bb.Min, bb.Max, Color( CThemes::current.colors.elem.background ).modulate( ), 12 * 1.0f );

        ImVec2 const center_pos = { bb.Min.x + 10 * 1.0f, bb.GetCenter( ).y };

        auto const btn_size = 30 * 1.0f;
        static char cloudKeyBuf[64] = {};

        std::vector< std::pair< std::string, std::function< void( ) > > > inner_buttons = {
            { ICON_FA_ARROWS_ROTATE, [ & ] { needRefresh = true; } },
            { ICON_FA_FOLDER_OPEN, [ & ] { configs::open_config_directory( ); } },
            { ICON_FA_WAND_MAGIC, [ & ] {
                 const static std::string characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                 std::random_device rd;
                 std::mt19937 generator( rd( ) );
                 std::uniform_int_distribution<> distribution( 0, ( int ) characters.size( ) - 1 );
                 std::string random_string;
                 for ( int i = 0; i < 10; ++i )
                     random_string += characters[ distribution( generator ) ];
                 if ( configs::create_config( random_string.c_str( ) ) )
                     needRefresh = true;
             } },
            { ICON_FA_CLOUD_ARROW_DOWN, [ & ] {
                 if (cloudKeyBuf[0] != '\0') {
                     std::string codeStr(cloudKeyBuf);
                     std::string name = "cloud_" + codeStr;
                     if (configs::download_cloud_config(cloudKeyBuf, name.c_str())) {
                         needRefresh = true;
                         cloudKeyBuf[0] = '\0';
                     }
                 }
            } }
        };

        ImVec2 const start = { bb.Max.x - 10 * 1.0f - ( btn_size * inner_buttons.size() ), bb.GetCenter( ).y - btn_size / 2 };

        struct _state
        {
            CAnimator text { ImVec4( 0, 0, 0, 0 ) };
            CAnimator background { ImVec4( 0, 0, 0, 0 ) };
        };

        static std::unordered_map< ImGuiID, _state > __state;

        GetWindowDrawList( )->AddText( center_pos - ImVec2( 0, label_size.y / 2 ), Color( CThemes::current.colors.text ).modulate( ), "Manager" );

        GetWindowDrawList( )->AddRectFilled( start, start + ImVec2( btn_size * inner_buttons.size( ), btn_size ), Color( CThemes::current.colors.elem.backgroundOverlay ).modulate( ), 12 * 1.0f );
        GetWindowDrawList( )->AddRect( start, start + ImVec2( btn_size * inner_buttons.size( ), btn_size ), Color( CThemes::current.colors.elem.backgroundOverlay ).modulate( ), 12 * 1.0f, 0, 1.0f );

        for ( int it { 0 }; it < ( int ) inner_buttons.size( ); it++ )
        {
            auto& btn = inner_buttons[ it ].first;

            ImRect const rect = {
                start + ImVec2( btn_size * it, 0 ), start + ImVec2( btn_size * ( it + 1 ), btn_size ) };

            auto const inner_id = GetID( ( std::to_string( it ) + inner_buttons[ it ].first + "manager" ).c_str( ) );

            ItemAdd( rect, inner_id );

            bool hovered, held;
            bool pressed = ButtonBehavior( rect, inner_id, &hovered, &held, 0 );

            _state& state = __state[ inner_id ];
            state.text.update< ImVec4 >( hovered
                                             ? CThemes::current.colors.text
                                             : CThemes::current.colors.textDim );

            state.background.update< ImVec4 >( hovered ? ImColor( CThemes::current.colors.elem.backgroundOverlay ).Value : Color( CThemes::current.colors.elem.backgroundOverlay ).modulate( 0 ).Value );

            GetWindowDrawList( )->AddText( rect.GetCenter( ) - CalcTextSize( btn.c_str( ) ) / 2,
                                           Color( state.text.get< ImVec4 >( ) ).modulate( ), btn.c_str( ) );

            GetWindowDrawList( )->AddRectFilled( rect.Min, rect.Max, Color( state.background.get< ImVec4 >( ) ).modulate( ), ( it == 0 || it == ( int ) inner_buttons.size( ) - 1 ) ? ( 12 * 1.0f ) : 0, ( it == 0 ) ? ImDrawFlags_RoundCornersLeft : ImDrawFlags_RoundCornersRight );

            if ( it != ( int ) inner_buttons.size( ) - 1 )
                GetWindowDrawList( )->AddLine( { rect.Max.x, rect.Min.y + 5 * 1.0f }, { rect.Max.x, rect.Max.y - 5 * 1.0f }, Color( CThemes::current.colors.elem.backgroundOverlay ).modulate( ), 1.0f );

            if ( pressed )
            {
                state.text.set< ImVec4 >( ImColor( CThemes::current.colors.accent ).Value );
                state.background.set< ImVec4 >( Color( CThemes::current.colors.elem.backgroundOverlay ).modulate( 1.3f * GetStyle( ).Alpha ).Value );
                inner_buttons[ it ].second( );
            }
        }
        
        // Custom config creation input inside the Manager bar
        ImVec2 input_pos = { bb.Min.x + 100 * 1.0f, bb.GetCenter().y - 14 * 1.0f };
        SetCursorScreenPos(input_pos);
        PushItemWidth(160 * 1.0f);
        
        PushStyleVar(ImGuiStyleVar_FrameRounding, 6.0f * 1.0f);
        PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8 * 1.0f, 6 * 1.0f));
        PushStyleColor(ImGuiCol_FrameBg, ImColor(CThemes::current.colors.elem.backgroundOverlay).Value);
        PushStyleColor(ImGuiCol_Text, ImColor(CThemes::current.colors.text).Value);
        PushStyleColor(ImGuiCol_TextDisabled, ImColor(CThemes::current.colors.textDim).Value);
        
        InputTextWithHint("##cfg_name", "Config name...", newNameBuf, sizeof(newNameBuf));
        PopStyleColor(3);
        PopItemWidth();
        
        SameLine(0, 8 * 1.0f);
        
        PushStyleColor(ImGuiCol_Button, ImColor(CThemes::current.colors.elem.backgroundOverlay).Value);
        PushStyleColor(ImGuiCol_ButtonHovered, ImColor(CThemes::current.colors.accent).Value);
        PushStyleColor(ImGuiCol_ButtonActive, ImColor(CThemes::current.colors.accent).Value);
        
        if (Button("Create", ImVec2(70 * 1.0f, 28 * 1.0f))) {
            if (newNameBuf[0] != '\0') {
                if (configs::create_config(newNameBuf)) {
                    needRefresh = true;
                    newNameBuf[0] = '\0';
                }
            }
        }
        
        SameLine(0, 15 * 1.0f);
        
        float available_w = start.x - GetCursorScreenPos().x - 10.0f;
        if (available_w < 40.0f) available_w = 40.0f;
        
        PushItemWidth(available_w);
        InputTextWithHint("##cloud_key", "Key...", cloudKeyBuf, sizeof(cloudKeyBuf));
        PopItemWidth();
        
        PopStyleColor(3);
        PopStyleVar(2);
        
    }( );

    for ( auto& [ id, st ] : cfg_anim )
        st.seen = false;

    auto const width = GetContentRegionAvail( ).x / 2.f - 5.f * 1.0f;

    ImGui::Dummy(ImVec2(0, 5 * 1.0f));

    std::vector< int > to_remove;
    to_remove.reserve( cfgList.size( ) );

    // Rename popup buffer
    static char renameBuf[64] = {};
    static int renamingConfig = -1;

    ImGuiWindow* window = GetCurrentWindow();
    int it = 0;

    for ( auto& cfg : cfgList )
    {
        ImGuiID id = GetID( ( cfg.second + std::to_string( cfg.first ) ).c_str( ) );
        auto& st = cfg_anim[ id ];
        st.seen = true;

        float const target = st.closing ? 0.f : 1.f;
        st.main.update< float >( target );

        if ( st.closing && st.main.get< float >( ) <= 0.01f )
        {
            if ( !st.removed_called )
            {
                st.removed_called = true;
                configs::delete_config( cfg.second.c_str( ) );
            }
            to_remove.push_back( cfg.first );
            continue;
        }

        float const a = st.main.get< float >( );
        PushStyleVar( ImGuiStyleVar_Alpha, GetStyle( ).Alpha * a );

        auto const inner_width = width - 10 * 1.0f;
        auto const height = 80 * 1.0f;

        ImVec2 old_pos = window->DC.CursorPos;

        ImRect const rect = { old_pos + ImVec2( ( it % 2 == 0 ) ? 0 : width + 10 * 1.0f, 0 ), old_pos + ImVec2( width, height * st.main.get< float >( ) ) + ImVec2( ( it % 2 == 0 ) ? 0 : width + 10 * 1.0f, 0 ) };

        ItemSize( rect.GetSize( ) );
        if ( !ItemAdd( rect, id ) )
        {
            PopStyleVar();
            continue;
        }

        GetWindowDrawList( )->AddRectFilled( rect.Min, rect.Max, Color( CThemes::current.colors.elem.background ).modulate( ), 8 * 1.0f );
        if (selectedConfig == cfg.first) {
            GetWindowDrawList( )->AddRectFilled( rect.Min, rect.Max, Color( CThemes::current.colors.elem.backgroundOverlay ).modulate( ), 8 * 1.0f );
        }

        bool hovered, held;
        ImGui::SetNextItemAllowOverlap();
        bool pressed = ButtonBehavior( rect, id, &hovered, &held );

        if ( pressed )
            selectedConfig = cfg.first;

        // name
        GetWindowDrawList( )->AddText( rect.Min + ImVec2( 10 * 1.0f, 10 * 1.0f ), Color( (selectedConfig == cfg.first) ? CThemes::current.colors.accent : CThemes::current.colors.text ).modulate( ), cfg.second.c_str( ) );

        // Cloud buttons below name
        ImVec2 const btn_area = { rect.Min.x + 10 * 1.0f, rect.Min.y + 40 * 1.0f };
        SetCursorScreenPos(btn_area);
        
        PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
        PushStyleColor(ImGuiCol_Button, ImColor(CThemes::current.colors.elem.backgroundOverlay).Value);
        PushStyleColor(ImGuiCol_Text, ImColor(CThemes::current.colors.text).Value);
        
        int i = cfg.first;
        // Rename
        if (renamingConfig == i) {
            PushItemWidth(80 * 1.0f);
            if (InputText("##ren", renameBuf, sizeof(renameBuf), ImGuiInputTextFlags_EnterReturnsTrue)) {
                if (renameBuf[0] != '\0') {
                    // Rename logic (copy and delete)
                    if (configs::load_config(cfg.second.c_str())) {
                        configs::save_config(renameBuf);
                        configs::delete_config(cfg.second.c_str());
                        needRefresh = true;
                    }
                }
                renamingConfig = -1;
            }
            PopItemWidth();
            SameLine();
        } else {
            if (Button((std::string(ICON_FA_PEN) + "##ren" + std::to_string(i)).c_str(), ImVec2(24*1.0f, 24*1.0f))) {
                renamingConfig = i;
                memcpy(renameBuf, cfg.second.c_str(), std::min(sizeof(renameBuf) - 1, cfg.second.length()));
                renameBuf[std::min(sizeof(renameBuf) - 1, cfg.second.length())] = '\0';
            }
            if (IsItemHovered()) SetTooltip("Rename Config");
            SameLine();
        }

        // Bot link
        if (Button((std::string(ICON_FA_LINK) + "##bot" + std::to_string(i)).c_str(), ImVec2(24*1.0f, 24*1.0f))) {
            std::string code = configs::upload_cloud_config(cfg.second.c_str(), configs::g_userId);
            std::string link = "https://t.me/InterlopeBot?start=cfg_" + (code.empty() ? cfg.second : code);
            ImGui::SetClipboardText(link.c_str());
        }
        if (IsItemHovered()) SetTooltip("Copy Bot Link");
        SameLine();

        // Activation key
        if (Button((std::string(ICON_FA_KEY) + "##key" + std::to_string(i)).c_str(), ImVec2(24*1.0f, 24*1.0f))) {
            std::string code = configs::upload_cloud_config(cfg.second.c_str(), configs::g_userId);
            if (!code.empty()) {
                ImGui::SetClipboardText(code.c_str());
            } else {
                ImGui::SetClipboardText(("ACT-" + cfg.second + "-KEY").c_str());
            }
        }
        if (IsItemHovered()) SetTooltip("Copy Cloud Key");
        
        PopStyleColor(2);
        PopStyleVar();

        // Right side buttons
        ImVec2 const right_btn_start = { rect.Max.x - 10 * 1.0f - ( 24 * 1.0f * 3 ) - 5 * 1.0f * 2, rect.GetCenter( ).y - 12 * 1.0f };
        SetCursorScreenPos(right_btn_start);
        
        PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
        PushStyleColor(ImGuiCol_Button, ImColor(CThemes::current.colors.elem.backgroundOverlay).Value);
        PushStyleColor(ImGuiCol_Text, ImColor(CThemes::current.colors.text).Value);

        if (Button((std::string(ICON_FA_FLOPPY_DISK) + "##save" + std::to_string(i)).c_str(), ImVec2(24*1.0f, 24*1.0f))) {
            selectedConfig = cfg.first;
            configs::save_config(cfg.second.c_str());
        }
        SameLine(0, 5 * 1.0f);
        if (Button((std::string(ICON_FA_DOWNLOAD) + "##load" + std::to_string(i)).c_str(), ImVec2(24*1.0f, 24*1.0f))) {
            selectedConfig = cfg.first;
            configs::load_config(cfg.second.c_str());
        }
        SameLine(0, 5 * 1.0f);
        PushStyleColor(ImGuiCol_Text, ImColor(255, 80, 80).Value);
        if (Button((std::string(ICON_FA_TRASH) + "##del" + std::to_string(i)).c_str(), ImVec2(24*1.0f, 24*1.0f))) {
            st.closing = true;
            if ( selectedConfig == cfg.first )
                selectedConfig = -1;
        }
        PopStyleColor();

        PopStyleColor(2);
        PopStyleVar();

        PopStyleVar();

        window->DC.CursorPos = old_pos;

        if ( it % 2 == 1 )
            window->DC.CursorPos.y += height + 10 * 1.0f;
        else if ( it == cfgList.size( ) - 1 )
            window->DC.CursorPos.y += height + 10 * 1.0f;

        it++;
    }




    if ( !to_remove.empty( ) )
    {
        std::sort( to_remove.begin( ), to_remove.end( ) );
        to_remove.erase( std::unique( to_remove.begin( ), to_remove.end( ) ), to_remove.end( ) );
        for ( int i = ( int ) to_remove.size( ) - 1; i >= 0; --i )
        {
            int idx = to_remove[ i ];
            ImGuiID id = GetID( cfgList[ idx ].c_str( ) );
            cfg_anim.erase( id );
            cfgList.erase( idx );
        }
        selectedConfig = -1;
        needRefresh = true;
    }

    {
        std::vector< ImGuiID > garbage;
        garbage.reserve( cfg_anim.size( ) );
        for ( auto& [ id, st ] : cfg_anim )
            if ( !st.seen && st.closing && st.main.get< float >( ) <= 0.01f )
                garbage.push_back( id );
        for ( auto id : garbage )
            cfg_anim.erase( id );
    }

    PopStyleVar( );
}