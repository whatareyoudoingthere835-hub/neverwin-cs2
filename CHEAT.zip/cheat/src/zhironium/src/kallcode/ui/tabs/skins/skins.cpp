#define IMGUI_DEFINE_MATH_OPERATORS
#include "../tabs.hpp"
#include "../../elem/elem.hpp"
#include "../../popups/popups.hpp"
#include "../../themes/themes.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include "ui/binder/binder.hpp"
#include "fonts/include/font_awesome/font_awesome.hpp"

#include "../../../../../../core/settings.hpp"
#include "skins.hpp"
#include "../../ui.hpp"
#include "../../elem/elem.hpp"
#include "../../popups/popups.hpp"
#include "../../../../core.hpp"
#include "../../../../../../features/skinchanger/skindb_local.hpp"
#include "../../../../../../features/skins/skins.hpp"
#include <algorithm>
#include <cctype>

namespace kallcode {
namespace tabs {

using namespace ImGui;

enum class ViewState {
    Weapons,
    Skins,
    Settings
};

static ViewState s_viewState = ViewState::Weapons;
static WeaponsEnum s_selectedWeaponEnum = WeaponsEnum::none;
static SkinInfo_t* s_selectedSkin = nullptr;

static int s_settingsPaint = 0;
static float s_settingsWear = 0.0f;
static int s_settingsSeed = 0;
static int s_settingsStatTrak = -1;
static bool s_settingsOldModel = false;

static char s_searchBuf[128] = "";

static ImColor GetRarityColor(int rarity) {
    switch(rarity) {
        case 1: return ImColor(170, 170, 170, 255); // Common - Grey
        case 2: return ImColor(130, 200, 250, 255); // Uncommon - Light Blue
        case 3: return ImColor(75, 105, 255, 255);  // Rare - Blue
        case 4: return ImColor(136, 71, 255, 255);  // Mythical - Purple
        case 5: return ImColor(211, 44, 230, 255);  // Legendary - Pink
        case 6: return ImColor(235, 75, 75, 255);   // Ancient - Red
        case 7: return ImColor(228, 174, 57, 255);  // Immortal - Gold
        default: return ImColor(150, 150, 150, 255);
    }
}

struct WeaponGroup {
    const char* name;
    std::vector<WeaponsEnum> weapons;
};

static std::vector<WeaponGroup> s_weaponGroups = {
    {"Pistols", { WeaponsEnum::Deagle, WeaponsEnum::Elite, WeaponsEnum::FiveSeven, WeaponsEnum::Glock, WeaponsEnum::p2000, WeaponsEnum::p250, WeaponsEnum::UspS, WeaponsEnum::Revolver, WeaponsEnum::Tec9, WeaponsEnum::Zeus }},
    {"Mid-Tier", { WeaponsEnum::Mac10, WeaponsEnum::Mp7, WeaponsEnum::Mp9, WeaponsEnum::Ump45, WeaponsEnum::P90, WeaponsEnum::Bizon, WeaponsEnum::Nova, WeaponsEnum::Xm1014, WeaponsEnum::Sawedoof, WeaponsEnum::Mag7, WeaponsEnum::M249, WeaponsEnum::Negev }},
    {"Rifles", { WeaponsEnum::Galil, WeaponsEnum::Famas, WeaponsEnum::Ak47, WeaponsEnum::M4A4, WeaponsEnum::M4A1Silencer, WeaponsEnum::Ssg08, WeaponsEnum::Aug, WeaponsEnum::Sg556, WeaponsEnum::Awp, WeaponsEnum::G3Sg1, WeaponsEnum::Scar20 }},
    {"Knives", { WeaponsEnum::Knife }},
    {"Gloves", { WeaponsEnum::Glove }}
};

static float s_notifyAlpha = 0.0f;
static std::string s_notifyText = "";

static const char* GetWeaponName(WeaponsEnum e) {
    switch(e) {
        case WeaponsEnum::Deagle: return "Desert Eagle";
        case WeaponsEnum::Elite: return "Dual Berettas";
        case WeaponsEnum::FiveSeven: return "Five-SeveN";
        case WeaponsEnum::Glock: return "Glock-18";
        case WeaponsEnum::Ak47: return "AK-47";
        case WeaponsEnum::Aug: return "AUG";
        case WeaponsEnum::Awp: return "AWP";
        case WeaponsEnum::Famas: return "FAMAS";
        case WeaponsEnum::G3Sg1: return "G3SG1";
        case WeaponsEnum::Galil: return "Galil AR";
        case WeaponsEnum::M249: return "M249";
        case WeaponsEnum::M4A4: return "M4A4";
        case WeaponsEnum::Mac10: return "MAC-10";
        case WeaponsEnum::P90: return "P90";
        case WeaponsEnum::Ump45: return "UMP-45";
        case WeaponsEnum::Xm1014: return "XM1014";
        case WeaponsEnum::Bizon: return "PP-Bizon";
        case WeaponsEnum::Mag7: return "MAG-7";
        case WeaponsEnum::Negev: return "Negev";
        case WeaponsEnum::Sawedoof: return "Sawed-Off";
        case WeaponsEnum::Tec9: return "Tec-9";
        case WeaponsEnum::p2000: return "P2000";
        case WeaponsEnum::Mp7: return "MP7";
        case WeaponsEnum::Mp9: return "MP9";
        case WeaponsEnum::Nova: return "Nova";
        case WeaponsEnum::p250: return "P250";
        case WeaponsEnum::Scar20: return "SCAR-20";
        case WeaponsEnum::Sg556: return "SG 553";
        case WeaponsEnum::Ssg08: return "SSG 08";
        case WeaponsEnum::M4A1Silencer: return "M4A1-S";
        case WeaponsEnum::UspS: return "USP-S";
        case WeaponsEnum::Cz65A: return "CZ75-Auto";
        case WeaponsEnum::Revolver: return "R8 Revolver";
        case WeaponsEnum::Zeus: return "Zeus x27";
        case WeaponsEnum::Knife: return "Knives";
        case WeaponsEnum::Glove: return "Gloves";
        default: return "Unknown";
    }
}

void kallcode::tabs::callSkins( int child )
{
    if ( !g_SkinDB->IsInitialized() )
    {
        if (child == 0) CUIElements::text( "Loading Skin Database..." );
        return;
    }

    if ( child != 0 ) return; // We only render in the full-width center block

    if (s_notifyAlpha > 0.0f) {
        float alpha = s_notifyAlpha < 1.0f ? s_notifyAlpha : 1.0f;
        ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x - 20.0f, ImGui::GetIO().DisplaySize.y - 20.0f), ImGuiCond_Always, ImVec2(1.0f, 1.0f));
        ImGui::SetNextWindowBgAlpha(0.0f);
        
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(15.0f, 15.0f));

        ImGui::Begin("SkinNotify", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove);
        
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        ImRect wnd_rect = window->Rect();
        
        window->DrawList->AddRectFilled(wnd_rect.Min, wnd_rect.Max, ImColor(20, 20, 20, (int)(alpha * 220)), 10.0f);
        kallcode::CUIElements::applyLiquidGlass( [&]( ImDrawList* draw ) -> void {
            draw->AddRect( wnd_rect.Min, wnd_rect.Max, ImColor( 32, 32, 32, (int)(alpha * 255) ), 10.0f, 0, 1.0f );
        }, window->DrawList, wnd_rect, ImColor( 32, 32, 32 ), ImColor( 255, 255, 255 ) );
        
        ImGui::TextColored(ImColor(255, 255, 255, (int)(alpha * 255)), "Applied ");
        ImGui::SameLine(0, 0);
        ImGui::TextColored(ImColor(150, 255, 150, (int)(alpha * 255)), "%s", s_notifyText.c_str());
        
        ImGui::End();
        ImGui::PopStyleVar(2);
        
        s_notifyAlpha -= ImGui::GetIO().DeltaTime;
    }

    if (s_viewState == ViewState::Weapons)
    {
        ImGui::BeginChild("##weapons_grid", ImGui::GetContentRegionAvail(), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);
        
        float hPad = 8.0f;
        float windowWidth = ImGui::GetContentRegionAvail().x - hPad * 2.0f;
        float minCardW = 140.0f;
        float pad = 10.0f;
        int cols = (int)((windowWidth + pad) / (minCardW + pad));
        if (cols < 1) cols = 1;
        
        float cardW = (windowWidth - (cols - 1) * pad) / cols;
        float cardH = cardW * 0.75f; // keep a good aspect ratio for the card itself

        ImDrawList* draw = ImGui::GetWindowDrawList();
        
        for (const auto& group : s_weaponGroups) {
            ImGui::Text("%s", group.name);
            ImGui::Spacing();
            
            ImVec2 startPos = ImGui::GetCursorScreenPos();
            int i = 0;
            
            for (WeaponsEnum wepEnum : group.weapons) {
                // Find first skin to use as icon
                SkinInfo_t* repSkin = nullptr;
                if (wepEnum == WeaponsEnum::Knife) {
                    for (auto& s : g_SkinDB->GetKnifeSkins()) {
                        if (s.Paint == 0) { repSkin = &s; break; }
                        if (!repSkin) repSkin = &s;
                    }
                } else if (wepEnum == WeaponsEnum::Glove) {
                    for (auto& s : g_SkinDB->GetGloveSkins()) {
                        if (s.Paint == 0) { repSkin = &s; break; }
                        if (!repSkin) repSkin = &s;
                    }
                } else {
                    for (auto& s : g_SkinDB->GetWeaponSkins()) {
                        if (s.weaponType == wepEnum) {
                            if (s.Paint == 0) { repSkin = &s; break; }
                            if (!repSkin) repSkin = &s;
                        }
                    }
                }
                
                if (repSkin) g_SkinDB->RequestTexture(repSkin);

                int row = i / cols;
                int col = i % cols;
                
                ImVec2 p(startPos.x + hPad + col * (cardW + pad), startPos.y + row * (cardH + pad));
                
                ImGui::SetCursorScreenPos(p);
                ImGui::PushID((int)wepEnum);
                bool clicked = ImGui::InvisibleButton("##card", ImVec2(cardW, cardH));
                ImGui::PopID();
                
                bool hovered = ImGui::IsItemHovered();
                if (clicked) {
                    s_selectedWeaponEnum = wepEnum;
                    s_viewState = ViewState::Skins;
                }
                
                ImColor bgCol = hovered ? ImColor(kallcode::CThemes::current.colors.elem.backgroundHovered) : ImColor(kallcode::CThemes::current.colors.elem.background);
                draw->AddRectFilled(p, ImVec2(p.x + cardW, p.y + cardH), bgCol, 8.0f);
                draw->AddRect(p, ImVec2(p.x + cardW, p.y + cardH), ImColor(kallcode::CThemes::current.colors.elem.outline), 8.0f, 0, 1.0f);

                if (repSkin && repSkin->cachedTexture) {
                    float imgW = cardW - 20.0f;
                    float imgH = (cardH * 0.7f) - 10.0f;
                    
                    float aspect = 4.0f / 3.0f;
                    float drawW = imgW;
                    float drawH = imgW / aspect;
                    if (drawH > imgH) {
                        drawH = imgH;
                        drawW = imgH * aspect;
                    }
                    
                    ImVec2 imgPMin(p.x + 10.0f + (imgW - drawW) * 0.5f, p.y + 5.0f + (imgH - drawH) * 0.5f);
                    ImVec2 imgPMax(imgPMin.x + drawW, imgPMin.y + drawH);
                    draw->AddImageRounded(repSkin->cachedTexture, imgPMin, imgPMax, ImVec2(0,0), ImVec2(1,1), ImColor(255,255,255,255), 4.0f);
                }

                ImVec2 textSize = ImGui::CalcTextSize(GetWeaponName(wepEnum), nullptr, true, cardW - 10.0f);
                ImVec2 textP(p.x + (cardW - textSize.x) * 0.5f, p.y + cardH - textSize.y - 8.0f);
                draw->AddText(nullptr, 0.0f, textP, ImColor(kallcode::CThemes::current.colors.text), GetWeaponName(wepEnum), nullptr, cardW - 10.0f);
                
                i++;
            }
            
            int totalRows = static_cast<int>((group.weapons.size() + cols - 1) / cols);
            ImGui::SetCursorScreenPos(ImVec2(startPos.x, startPos.y + totalRows * (cardH + pad)));
            ImGui::Dummy(ImVec2(10, 10));
            ImGui::Separator();
            ImGui::Spacing();
        }

        ImGui::EndChild();
    }
    else if (s_viewState == ViewState::Skins)
    {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(kallcode::CThemes::current.colors.elem.background));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(kallcode::CThemes::current.colors.elem.backgroundHovered));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(kallcode::CThemes::current.colors.elem.backgroundClicked));
        if (ImGui::Button(ICON_FA_ARROW_LEFT " Back to Weapons")) {
            ImGui::PopStyleColor(3);
            s_viewState = ViewState::Weapons;
            return;
        }
        ImGui::PopStyleColor(3);
        
        ImGui::SameLine();
        ImGui::Text("  %s Skins", GetWeaponName(s_selectedWeaponEnum));
        ImGui::Separator();

        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(kallcode::CThemes::current.colors.elem.background));
        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(kallcode::CThemes::current.colors.elem.backgroundHovered));
        ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(kallcode::CThemes::current.colors.elem.backgroundClicked));
        ImGui::InputText("Search", s_searchBuf, IM_ARRAYSIZE(s_searchBuf));
        
        static int s_sortMode = 0;
        kallcode::CUIElements::combo(kallcode::ElemType::Single, "Sort", &s_sortMode, {"Default", "Red to Gray", "Gray to Red"});
        
        ImGui::PopStyleColor(3);
        
        ImGui::Spacing();

        std::vector<SkinInfo_t>* pSkins = nullptr;
        std::vector<SkinInfo_t*> filteredSkins;

        if (s_selectedWeaponEnum == WeaponsEnum::Knife) pSkins = &g_SkinDB->GetKnifeSkins();
        else if (s_selectedWeaponEnum == WeaponsEnum::Glove) pSkins = &g_SkinDB->GetGloveSkins();
        else pSkins = &g_SkinDB->GetWeaponSkins();

        if (!pSkins) return;

        std::string search(s_searchBuf);
        std::transform(search.begin(), search.end(), search.begin(), ::tolower);

        for (auto& skin : *pSkins) {
            if (s_selectedWeaponEnum != WeaponsEnum::Knife && s_selectedWeaponEnum != WeaponsEnum::Glove) {
                if (skin.weaponType != s_selectedWeaponEnum) continue;
            }
            
            if (!search.empty()) {
                std::string lowerName = skin.name;
                std::transform(lowerName.begin(), lowerName.end(), lowerName.begin(), ::tolower);
                if (lowerName.find(search) == std::string::npos) continue;
            }
            filteredSkins.push_back(&skin);
        }

        if (s_sortMode == 1) {
            std::sort(filteredSkins.begin(), filteredSkins.end(), [](SkinInfo_t* a, SkinInfo_t* b) {
                if (a->rarity != b->rarity) return a->rarity > b->rarity;
                return a->name < b->name;
            });
        } else if (s_sortMode == 2) {
            std::sort(filteredSkins.begin(), filteredSkins.end(), [](SkinInfo_t* a, SkinInfo_t* b) {
                if (a->rarity != b->rarity) return a->rarity < b->rarity;
                return a->name < b->name;
            });
        } else {
            std::sort(filteredSkins.begin(), filteredSkins.end(), [](SkinInfo_t* a, SkinInfo_t* b) {
                return a->name < b->name;
            });
        }

        float hPad = 8.0f;
        float windowWidth = ImGui::GetContentRegionAvail().x - hPad * 2.0f;
        float minCardW = 120.0f;
        float pad = 10.0f;
        int cols = (int)((windowWidth + pad) / (minCardW + pad));
        if (cols < 1) cols = 1;

        float cardW = (windowWidth - (cols - 1) * pad) / cols;
        float cardH = cardW * 1.25f; // Taller cards for skins

        ImGui::BeginChild("##skins_grid", ImGui::GetContentRegionAvail(), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);
        
        ImDrawList* draw = ImGui::GetWindowDrawList();
        ImVec2 startPos = ImGui::GetCursorScreenPos();
        
        for (int i = 0; i < static_cast<int>(filteredSkins.size()); i++) {
            SkinInfo_t* skin = filteredSkins[i];
            
            g_SkinDB->RequestTexture(skin);

            int row = i / cols;
            int col = i % cols;
            
            ImVec2 p(startPos.x + hPad + col * (cardW + pad), startPos.y + row * (cardH + pad));
            
            ImGui::SetCursorScreenPos(p);
            ImGui::PushID((int)i);
            bool clicked = ImGui::InvisibleButton("##card", ImVec2(cardW, cardH));
            ImGui::PopID();
            
            bool hovered = ImGui::IsItemHovered();
            
            if (clicked) {
                s_selectedSkin = skin;
                s_settingsPaint = skin->Paint;
                s_settingsWear = 0.001f;
                s_settingsSeed = 0;
                s_settingsStatTrak = -1;
                s_settingsOldModel = skin->legacy_model;
                s_viewState = ViewState::Settings;
            }

            ImColor bgCol = hovered ? ImColor(kallcode::CThemes::current.colors.elem.backgroundHovered) : ImColor(kallcode::CThemes::current.colors.elem.background);
            draw->AddRectFilled(p, ImVec2(p.x + cardW, p.y + cardH), bgCol, 8.0f);
            
            ImColor borderCol = GetRarityColor(skin->rarity);
            if (hovered) borderCol = ImColor(255, 255, 255, 255);
            draw->AddRect(p, ImVec2(p.x + cardW, p.y + cardH), borderCol, 8.0f, 0, 1.0f);

            if (skin->cachedTexture) {
                float imgW = cardW - 10.0f;
                float imgH = (cardH * 0.7f) - 10.0f;
                
                float aspect = 4.0f / 3.0f;
                float drawW = imgW;
                float drawH = imgW / aspect;
                if (drawH > imgH) {
                    drawH = imgH;
                    drawW = imgH * aspect;
                }
                
                ImVec2 imgPMin(p.x + 5.0f + (imgW - drawW) * 0.5f, p.y + 5.0f + (imgH - drawH) * 0.5f);
                ImVec2 imgPMax(imgPMin.x + drawW, imgPMin.y + drawH);
                draw->AddImageRounded(skin->cachedTexture, imgPMin, imgPMax, ImVec2(0,0), ImVec2(1,1), ImColor(255,255,255,255), 4.0f);
            }

            ImVec2 textSize = ImGui::CalcTextSize(skin->name.c_str(), nullptr, true, cardW - 10.0f);
            ImVec2 textP(p.x + (cardW - textSize.x) * 0.5f, p.y + cardH - textSize.y - 8.0f);
            draw->AddText(nullptr, 0.0f, textP, ImColor(kallcode::CThemes::current.colors.text), skin->name.c_str(), nullptr, cardW - 10.0f);
        }

        int totalRows = static_cast<int>((filteredSkins.size() + cols - 1) / cols);
        ImGui::SetCursorScreenPos(ImVec2(startPos.x, startPos.y + totalRows * (cardH + pad)));
        ImGui::Dummy(ImVec2(10, 10));

        ImGui::EndChild();
    }
    else if (s_viewState == ViewState::Settings)
    {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(kallcode::CThemes::current.colors.elem.background));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(kallcode::CThemes::current.colors.elem.backgroundHovered));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(kallcode::CThemes::current.colors.elem.backgroundClicked));
        if (ImGui::Button(ICON_FA_ARROW_LEFT " Back to Skins")) {
            ImGui::PopStyleColor(3);
            s_viewState = ViewState::Skins;
            return;
        }
        ImGui::PopStyleColor(3);
        
        ImGui::SameLine();
        ImGui::Text("  Settings for %s | %s", GetWeaponName(s_selectedWeaponEnum), s_selectedSkin ? s_selectedSkin->name.c_str() : "");
        ImGui::Separator();

        if (s_selectedSkin) {
            ImDrawList* draw = ImGui::GetWindowDrawList();
            ImVec2 p = ImGui::GetCursorScreenPos();
            
            float previewW = 300.0f;
            float previewH = 200.0f;
            
            draw->AddRectFilled(p, ImVec2(p.x + previewW, p.y + previewH), ImColor(kallcode::CThemes::current.colors.elem.background), 8.0f);
            draw->AddRect(p, ImVec2(p.x + previewW, p.y + previewH), ImColor(kallcode::CThemes::current.colors.elem.outline), 8.0f);
            
            if (s_selectedSkin->cachedTexture) {
                float aspect = 4.0f / 3.0f;
                float drawW = previewW - 20.0f;
                float drawH = drawW / aspect;
                if (drawH > previewH - 20.0f) {
                    drawH = previewH - 20.0f;
                    drawW = drawH * aspect;
                }
                
                ImVec2 imgPMin(p.x + 10.0f + (previewW - 20.0f - drawW) * 0.5f, p.y + 10.0f + (previewH - 20.0f - drawH) * 0.5f);
                ImVec2 imgPMax(imgPMin.x + drawW, imgPMin.y + drawH);
                
                draw->AddImageRounded(s_selectedSkin->cachedTexture, imgPMin, imgPMax, ImVec2(0,0), ImVec2(1,1), ImColor(255,255,255,255), 8.0f);
            }
            
            ImGui::SetCursorScreenPos(ImVec2(p.x + previewW + 20.0f, p.y));
            
            ImGui::BeginChild("##skin_settings_sliders", ImVec2(ImGui::GetContentRegionAvail().x - 20.0f, previewH), false);
            
            ImGui::PushItemWidth(300.0f);
            PopupEntries::sliderFloat(std::nullopt, "Wear", &s_settingsWear, 0.0001f, 1.0f);
            PopupEntries::sliderInt(std::nullopt, "Seed", &s_settingsSeed, 0, 1000);
            PopupEntries::sliderInt(std::nullopt, "StatTrak", &s_settingsStatTrak, -1, 999999);
            ImGui::PopItemWidth();

            ImGui::EndChild();
            
            ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + previewH + 20.0f));
            ImGui::Separator();
            ImGui::Spacing();
            
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.33f, 0.65f, 0.29f, 1.0f)); 
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.37f, 0.70f, 0.33f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.29f, 0.60f, 0.25f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.50f, 0.85f, 0.45f, 1.0f));
            ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 30.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
            
            if (ImGui::Button("Apply Skin", ImVec2(150, 40))) {
                if (s_selectedWeaponEnum == WeaponsEnum::Knife) {
                    SKINS::skins_cfg[static_cast<int>(WeaponsEnum::Knife)] = SKIN_CFG(s_settingsPaint, s_settingsWear, s_settingsSeed, s_settingsOldModel, s_settingsStatTrak);
                } else if (s_selectedWeaponEnum != WeaponsEnum::Glove) {
                    int weaponDefIndex = static_cast<int>(s_selectedWeaponEnum);
                    if (weaponDefIndex > 0) {
                        SKINS::skins_cfg[weaponDefIndex] = SKIN_CFG(s_settingsPaint, s_settingsWear, s_settingsSeed, s_settingsOldModel, s_settingsStatTrak);
                    }
                }

                s_notifyText = s_selectedSkin->name;
                s_notifyAlpha = 3.0f;
            }
            
            ImGui::PopStyleVar(2);
            ImGui::PopStyleColor(5);
        }
    }
}

} // namespace tabs
} // namespace kallcode
