//
// Created by rei on 1/28/2026.
//

#ifndef SCATTEREDABYSS_DESKTOP_TABS_HPP
#define SCATTEREDABYSS_DESKTOP_TABS_HPP

#include <string>

namespace kallcode::tabs
{
    extern void callConfig( int child );
    extern void callVisual( int child );
    extern void callWorld( int child );
    extern void callWorldMisc( int child );
    extern void callLegitbot( int child );
    extern void callLegitbotTrigger( int child );
    extern void callSkins( int child );
    extern void callInternet( int child );

    extern std::string get_selected_config();
} // namespace kallcode::tabs

#endif // SCATTEREDABYSS_DESKTOP_TABS_HPP
