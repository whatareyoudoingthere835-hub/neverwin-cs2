//
// Created by rei on 1/22/2026.
//

#ifndef EVERNESSEU_CORE_HPP
#define EVERNESSEU_CORE_HPP

#include <memory>
#include <string>

#include "config/data.hpp"

namespace kallcode
{
    class CUserInterface;
    class CFonts;
    class CAlerts;
    class CBinder;
    class CThemes;
    class CWidgets;
    class CAssets;
} // namespace kallcode

namespace zhironium
{
    class CGraphics;

    struct KallcodeKit
    {
        KallcodeKit( );
        ~KallcodeKit( );

        std::unique_ptr< kallcode::CUserInterface > ui;
        std::unique_ptr< kallcode::CFonts > fonts;
        std::unique_ptr< kallcode::CAlerts > alerts;
        std::unique_ptr< kallcode::CBinder > binder;
        std::unique_ptr< kallcode::CThemes > themes;
        std::unique_ptr< kallcode::CWidgets > widgets;
        std::unique_ptr< kallcode::CAssets > assets;

        int resizeWidth;
        int resizeHeight;
    };

    class CCore
    {
    public:
        CCore( );
        ~CCore( );

        std::unique_ptr< KallcodeKit > kallcode;

        std::unique_ptr< CGraphics > graphics;

        Config config;

        bool safeMode { true };
    };

    extern std::unique_ptr< CCore > ctx;
} // namespace zhironium

#endif // EVERNESSEU_CORE_HPP
