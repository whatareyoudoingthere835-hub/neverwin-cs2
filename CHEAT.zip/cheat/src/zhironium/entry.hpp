//
// Created by rei on 1/22/2026.
//

#ifndef EVERNESSEU_ENTRY_HPP
#define EVERNESSEU_ENTRY_HPP

namespace zhironium
{
    struct EntryPoint
    {
        ~EntryPoint( );
        EntryPoint( );
    };
} // namespace zhironium

#endif // EVERNESSEU_ENTRY_HPP
