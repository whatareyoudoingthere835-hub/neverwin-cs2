//
// Created by rei on 1/22/2026.
//

#include "entry.hpp"

#include "src/core.hpp"
#include "assets/assets.hpp"
#include "graphics/graphics.hpp"
#include "ui/ui.hpp"
#include "fonts/fonts.hpp"
#include "ui/alerts/alerts.hpp"
#include "ui/widgets/widgets.hpp"
#include "util/util.hpp"

#include <sstream>
#include <thread>

using zhironium::EntryPoint;

EntryPoint::~EntryPoint( ) = default;

EntryPoint::EntryPoint( )
{
    ctx = std::make_unique< CCore >( );

    ctx->graphics->execute( [] {
        kallcode::CUserInterface::logo = ctx->graphics->loadTextureFromFile( "C:\\zhironium_assets\\Interlope.png" );
        kallcode::CUserInterface::profile_picture = ctx->graphics->loadTextureFromFile( "C:\\zhironium_assets\\profile_picture.jpg" );

        ctx->kallcode->ui->init( );
        ctx->kallcode->fonts->init( );
        // ctx->kallcode->assets->loadFromFolder( "C:\\zzzstickers" );
    },
                            [] {
                                {
                                    ctx->kallcode->ui->render( );
                                    ctx->kallcode->alerts->render( );
                                    ctx->kallcode->widgets->render( );
                                }
                            } );
}
