#pragma once
#include <Windows.h>
#include <cstdint>
#include <cassert>
#include <vector>
#include <string_view>
#include <format>
#include <unordered_map>

#ifdef _DEBUG
#include <iostream>
#endif

// used: string encryption
#include "../ext/xorstr.h"

// XORSTR
#ifdef _DEBUG
#define CS_XOR(STRING) STRING
#else
#define JM_XORSTR_DISABLE_AVX_INTRINSICS
#define CS_XOR(STRING) xorstr_(STRING)
#endif

// MEM_PAD
#define _CS_INTERNAL_CONCATENATE(LEFT, RIGHT) LEFT##RIGHT
#define CS_CONCATENATE(LEFT, RIGHT) _CS_INTERNAL_CONCATENATE(LEFT, RIGHT)
#define MEM_PAD(SIZE)										\
private:													\
	char CS_CONCATENATE(pad_0, __COUNTER__)[SIZE];			\
public: