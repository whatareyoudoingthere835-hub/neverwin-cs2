#pragma once
#include "base.hpp"

namespace INIT
{
	void Init(HINSTANCE instance);
}