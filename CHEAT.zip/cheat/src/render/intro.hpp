#pragma once

void InterlopeIntro_Render();
bool InterlopeIntro_IsFinished();
void InterlopeIntro_RenderWarning();
bool InterlopeIntro_IsWarningDismissed();
