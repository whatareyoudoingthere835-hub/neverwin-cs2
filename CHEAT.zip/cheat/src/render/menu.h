#pragma once

struct ImFont;
struct ImGuiIO;
struct ID3D11Device;
struct ID3D11DeviceContext;

// Menu API
void InterlopeMenu_Initialize(ImGuiIO& io, ID3D11Device* device, ID3D11DeviceContext* ctx);
void InterlopeMenu_Render();
bool InterlopeMenu_IsOpen();
void InterlopeMenu_Toggle();
