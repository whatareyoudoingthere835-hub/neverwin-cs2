#include "configs.h"
#include "../../core/settings.hpp"
#include "../features/skins/skins.hpp"
#include "../../ext/imgui/imgui.h"
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <wincrypt.h>
#include <shlobj.h>
#include <shellapi.h>
#pragma comment(lib, "advapi32.lib")
#include <sstream>
#include <fstream>
#include <algorithm>
#include "../base.hpp"
#include <cstring>
#include <cstdio>
#include <cctype>
#include <vector>
#include <wininet.h>
#pragma comment(lib, "wininet.lib")

#pragma comment(lib, "shell32.lib")

namespace configs
{
	static thread_local char g_err[256];

	const char* last_error()
	{
		return g_err;
	}

	static void set_err(const char* s)
	{
		snprintf(g_err, sizeof(g_err), "%s", s ? s : "");
	}

	std::wstring get_config_dir_w()
	{
		return CS_XOR(L"C:\\Interlope\\configs");
	}

	std::string get_config_dir()
	{
		std::wstring wpath = get_config_dir_w();
		int len = WideCharToMultiByte(CP_UTF8, 0, wpath.c_str(), -1, NULL, 0, NULL, NULL);
		if (len <= 0) return CS_XOR("C:\\Interlope");
		std::string path(len, 0);
		WideCharToMultiByte(CP_UTF8, 0, wpath.c_str(), -1, &path[0], len, NULL, NULL);
		while (!path.empty() && path.back() == '\0') path.pop_back();
		return path;
	}

	std::wstring get_killsound_dir_w()
	{
		return get_config_dir_w() + L"\\hitsounds";
	}

	bool ensure_directory()
	{
		CreateDirectoryW(CS_XOR(L"C:\\Interlope"), NULL);
		std::wstring dir = get_config_dir_w();
		if (CreateDirectoryW(dir.c_str(), NULL) || GetLastError() == ERROR_ALREADY_EXISTS)
		{
			std::wstring ks = CS_XOR(L"C:\\Interlope\\killsound");
			CreateDirectoryW(ks.c_str(), NULL);
			return true;
		}
		set_err("Failed to create directory");
		return false;
	}

	std::string xor_crypt(std::string data)
	{
		const char* key = CS_XOR("AppSystemContextID_7b82_9a");
		size_t key_len = strlen(key);
		for (size_t i = 0; i < data.size(); ++i) {
			data[i] ^= key[i % key_len];
		}
		return data;
	}

	std::vector<std::string> list_configs()
	{
		ensure_directory();
		std::vector<std::string> ret;
		std::wstring search_path = get_config_dir_w() + L"\\*.cfg";

		WIN32_FIND_DATAW fd;
		HANDLE hFind = FindFirstFileW(search_path.c_str(), &fd);
		if (hFind != INVALID_HANDLE_VALUE)
		{
			do {
				if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
				{
					std::wstring wname = fd.cFileName;
					int len = WideCharToMultiByte(CP_UTF8, 0, wname.c_str(), -1, NULL, 0, NULL, NULL);
					if (len > 0) {
						std::string name(len, 0);
						WideCharToMultiByte(CP_UTF8, 0, wname.c_str(), -1, &name[0], len, NULL, NULL);
						while (!name.empty() && name.back() == '\0') name.pop_back();
						if (name.length() > 4) {
							ret.push_back(name.substr(0, name.length() - 4));
						}
					}
				}
			} while (FindNextFileW(hFind, &fd));
			FindClose(hFind);
		}
		return ret;
	}

	std::string sanitize_config_name(const char* name)
	{
		if (!name) return "Unnamed";
		std::string res = name;
		for (char& c : res) {
			if (!isalnum(c) && c != '_' && c != '-') c = '_';
		}
		if (res.empty()) return "Unnamed";
		return res;
	}

	static std::string get_file_path(const char* name_no_ext)
	{
		return get_config_dir() + "\\" + sanitize_config_name(name_no_ext) + ".cfg";
	}

	bool create_config(const char* name_no_ext)
	{
		if (!ensure_directory()) return false;
		std::string path = get_file_path(name_no_ext);
		std::ofstream out(path);
		if (!out.is_open())
		{
			set_err("Failed to create file");
			return false;
		}
		out << CS_XOR("// Interlope config") << std::endl;
		out.close();
		return true;
	}

	bool save_config(const char* name_no_ext)
	{
		if (!ensure_directory()) return false;
		std::string path = get_file_path(name_no_ext);
		
		std::ostringstream o;
		
		auto bf = [&](std::ostringstream& os, const char* key, bool val) { os << key << "=" << (val ? 1 : 0) << "\n"; };
		auto ff = [&](std::ostringstream& os, const char* key, float val) { os << key << "=" << val << "\n"; };
		auto intf = [&](std::ostringstream& os, const char* key, int val) { os << key << "=" << val << "\n"; };

		bf(o, "aimbot_enabled", Settings::aimbot_enabled);
		ff(o, "aimbot_fov", Settings::aimbot_fov);
		intf(o, "aimbot_bones", Settings::aimbot_bones);

		bf(o, "esp_enabled", Settings::esp_enabled);
		bf(o, "esp_box", Settings::esp_box);
		bf(o, "esp_name", Settings::esp_name);
		bf(o, "esp_health", Settings::esp_health);

		bf(o, "chams_enabled", Settings::chams_enabled);
		bf(o, "movement_bhop", Settings::movement_bhop);

		bf(o, "skinchanger_enabled", Settings::skinchanger_enabled);
		bf(o, "skinchanger_knife_enabled", Settings::skinchanger_knife_enabled);
		intf(o, "skinchanger_knife_model", Settings::skinchanger_knife_model);
		ff(o, "skinchanger_knife_paint_kit", Settings::skinchanger_knife_paint_kit);
		ff(o, "skinchanger_knife_wear", Settings::skinchanger_knife_wear);

		bf(o, "skinchanger_glove_enabled", Settings::skinchanger_glove_enabled);
		intf(o, "skinchanger_glove_model", Settings::skinchanger_glove_model);
		ff(o, "skinchanger_glove_paint_kit", Settings::skinchanger_glove_paint_kit);
		ff(o, "skinchanger_glove_wear", Settings::skinchanger_glove_wear);

		for (size_t def_index = 0; def_index < SKINS::skins_size; ++def_index)
		{
			auto& cfg = SKINS::skins_cfg[def_index];
			if (cfg.FallbackPaintKit != -1) {
				intf(o, ("skin_" + std::to_string(def_index) + "_paint_kit").c_str(), cfg.FallbackPaintKit);
				ff(o, ("skin_" + std::to_string(def_index) + "_wear").c_str(), cfg.FallbackWear);
				intf(o, ("skin_" + std::to_string(def_index) + "_seed").c_str(), cfg.FallbackSeed);
				intf(o, ("skin_" + std::to_string(def_index) + "_stat_trak").c_str(), cfg.FallbackStatTrak);
				bf(o, ("skin_" + std::to_string(def_index) + "_use_old_model").c_str(), cfg.use_old_model);
			}
		}

		std::string raw = o.str();
		raw = xor_crypt(raw);
		std::ofstream out(path, std::ios::binary);
		if (!out.is_open())
		{
			set_err("Failed to save file");
			return false;
		}
		out.write(raw.c_str(), raw.size());
		out.close();
		return true;
	}

	static void parse_line(const std::string& line)
	{
		if (line.empty() || line[0] == '/' || line[0] == '#') return;
		size_t eq = line.find('=');
		if (eq == std::string::npos) return;
		std::string key = line.substr(0, eq);
		std::string val = line.substr(eq + 1);

		if (key == "aimbot_enabled") { Settings::aimbot_enabled = (val == "1"); return; }
		if (key == "aimbot_fov") { Settings::aimbot_fov = (float)atof(val.c_str()); return; }
		if (key == "aimbot_bones") { Settings::aimbot_bones = atoi(val.c_str()); return; }

		if (key == "esp_enabled") { Settings::esp_enabled = (val == "1"); return; }
		if (key == "esp_box") { Settings::esp_box = (val == "1"); return; }
		if (key == "esp_name") { Settings::esp_name = (val == "1"); return; }
		if (key == "esp_health") { Settings::esp_health = (val == "1"); return; }

		if (key == "chams_enabled") { Settings::chams_enabled = (val == "1"); return; }
		if (key == "movement_bhop") { Settings::movement_bhop = (val == "1"); return; }

		if (key == "skinchanger_enabled") { Settings::skinchanger_enabled = (val == "1"); return; }
		if (key == "skinchanger_knife_enabled") { Settings::skinchanger_knife_enabled = (val == "1"); return; }
		if (key == "skinchanger_knife_model") { Settings::skinchanger_knife_model = atoi(val.c_str()); return; }
		if (key == "skinchanger_knife_paint_kit") { Settings::skinchanger_knife_paint_kit = (float)atof(val.c_str()); return; }
		if (key == "skinchanger_knife_wear") { Settings::skinchanger_knife_wear = (float)atof(val.c_str()); return; }
		
		if (key == "skinchanger_glove_enabled") { Settings::skinchanger_glove_enabled = (val == "1"); return; }
		if (key == "skinchanger_glove_model") { Settings::skinchanger_glove_model = atoi(val.c_str()); return; }
		if (key == "skinchanger_glove_paint_kit") { Settings::skinchanger_glove_paint_kit = (float)atof(val.c_str()); return; }
		if (key == "skinchanger_glove_wear") { Settings::skinchanger_glove_wear = (float)atof(val.c_str()); return; }

		if (key.find("skin_") == 0)
		{
			size_t first_under = key.find('_');
			size_t second_under = key.find('_', first_under + 1);
			if (second_under != std::string::npos)
			{
				int def_index = atoi(key.substr(first_under + 1, second_under - first_under - 1).c_str());
				if (def_index >= 0 && def_index < SKINS::skins_size) {
					std::string prop = key.substr(second_under + 1);

					if (prop == "paint_kit") SKINS::skins_cfg[def_index].FallbackPaintKit = atoi(val.c_str());
					else if (prop == "wear") SKINS::skins_cfg[def_index].FallbackWear = (float)atof(val.c_str());
					else if (prop == "seed") SKINS::skins_cfg[def_index].FallbackSeed = atoi(val.c_str());
					else if (prop == "stat_trak") SKINS::skins_cfg[def_index].FallbackStatTrak = atoi(val.c_str());
					else if (prop == "use_old_model") SKINS::skins_cfg[def_index].use_old_model = (val == "1");
				}
			}
			return;
		}
	}

	bool load_config(const char* name_no_ext)
	{
		std::string path = get_file_path(name_no_ext);
		std::ifstream in(path, std::ios::binary);
		if (!in.is_open())
		{
			set_err("File not found");
			return false;
		}
		std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
		in.close();

		content = xor_crypt(content);

		std::istringstream stream(content);
		std::string line;
		while (std::getline(stream, line))
		{
			if (!line.empty() && line.back() == '\r') line.pop_back();
			parse_line(line);
		}
		return true;
	}

	bool delete_config(const char* name_no_ext)
	{
		std::string path = get_file_path(name_no_ext);
		if (remove(path.c_str()) == 0) return true;
		set_err("Failed to delete");
		return false;
	}

	void open_config_directory()
	{
		ensure_directory();
		std::wstring dir = get_config_dir_w();
		ShellExecuteW(NULL, L"open", dir.c_str(), NULL, NULL, SW_SHOWDEFAULT);
	}

	std::string g_userName = "Unknown";
	std::string g_tgUserName = "";
	std::string g_userSub = "Sub: Unknown";
	int g_userId = 0;
	std::vector<unsigned char> g_userAvatarBuffer;
	bool g_userAvatarReady = false;
	void* g_userAvatarTexture = nullptr;

	std::string get_hwid_str() {
		DWORD volumeSerialNumber = 0;
		GetVolumeInformationA("C:\\", NULL, 0, &volumeSerialNumber, NULL, NULL, NULL, 0);
		return std::to_string(volumeSerialNumber);
	}

	std::string upload_cloud_config(const char* name_no_ext, int user_id) {
		std::string path = get_file_path(name_no_ext);
		std::ifstream in(path, std::ios::binary);
		if (!in.is_open()) return "";
		std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
		in.close();

		HINTERNET hSession = InternetOpenA("Interlope Client", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
		if (!hSession) return "";
		HINTERNET hConnect = InternetConnectA(hSession, "127.0.0.1", 443, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
		if (!hConnect) { InternetCloseHandle(hSession); return ""; }
		HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", "/configs/upload", NULL, NULL, NULL, INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
		if (!hRequest) { InternetCloseHandle(hConnect); InternetCloseHandle(hSession); return ""; }

		DWORD dwFlags = 0;
		DWORD dwBuffLen = sizeof(dwFlags);
		InternetQueryOptionA(hRequest, INTERNET_OPTION_SECURITY_FLAGS, (LPVOID)&dwFlags, &dwBuffLen);
		dwFlags |= SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_CN_INVALID | SECURITY_FLAG_IGNORE_CERT_DATE_INVALID | SECURITY_FLAG_IGNORE_REVOCATION;
		InternetSetOptionA(hRequest, INTERNET_OPTION_SECURITY_FLAGS, &dwFlags, sizeof(dwFlags));

		std::string code = "";
		std::string headers = "Content-Type: application/json\r\n";
		
		// Hex encode content manually
		std::string escaped_content = "";
		static const char hex_chars[] = "0123456789ABCDEF";
		for (unsigned char c : content) {
			escaped_content += hex_chars[c >> 4];
			escaped_content += hex_chars[c & 15];
		}
		
		std::string payload = "{\"data\": \"" + escaped_content + "\", \"user_id\": " + std::to_string(user_id) + ", \"name\": \"" + std::string(name_no_ext) + "\"}";
		
		if (HttpSendRequestA(hRequest, headers.c_str(), headers.length(), (LPVOID)payload.data(), payload.size())) {
			char buffer[1024];
			DWORD bytesRead;
			std::string response = "";
			while (InternetReadFile(hRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
				buffer[bytesRead] = '\0';
				response += buffer;
			}
			size_t codePos = response.find("\"code\":\"");
			if (codePos != std::string::npos) {
				codePos += 8;
				size_t endPos = response.find("\"", codePos);
				if (endPos != std::string::npos) {
					code = response.substr(codePos, endPos - codePos);
				}
			}
		}
		InternetCloseHandle(hRequest);
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hSession);
		return code;
	}

	bool download_cloud_config(const char* code, const char* name_no_ext) {
		HINTERNET hSession = InternetOpenA("Interlope Client", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
		if (!hSession) return false;
		HINTERNET hConnect = InternetConnectA(hSession, "127.0.0.1", 443, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
		if (!hConnect) { InternetCloseHandle(hSession); return false; }
		
		std::string reqPath = std::string("/configs/") + code;
		HINTERNET hRequest = HttpOpenRequestA(hConnect, "GET", reqPath.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
		if (!hRequest) { InternetCloseHandle(hConnect); InternetCloseHandle(hSession); return false; }

		DWORD dwFlags = 0;
		DWORD dwBuffLen = sizeof(dwFlags);
		InternetQueryOptionA(hRequest, INTERNET_OPTION_SECURITY_FLAGS, (LPVOID)&dwFlags, &dwBuffLen);
		dwFlags |= SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_CN_INVALID | SECURITY_FLAG_IGNORE_CERT_DATE_INVALID | SECURITY_FLAG_IGNORE_REVOCATION;
		InternetSetOptionA(hRequest, INTERNET_OPTION_SECURITY_FLAGS, &dwFlags, sizeof(dwFlags));

		std::string response_data = "";
		if (HttpSendRequestA(hRequest, NULL, 0, NULL, 0)) {
			char buffer[4096];
			DWORD bytesRead;
			while (InternetReadFile(hRequest, buffer, sizeof(buffer)-1, &bytesRead) && bytesRead > 0) {
				buffer[bytesRead] = '\0';
				response_data.append(buffer);
			}
		}
		InternetCloseHandle(hRequest);
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hSession);

		if (response_data.empty() || response_data.find("{\"error\"") != std::string::npos) {
			set_err("Config not found on cloud");
			return false;
		}
		
		// Parse {"data": "<config_data>"}
		std::string config_data = "";
		size_t dataPos = response_data.find("\"data\":\"");
		if (dataPos != std::string::npos) {
			dataPos += 8;
			size_t endPos = response_data.find("\"", dataPos);
			if (endPos != std::string::npos) {
				std::string hex_str = response_data.substr(dataPos, endPos - dataPos);
				// Hex decode
				for (size_t i = 0; i + 1 < hex_str.length(); i += 2) {
					std::string byteString = hex_str.substr(i, 2);
					char byte = (char)strtol(byteString.c_str(), NULL, 16);
					config_data += byte;
				}
			}
		}

		ensure_directory();
		std::string local_path = get_file_path(name_no_ext);
		std::ofstream out(local_path, std::ios::binary);
		if (!out.is_open()) {
			set_err("Failed to write downloaded config");
			return false;
		}
		out.write(config_data.c_str(), config_data.size());
		out.close();

		return true;
	}

	void fetch_user_info() {
		std::string hwid = get_hwid_str();
		HINTERNET hSession = InternetOpenA("Interlope Client", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
		if (!hSession) return;
		HINTERNET hConnect = InternetConnectA(hSession, "127.0.0.1", 443, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
		if (!hConnect) { InternetCloseHandle(hSession); return; }

		std::string path = "/userinfo?hwid=" + hwid;
		HINTERNET hRequest = HttpOpenRequestA(hConnect, "GET", path.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
		if (!hRequest) { InternetCloseHandle(hConnect); InternetCloseHandle(hSession); return; }

		DWORD dwFlags = 0;
		DWORD dwBuffLen = sizeof(dwFlags);
		InternetQueryOptionA(hRequest, INTERNET_OPTION_SECURITY_FLAGS, (LPVOID)&dwFlags, &dwBuffLen);
		dwFlags |= SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_CN_INVALID | SECURITY_FLAG_IGNORE_CERT_DATE_INVALID | SECURITY_FLAG_IGNORE_REVOCATION;
		InternetSetOptionA(hRequest, INTERNET_OPTION_SECURITY_FLAGS, &dwFlags, sizeof(dwFlags));

		if (HttpSendRequestA(hRequest, NULL, 0, NULL, 0)) {
			std::string response = "";
			char buffer[1024];
			DWORD bytesRead;
			while (InternetReadFile(hRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
				buffer[bytesRead] = '\0';
				response += buffer;
			}

			if (!response.empty()) {
				size_t uidPos = response.find("\"user_id\":");
				if (uidPos != std::string::npos) {
					uidPos += 10;
					size_t endPos = response.find_first_not_of("0123456789", uidPos);
					if (endPos == std::string::npos) endPos = response.size();
					try {
						g_userId = std::stoi(response.substr(uidPos, endPos - uidPos));
					} catch (...) {}
				}

				size_t tgPos = response.find("\"tg_username\":\"");
				if (tgPos != std::string::npos) {
					tgPos += 15;
					size_t endPos = response.find("\"", tgPos);
					if (endPos != std::string::npos) {
						g_tgUserName = response.substr(tgPos, endPos - tgPos);
					}
				}

				size_t nickPos = response.find("\"nickname\":\"");
				if (nickPos != std::string::npos) {
					nickPos += 12;
					size_t endPos = response.find("\"", nickPos);
					if (endPos != std::string::npos) {
						g_userName = response.substr(nickPos, endPos - nickPos);
						if (g_userName.empty() || g_userName == "null") g_userName = "Unknown";
					}
				} else {
					if (g_tgUserName.empty()) {
						g_userName = "Unknown";
					} else {
						g_userName = g_tgUserName;
					}
				}

				size_t expPos = response.find("\"expires\":");
				if (expPos != std::string::npos) {
					expPos += 10;
					size_t endPos = response.find_first_not_of("0123456789", expPos);
					if (endPos == std::string::npos) endPos = response.size();
					std::string expStr = response.substr(expPos, endPos - expPos);
					long long timestamp = 0;
					try {
						timestamp = std::stoll(expStr);
						if (timestamp > 0) {
							if (timestamp > 2524608000LL) {
								g_userSub = "Sub: Lifetime";
							} else {
								__time64_t t = static_cast<__time64_t>(timestamp);
								struct tm timeinfo {};
								if (_localtime64_s(&timeinfo, &t) == 0) {
									char buf[80];
									strftime(buf, sizeof(buf), "Sub: %Y-%m-%d", &timeinfo);
									g_userSub = buf;
								}
							}
						}
					} catch (...) {}
				}
			}
		}
		InternetCloseHandle(hRequest);
		InternetCloseHandle(hConnect);

		if (!g_tgUserName.empty() && g_tgUserName != "Unknown") {
			HINTERNET hConnect2 = InternetConnectA(hSession, "t.me", INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
			if (hConnect2) {
				std::string path2 = "/" + g_tgUserName;
				HINTERNET hRequest2 = HttpOpenRequestA(hConnect2, "GET", path2.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE | INTERNET_FLAG_RELOAD, 0);
				if (hRequest2) {
					if (HttpSendRequestA(hRequest2, NULL, 0, NULL, 0)) {
						std::string response2 = "";
						char buffer[4096];
						DWORD bytesRead;
						while (InternetReadFile(hRequest2, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
							buffer[bytesRead] = '\0';
							response2 += buffer;
						}
						
						size_t ogPos = response2.find("property=\"og:image\" content=\"");
						if (ogPos != std::string::npos) {
							ogPos += 29;
							size_t endPos = response2.find("\"", ogPos);
							if (endPos != std::string::npos) {
								std::string avatarUrl = response2.substr(ogPos, endPos - ogPos);
								if (avatarUrl.find("https://") == 0) {
									avatarUrl = avatarUrl.substr(8);
									size_t slashPos = avatarUrl.find("/");
									if (slashPos != std::string::npos) {
										std::string host = avatarUrl.substr(0, slashPos);
										std::string path3 = avatarUrl.substr(slashPos);
										
										HINTERNET hConnectImg = InternetConnectA(hSession, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
										if (hConnectImg) {
											HINTERNET hRequestImg = HttpOpenRequestA(hConnectImg, "GET", path3.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE | INTERNET_FLAG_RELOAD, 0);
											if (hRequestImg) {
												if (HttpSendRequestA(hRequestImg, NULL, 0, NULL, 0)) {
													std::vector<unsigned char> imgData;
													while (InternetReadFile(hRequestImg, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
														imgData.insert(imgData.end(), buffer, buffer + bytesRead);
													}
													if (!imgData.empty()) {
														g_userAvatarBuffer = imgData;
														g_userAvatarReady = true;
													}
												}
												InternetCloseHandle(hRequestImg);
											}
											InternetCloseHandle(hConnectImg);
										}
									}
								}
							}
						}
					}
					InternetCloseHandle(hRequest2);
				}
				InternetCloseHandle(hConnect2);
			}
		}

		InternetCloseHandle(hSession);
	}
}
