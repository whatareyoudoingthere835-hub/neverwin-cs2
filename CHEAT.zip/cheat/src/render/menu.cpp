#include "menu.h"
#include <windows.h>
#include "../zhironium/src/core.hpp"
#include "../zhironium/src/kallcode/assets/assets.hpp"
#include "../zhironium/src/graphics/graphics.hpp"
#include "../zhironium/src/kallcode/ui/ui.hpp"
#include "../zhironium/src/kallcode/fonts/fonts.hpp"
#include "../zhironium/src/kallcode/ui/alerts/alerts.hpp"
#include "../zhironium/src/kallcode/ui/widgets/widgets.hpp"
#include "../zhironium/src/dream_mode/dream_mode.hpp"
#include "../core/settings.hpp"
#include "../zhironium/src/kallcode/ui/elem/elem.hpp"
#include "../zhironium/src/kallcode/ui/popups/popups.hpp"
#include "../base.hpp"
#include <filesystem>
#include <string>

#include "../zhironium/src/kallcode/ui/binder/binder.hpp"

void InterlopeMenu_Initialize(ImGuiIO& io, ID3D11Device* device, ID3D11DeviceContext* ctx)
{
    zhironium::ctx = std::make_unique<zhironium::CCore>();

    zhironium::CGraphics::m_device = device;
    zhironium::CGraphics::m_deviceContext = ctx;

    zhironium::ctx->kallcode->ui->init();
    zhironium::ctx->kallcode->fonts->init();
}

#include "intro.hpp"

void InterlopeMenu_Render()
{
    if (!zhironium::ctx) return;

    if (!InterlopeIntro_IsFinished()) {
        InterlopeIntro_Render();
        return;
    }

    static bool warning_cursor_freed = false;

    if (!InterlopeIntro_IsWarningDismissed()) {
        if (!warning_cursor_freed) {
            if (!InterlopeMenu_IsOpen()) {
                InterlopeMenu_Toggle();
            }
            warning_cursor_freed = true;
        }

        InterlopeIntro_RenderWarning();
        return;
    }

    if (warning_cursor_freed) {
        warning_cursor_freed = false;
    }

    zhironium::ctx->kallcode->ui->render();


    zhironium::ctx->kallcode->alerts->render();
    zhironium::ctx->kallcode->widgets->render();
    
    dream_mode::handleToggle(&zhironium::c::get<bool>(zhironium::ctx->config.dreamMode));
    zhironium::ctx->kallcode->binder->updateAllBinds();
    zhironium::ctx->kallcode->binder->renderActiveBindMenu();
}

bool InterlopeMenu_IsOpen()
{
    if (!zhironium::ctx) return false;
    return zhironium::ctx->kallcode->ui->isPresented();
}

void InterlopeMenu_Toggle()
{
    if (!zhironium::ctx) return;
    bool& presented = zhironium::ctx->kallcode->ui->isPresented();
    presented = !presented;

    using SDL_SetRelativeMouseMode_t = int(*)(bool);
    static SDL_SetRelativeMouseMode_t SDL_SetRelativeMouseMode = nullptr;
    if (!SDL_SetRelativeMouseMode) {
        SDL_SetRelativeMouseMode = (SDL_SetRelativeMouseMode_t)GetProcAddress(GetModuleHandleA("SDL3.dll"), "SDL_SetRelativeMouseMode");
        if (!SDL_SetRelativeMouseMode)
            SDL_SetRelativeMouseMode = (SDL_SetRelativeMouseMode_t)GetProcAddress(GetModuleHandleA("SDL2.dll"), "SDL_SetRelativeMouseMode");
    }

    if (SDL_SetRelativeMouseMode) {
        SDL_SetRelativeMouseMode(!presented);
    }
}




