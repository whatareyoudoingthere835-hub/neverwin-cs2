#include "intro.hpp"
#include "../../ext/imgui/imgui.h"
#include "../../ext/imgui/imgui_internal.h"
#include "../zhironium/src/core.hpp"
#include "../zhironium/src/kallcode/fonts/fonts.hpp"
#include "../zhironium/src/kallcode/ui/themes/themes.hpp"
#include "../features/skinchanger/skindb_local.hpp"
#include <algorithm>
#include <string>

static float intro_time = 0.0f;
static const float INTRO_DURATION = 20.0f; 
static bool vac_warning_dismissed = false;

void InterlopeIntro_Render()
{
    if (intro_time >= INTRO_DURATION)
        return;

    ImGuiIO& io = ImGui::GetIO();
    intro_time += io.DeltaTime;

    float alpha = 1.0f;
    if (intro_time < 2.0f) {
        alpha = intro_time / 2.0f;
    } else if (intro_time > INTRO_DURATION - 2.0f) {
        alpha = (INTRO_DURATION - intro_time) / 2.0f;
    }
    
    alpha = std::clamp(alpha, 0.0f, 1.0f);

    if (alpha <= 0.0f)
        return;

    ImDrawList* draw = ImGui::GetForegroundDrawList();
    ImVec2 screen_size = io.DisplaySize;
    ImVec2 center = ImVec2(screen_size.x / 2.0f, screen_size.y / 2.0f);

    draw->AddRectFilled(ImVec2(0, 0), screen_size, ImColor(10, 10, 10, (int)(alpha * 199)));

    if (!zhironium::ctx || !zhironium::ctx->kallcode || !zhironium::ctx->kallcode->fonts)
        return;

    ImFont* title_font = zhironium::ctx->kallcode->fonts->get("large").ptr;
    if (title_font) ImGui::PushFont(title_font);
    
    std::string title_text = "Interlope";
    ImVec2 title_size = ImGui::CalcTextSize(title_text.c_str());
    ImVec2 title_pos = ImVec2(center.x - title_size.x / 2.0f, center.y - title_size.y);
    
    draw->AddText(ImVec2(title_pos.x + 2, title_pos.y + 2), ImColor(0, 0, 0, (int)(alpha * 255)), title_text.c_str());
    
    int vert_start_idx = draw->VtxBuffer.Size;
    draw->AddText(title_pos, ImColor(255, 255, 255, (int)(alpha * 255)), title_text.c_str());
    int vert_end_idx = draw->VtxBuffer.Size;

    ImU32 col0 = ImColor(255, 255, 255, (int)(alpha * 255));
    ImU32 col1 = ImColor(kallcode::CThemes::current.colors.accent.x, kallcode::CThemes::current.colors.accent.y, kallcode::CThemes::current.colors.accent.z, alpha);
    
    ImGui::ShadeVertsLinearColorGradientKeepAlpha(
        draw,
        vert_start_idx,
        vert_end_idx,
        ImVec2(center.x - title_size.x / 2.0f, 0),
        ImVec2(center.x + title_size.x / 2.0f, 0),
        col0,
        col1);

    if (title_font) ImGui::PopFont();

    ImFont* subtitle_font = zhironium::ctx->kallcode->fonts->get("primary").ptr;
    if (subtitle_font) ImGui::PushFont(subtitle_font);

    std::string sub_text = g_SkinDB->IsInitialized() ? "Ready" : "Loading skin database..";
    ImVec2 sub_size = ImGui::CalcTextSize(sub_text.c_str());
    ImVec2 sub_pos = ImVec2(center.x - sub_size.x / 2.0f, center.y + 5.0f);
    
    draw->AddText(sub_pos, ImColor(150, 150, 150, (int)(alpha * 255)), sub_text.c_str());

    if (subtitle_font) ImGui::PopFont();

    float bar_width = 200.0f;
    float bar_height = 4.0f;
    ImVec2 bar_min = ImVec2(center.x - bar_width / 2.0f, sub_pos.y + sub_size.y + 15.0f);
    ImVec2 bar_max = ImVec2(bar_min.x + bar_width, bar_min.y + bar_height);
    
    draw->AddRectFilled(bar_min, bar_max, ImColor(30, 30, 30, (int)(alpha * 255)), bar_height / 2.0f);
    
    float progress = intro_time / INTRO_DURATION;
    progress = std::clamp(progress, 0.0f, 1.0f);
    
    float eased_progress = 1.0f - powf(1.0f - progress, 3.0f);
    
    ImVec2 fill_max = ImVec2(bar_min.x + bar_width * eased_progress, bar_max.y);
    draw->AddRectFilled(bar_min, fill_max, col1, bar_height / 2.0f);
}

bool InterlopeIntro_IsFinished()
{
    return intro_time >= INTRO_DURATION;
}

bool InterlopeIntro_IsWarningDismissed()
{
    return vac_warning_dismissed;
}

#include "../zhironium/src/kallcode/ui/elem/elem.hpp"

void InterlopeIntro_RenderWarning()
{
    if (vac_warning_dismissed || !InterlopeIntro_IsFinished())
        return;

    ImGuiIO& io = ImGui::GetIO();
    static float warning_time = 0.0f;
    warning_time += io.DeltaTime;

    ImVec2 screen_size = io.DisplaySize;

    ImGui::SetNextWindowPos(ImVec2(screen_size.x / 2.0f, screen_size.y / 2.0f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(500, 240), ImGuiCond_Always);

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 12.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(20, 20));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, kallcode::CThemes::current.colors.window.background);
    ImGui::PushStyleColor(ImGuiCol_Border, kallcode::CThemes::current.colors.elem.outline);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0f);

    if (ImGui::Begin("VAC Warning", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar))
    {
        ImFont* title_font = zhironium::ctx->kallcode->fonts->get("large").ptr;
        if (title_font) ImGui::PushFont(title_font);
        
        ImGui::TextColored(kallcode::CThemes::current.colors.textUnsafe, "Warning");
        
        if (title_font) ImGui::PopFont();
        
        ImGui::Spacing();
        ImGui::Spacing();

        ImGui::PushStyleColor(ImGuiCol_Text, kallcode::CThemes::current.colors.text);
        ImGui::TextWrapped("Our cheat is safe. However, we recommend being more careful when playing, as we cannot predict how VAC will work.");
        ImGui::Spacing();
        ImGui::PopStyleColor();

        ImGui::PushStyleColor(ImGuiCol_Text, kallcode::CThemes::current.colors.textDim);
        ImGui::TextColored(kallcode::CThemes::current.colors.textDim, "P.S. do not play against fair players");
        ImGui::PopStyleColor();

        ImGui::SetCursorPosY(180);
        
        bool can_click = warning_time >= 1.0f;
        std::string btn_text = can_click ? "I Understand" : "I Understand (" + std::to_string(1 - (int)warning_time) + "s)";
        
        ImVec4 accent = kallcode::CThemes::current.colors.accent;
        float alpha = can_click ? 1.0f : 0.5f;

        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 8.0f);
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(accent.x, accent.y, accent.z, 0.8f * alpha));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(accent.x, accent.y, accent.z, 1.0f * alpha));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(accent.x * 0.8f, accent.y * 0.8f, accent.z * 0.8f, 1.0f * alpha));

        if (ImGui::Button(btn_text.c_str(), ImVec2(ImGui::GetContentRegionAvail().x, 30)))
        {
            if (can_click)
                vac_warning_dismissed = true;
        }

        ImGui::PopStyleColor(3);
        ImGui::PopStyleVar();
    }
    ImGui::End();

    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(2);
}
