// Generated using https://github.com/a2x/cs2-dumper
// 2026-08-25 00:25:40.014294100 UTC

pub const cs2_dumper = struct {
    // Module: client.dll
    pub const buttons = struct {
        pub const attack: usize = 0x20B48F0;
        pub const attack2: usize = 0x20B4980;
        pub const back: usize = 0x20B4BC0;
        pub const duck: usize = 0x20B4E90;
        pub const forward: usize = 0x20B4B30;
        pub const jump: usize = 0x20B4E00;
        pub const left: usize = 0x20B4C50;
        pub const lookatweapon: usize = 0x23DCBA0;
        pub const reload: usize = 0x20B4860;
        pub const right: usize = 0x20B4CE0;
        pub const showscores: usize = 0x23DCA80;
        pub const sprint: usize = 0x20B47D0;
        pub const turnleft: usize = 0x20B4A10;
        pub const turnright: usize = 0x20B4AA0;
        pub const use: usize = 0x20B4D70;
        pub const zoom: usize = 0x23DCB10;
    };
};
