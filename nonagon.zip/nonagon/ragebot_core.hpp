#pragma once
#include "ragebot.hpp"
#include "resolver.hpp"
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>
#include <limits>

class Ragebot
{
public:
    explicit Ragebot(RagebotConfig& cfg) : m_cfg(cfg) {}

    void Run(ILocalPlayer* local, const std::vector<IPlayer*>& players, int currentTick)
    {
        if (!m_cfg.enabled)
            return;
        if (!local || !local->IsAlive())
            return;
        if (!local->CanFire())
            return;

        int weaponIdx = std::clamp(local->GetWeaponIndex(), 0, RagebotConfig::WEAPON_SLOTS - 1);
        const WeaponConfig& wcfg = m_cfg.weapons[weaponIdx];

        if (!wcfg.enabled)
            return;

        if (m_cfg.auto_scope && !local->IsScoped())
            return;

        UpdateBacktrack(players, currentTick);

        AimTarget best = FindBestTarget(local, players, wcfg, currentTick);
        if (!best.valid)
            return;

        ApplyAutostop(local, wcfg);

        Vec3 aimAngles = CalcAngle(local->GetEyePos(), best.aimPos);

        if (wcfg.silent)
            m_pendingAngles = aimAngles;
        else
            local->SetViewAngles(aimAngles);

        if (m_cfg.auto_fire)
            local->ForceAttack();
    }

    void OnShotFired(int targetIdx, HitboxID hitbox, float damage, float hc, int tick)
    {
        ShotRecord rec;
        rec.targetIndex      = targetIdx;
        rec.hitbox           = hitbox;
        rec.estimatedDamage  = damage;
        rec.hitchance        = hc;
        rec.tick             = tick;
        rec.isBodyAim        = (hitbox != HITBOX_HEAD);
        m_lastShot           = rec;
    }

    void OnMissed(int targetIdx, HitboxID hitbox, float resolvedYaw)
    {
        m_resolver.OnMiss(targetIdx, hitbox, resolvedYaw);
    }

    void OnHit(int targetIdx)
    {
        m_resolver.OnHit(targetIdx);
    }

    Vec3 GetPendingAngles() const { return m_pendingAngles; }

    Resolver& GetResolver() { return m_resolver; }

private:
    RagebotConfig&                               m_cfg;
    Resolver                                     m_resolver;
    Vec3                                         m_pendingAngles{};
    ShotRecord                                   m_lastShot{};
    std::array<std::vector<BacktrackRecord>, 64> m_backtrack{};

    void UpdateBacktrack(const std::vector<IPlayer*>& players, int currentTick)
    {
        for (auto* p : players)
        {
            if (!p || !p->IsAlive() || p->IsTeammate())
                continue;

            int idx = p->GetIndex();
            if (idx < 0 || idx >= 64)
                continue;

            auto& records = m_backtrack[idx];

            BacktrackRecord rec;
            for (int h = 0; h < HITBOX_MAX; h++)
                rec.hitboxPos[h] = p->GetHitboxPos(static_cast<HitboxID>(h));
            rec.tick    = currentTick;
            rec.simtime = p->GetSimTime();
            rec.valid   = true;

            records.push_back(rec);

            while (static_cast<int>(records.size()) > m_cfg.max_backtrack_ticks)
                records.erase(records.begin());
        }
    }

    AimTarget FindBestTarget(ILocalPlayer* local, const std::vector<IPlayer*>& players,
                             const WeaponConfig& wcfg, int currentTick)
    {
        AimTarget best;
        Vec3 eyePos  = local->GetEyePos();
        Vec3 viewAng = local->GetViewAngles();
        float dmg    = local->GetWeaponDamage();

        for (auto* p : players)
        {
            if (!p || !p->IsAlive() || p->IsTeammate())
                continue;

            int idx = p->GetIndex();

            float resolvedYaw = m_resolver.Resolve(idx, 0.f, p->GetSpeed(),
                                                   m_cfg.head_misses_trigger);

            AimTarget candidate = EvalPlayer(p, local, wcfg, eyePos, viewAng, dmg, currentTick);

            if (!candidate.valid)
                continue;

            if (candidate.fov < best.fov)
                best = candidate;
        }

        return best;
    }

    AimTarget EvalPlayer(IPlayer* p, ILocalPlayer* local, const WeaponConfig& wcfg,
                         const Vec3& eyePos, const Vec3& viewAng, float dmg, int currentTick)
    {
        AimTarget best;

        int minDmg = wcfg.min_damage_override ? wcfg.min_damage_override_value : wcfg.min_damage;
        int hcReq  = wcfg.hitchance_override  ? wcfg.hitchance_override_value  : wcfg.hitchance;

        auto tryHitbox = [&](HitboxID hb, bool bodyAim)
        {
            if (!p->IsVisible(hb))
                return;

            Vec3 aimPos = p->GetHitboxPos(hb);

            if (bodyAim && wcfg.dynamic_point_scale)
                aimPos = ScalePoint(eyePos, aimPos, wcfg.point_scale);

            float fov = CalcFOV(viewAng, eyePos, aimPos);
            if (fov > wcfg.max_fov)
                return;

            float estimatedDmg = EstimateDamage(p, local, aimPos);
            if (estimatedDmg < minDmg)
                return;

            float hc = CalcHitchance(local, aimPos, wcfg.point_scale, bodyAim);
            if (hc < static_cast<float>(hcReq))
                return;

            if (fov < best.fov)
            {
                best.playerIndex = p->GetIndex();
                best.hitbox      = hb;
                best.aimPos      = aimPos;
                best.damage      = estimatedDmg;
                best.fov         = fov;
                best.valid       = true;
                best.isBodyAim   = bodyAim;
            }
        };

        bool doHead   = (wcfg.hitboxes & (1 << HITBOX_HEAD))    && !wcfg.force_baim;
        bool doChest  = (wcfg.hitboxes & (1 << HITBOX_CHEST));
        bool doStomach= (wcfg.hitboxes & (1 << HITBOX_STOMACH));
        bool doPelvis = (wcfg.hitboxes & (1 << HITBOX_PELVIS));

        if (doHead)   tryHitbox(HITBOX_HEAD,    false);
        if (doChest)  tryHitbox(HITBOX_CHEST,   true);
        if (doStomach)tryHitbox(HITBOX_STOMACH,  true);
        if (doPelvis) tryHitbox(HITBOX_PELVIS,   true);

        if (!best.valid && wcfg.force_baim)
        {
            tryHitbox(HITBOX_CHEST,  true);
            tryHitbox(HITBOX_PELVIS, true);
        }

        if (!best.valid && wcfg.prefer_safe)
        {
            tryHitbox(HITBOX_CHEST,  true);
        }

        return best;
    }

    static void ApplyAutostop(ILocalPlayer* local, const WeaponConfig& wcfg)
    {
        if (wcfg.autostop_mode == AUTOSTOP_NONE)
            return;

        if (local->GetSpeed() > wcfg.autostop_min_speed)
            local->StopMovement();
    }

    static Vec3 CalcAngle(const Vec3& src, const Vec3& dst)
    {
        Vec3 delta = dst - src;
        float dist = delta.len();
        Vec3 ang;
        ang.x = std::asin(delta.z / (dist > 0.f ? dist : 1.f)) * (180.f / 3.14159265f);
        ang.y = std::atan2(delta.y, delta.x) * (180.f / 3.14159265f);
        ang.z = 0.f;
        return ang;
    }

    static float CalcFOV(const Vec3& viewAng, const Vec3& src, const Vec3& dst)
    {
        Vec3 aimAng = CalcAngle(src, dst);
        Vec3 delta  = { aimAng.x - viewAng.x, aimAng.y - viewAng.y, 0.f };
        while (delta.y >  180.f) delta.y -= 360.f;
        while (delta.y < -180.f) delta.y += 360.f;
        return std::sqrt(delta.x * delta.x + delta.y * delta.y);
    }

    static float EstimateDamage(IPlayer* target, ILocalPlayer* local, const Vec3& aimPos)
    {
        float base   = local->GetWeaponDamage();
        float armor  = target->GetArmor();
        float dist   = (aimPos - local->GetEyePos()).len();
        float range  = local->GetWeaponRange();
        float falloff = (range > 0.f) ? std::max(0.f, 1.f - dist / range) : 1.f;
        float armorMult = (armor > 0.f) ? 0.5f : 1.f;
        return base * falloff * armorMult;
    }

    static float CalcHitchance(ILocalPlayer* local, const Vec3& aimPos,
                               float pointScale, bool isBody)
    {
        float spread = local->GetSpread() + local->GetInaccuracy();
        if (spread < 0.0001f)
            return 100.f;

        float radius  = isBody ? (40.f * pointScale) : 4.f;
        float dist    = (aimPos - local->GetEyePos()).len();
        float angSize = std::atan2(radius, dist > 0.f ? dist : 1.f);
        float ratio   = angSize / (spread > 0.f ? spread : 0.0001f);
        return std::clamp(ratio * 100.f, 0.f, 100.f);
    }

    static Vec3 ScalePoint(const Vec3& eye, const Vec3& hitPos, float scale)
    {
        Vec3 dir = (hitPos - eye).normalized();
        float dist = (hitPos - eye).len();
        return eye + dir * (dist * std::clamp(scale, 0.f, 1.f));
    }
};
