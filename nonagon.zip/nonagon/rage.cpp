#include "ragebot.hpp"
#include "resolver.hpp"
#include "ragebot_core.hpp"
#include "strafer.hpp"
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>

static RagebotConfig  g_cfg;
static StraferConfig  g_strafer_cfg;
static Ragebot        g_rage(g_cfg);
static TestStrafer    g_strafer(g_strafer_cfg);

static std::array<std::vector<BacktrackRecord>, 64> g_backtrack;

static float NormalizeYaw(float y)
{
    while (y >  180.f) y -= 360.f;
    while (y < -180.f) y += 360.f;
    return y;
}

static Vec3 CalcAngle(const Vec3& src, const Vec3& dst)
{
    Vec3 delta = dst - src;
    float dist = delta.len();
    Vec3 ang;
    ang.x = std::asin(delta.z / (dist > 0.f ? dist : 1.f)) * (180.f / 3.14159265f);
    ang.y = std::atan2(delta.y, delta.x) * (180.f / 3.14159265f);
    ang.z = 0.f;
    return ang;
}

static float CalcFOV(const Vec3& view, const Vec3& src, const Vec3& dst)
{
    Vec3 aim  = CalcAngle(src, dst);
    Vec3 d    = { aim.x - view.x, NormalizeYaw(aim.y - view.y), 0.f };
    return std::sqrt(d.x * d.x + d.y * d.y);
}

static float EstimateDamage(IPlayer* target, ILocalPlayer* local, const Vec3& pos)
{
    float base    = local->GetWeaponDamage();
    float armor   = target->GetArmor();
    float dist    = (pos - local->GetEyePos()).len();
    float range   = local->GetWeaponRange();
    float falloff = (range > 0.f) ? std::max(0.f, 1.f - dist / range) : 1.f;
    float armored = (armor > 0.f) ? 0.5f : 1.f;
    return base * falloff * armored;
}

static float CalcHitchance(ILocalPlayer* local, const Vec3& pos,
                           float pointScale, bool isBody)
{
    float spread = local->GetSpread() + local->GetInaccuracy();
    if (spread < 0.0001f)
        return 100.f;
    float radius  = isBody ? (40.f * pointScale) : 4.f;
    float dist    = (pos - local->GetEyePos()).len();
    float angSize = std::atan2(radius, dist > 0.f ? dist : 1.f);
    float ratio   = angSize / spread;
    return std::clamp(ratio * 100.f, 0.f, 100.f);
}

static void UpdateBacktrack(const std::vector<IPlayer*>& players,
                            int tick, int maxTicks)
{
    for (auto* p : players)
    {
        if (!p || !p->IsAlive() || p->IsTeammate())
            continue;
        int idx = p->GetIndex();
        if (idx < 0 || idx >= 64)
            continue;

        BacktrackRecord rec;
        for (int h = 0; h < HITBOX_MAX; h++)
            rec.hitboxPos[h] = p->GetHitboxPos(static_cast<HitboxID>(h));
        rec.tick    = tick;
        rec.simtime = p->GetSimTime();
        rec.valid   = true;

        auto& buf = g_backtrack[idx];
        buf.push_back(rec);
        while (static_cast<int>(buf.size()) > maxTicks)
            buf.erase(buf.begin());
    }
}

static AimTarget SelectTarget(ILocalPlayer* local,
                              const std::vector<IPlayer*>& players,
                              const WeaponConfig& wcfg)
{
    AimTarget best;
    Vec3 eye  = local->GetEyePos();
    Vec3 view = local->GetViewAngles();
    int minDmg = wcfg.min_damage_override ? wcfg.min_damage_override_value : wcfg.min_damage;
    int hcReq  = wcfg.hitchance_override  ? wcfg.hitchance_override_value  : wcfg.hitchance;

    for (auto* p : players)
    {
        if (!p || !p->IsAlive() || p->IsTeammate())
            continue;

        int   idx  = p->GetIndex();
        float resolvedYaw = g_rage.GetResolver().Resolve(
            idx, 0.f, p->GetSpeed(), g_cfg.head_misses_trigger);

        static constexpr HitboxID ORDER[] = {
            HITBOX_HEAD, HITBOX_CHEST, HITBOX_STOMACH, HITBOX_PELVIS
        };

        for (HitboxID hb : ORDER)
        {
            if (!(wcfg.hitboxes & (1 << hb)))
                continue;
            if (hb == HITBOX_HEAD && wcfg.force_baim)
                continue;
            if (!p->IsVisible(hb))
                continue;

            Vec3  pos  = p->GetHitboxPos(hb);
            bool  body = (hb != HITBOX_HEAD);
            float fov  = CalcFOV(view, eye, pos);

            if (fov > wcfg.max_fov)
                continue;

            float dmg = EstimateDamage(p, local, pos);
            if (dmg < static_cast<float>(minDmg))
                continue;

            float hc = CalcHitchance(local, pos, wcfg.point_scale, body);
            if (hc < static_cast<float>(hcReq))
                continue;

            if (fov < best.fov)
            {
                best.playerIndex = idx;
                best.hitbox      = hb;
                best.aimPos      = pos;
                best.damage      = dmg;
                best.fov         = fov;
                best.valid       = true;
                best.isBodyAim   = body;
            }
        }

        if (!best.valid && wcfg.force_baim)
        {
            for (HitboxID hb : { HITBOX_CHEST, HITBOX_PELVIS })
            {
                if (!p->IsVisible(hb))
                    continue;
                Vec3  pos = p->GetHitboxPos(hb);
                float fov = CalcFOV(view, eye, pos);
                if (fov > wcfg.max_fov)
                    continue;
                float dmg = EstimateDamage(p, local, pos);
                if (dmg < static_cast<float>(minDmg))
                    continue;
                if (fov < best.fov)
                {
                    best.playerIndex = idx;
                    best.hitbox      = hb;
                    best.aimPos      = pos;
                    best.damage      = dmg;
                    best.fov         = fov;
                    best.valid       = true;
                    best.isBodyAim   = true;
                }
            }
        }

        if (!best.valid && wcfg.prefer_safe)
        {
            if (p->IsVisible(HITBOX_CHEST))
            {
                Vec3  pos = p->GetHitboxPos(HITBOX_CHEST);
                float fov = CalcFOV(view, eye, pos);
                if (fov <= wcfg.max_fov)
                {
                    float dmg = EstimateDamage(p, local, pos);
                    if (dmg >= static_cast<float>(minDmg) && fov < best.fov)
                    {
                        best.playerIndex = idx;
                        best.hitbox      = HITBOX_CHEST;
                        best.aimPos      = pos;
                        best.damage      = dmg;
                        best.fov         = fov;
                        best.valid       = true;
                        best.isBodyAim   = true;
                    }
                }
            }
        }
    }

    return best;
}

static void ApplyAutostop(ILocalPlayer* local, const WeaponConfig& wcfg)
{
    if (wcfg.autostop_mode == AUTOSTOP_NONE)
        return;
    if (local->GetSpeed() > wcfg.autostop_min_speed)
        local->StopMovement();
}

static bool ShouldForceShot(ILocalPlayer* local, const WeaponConfig& wcfg)
{
    bool onGround = local->IsOnGround();
    if (wcfg.force_shot_on_ground && onGround)
        return true;
    if (wcfg.force_shot_in_air && !onGround)
        return true;
    return false;
}

void Rage_OnCreateMove(ILocalPlayer* local,
                       const std::vector<IPlayer*>& players,
                       int currentTick,
                       float& outMoveX,
                       float& outMoveY,
                       float  wishYaw)
{
    g_strafer.Run(local, wishYaw, outMoveX, outMoveY);

    if (!g_cfg.enabled)
        return;
    if (!local || !local->IsAlive())
        return;

    UpdateBacktrack(players, currentTick, g_cfg.max_backtrack_ticks);

    if (g_cfg.auto_scope && !local->IsScoped())
        return;
    if (!local->CanFire())
        return;

    int weaponIdx = std::clamp(local->GetWeaponIndex(), 0,
                               RagebotConfig::WEAPON_SLOTS - 1);
    const WeaponConfig& wcfg = g_cfg.weapons[weaponIdx];

    if (!wcfg.enabled)
        return;

    ApplyAutostop(local, wcfg);

    AimTarget target = SelectTarget(local, players, wcfg);
    if (!target.valid)
        return;

    Vec3 aimAngles = CalcAngle(local->GetEyePos(), target.aimPos);

    if (wcfg.silent)
    {
    }
    else
    {
        local->SetViewAngles(aimAngles);
    }

    bool forceShot = ShouldForceShot(local, wcfg);

    if (g_cfg.auto_fire || forceShot)
        local->ForceAttack();
}

void Rage_OnMiss(int targetIdx, HitboxID hitbox, float resolvedYaw)
{
    g_rage.GetResolver().OnMiss(targetIdx, hitbox, resolvedYaw);
}

void Rage_OnHit(int targetIdx)
{
    g_rage.GetResolver().OnHit(targetIdx);
}

void Rage_OnPlayerUpdate(int idx, float serverYaw, float lbyYaw, float speed)
{
    g_rage.GetResolver().OnPlayerVisible(idx, serverYaw, lbyYaw, speed);
}

void Rage_OnJump(ILocalPlayer* local)
{
    g_strafer.OnJump(local);
}

RagebotConfig& Rage_GetConfig()    { return g_cfg; }
StraferConfig& Rage_GetStrafer()   { return g_strafer_cfg; }
